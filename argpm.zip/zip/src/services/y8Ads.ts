export interface Y8Config {
  appId: string;
  adCooldownMs: number;
  offlineCooldownMs?: number;
}

interface Y8Sdk {
  init?: (appId: string) => void | Promise<void>;
  getLinkForGame?: (callback: (url: string) => void) => void;
  showAd?: (callback: () => void) => void;
}

declare global {
  interface Window {
    ID?: Y8Sdk;
    __Y8_LOAD_FAILED__?: boolean;
    __ASHBOUND_CONFIG__?: Y8Config;
  }
}

export type Y8AdAvailability = "ready" | "unavailable" | "cooldown";

export class Y8AdManager {
  private initialized = false;
  private lastAdAt = 0;
  private lastOfflineChargeAt = 0;
  private readonly config: Y8Config;

  constructor(config: Y8Config) {
    this.config = config;
  }

  init(): void {
    if (this.initialized) return;
    try {
      if (window.ID?.init) {
        void window.ID.init(this.config.appId);
        this.initialized = true;
      }
    } catch {
      this.initialized = false;
    }
  }

  isAdAvailable(): boolean {
    this.init();
    return Boolean(
      navigator.onLine
      && !window.__Y8_LOAD_FAILED__
      && window.ID
      && typeof window.ID.showAd === "function"
    );
  }

  getAvailability(): Y8AdAvailability {
    if (!this.isAdAvailable()) return "unavailable";
    if (this.getAdRemainingMs() > 0) return "cooldown";
    return "ready";
  }

  getAdRemainingMs(): number {
    return Math.max(0, this.config.adCooldownMs - (Date.now() - this.lastAdAt));
  }

  getOfflineRemainingMs(): number {
    const cooldown = this.config.offlineCooldownMs ?? 90000;
    return Math.max(0, cooldown - (Date.now() - this.lastOfflineChargeAt));
  }

  consumeOfflineCharge(onReward: () => void): boolean {
    if (this.getOfflineRemainingMs() > 0) {
      this.notify(`Офлайн-заряд появится через ${Math.ceil(this.getOfflineRemainingMs() / 1000)} сек.`);
      return false;
    }

    this.lastOfflineChargeAt = Date.now();
    onReward();
    return true;
  }

  showRewardedAd(
    onReward: () => void,
    onMuteAudio: (muted: boolean) => void,
    onUnavailable: () => void = () => this.notify("Реклама недоступна: доступен офлайн-заряд или оплата Озарением."),
  ): void {
    if (!this.isAdAvailable()) {
      onMuteAudio(false);
      onUnavailable();
      return;
    }

    const remaining = this.getAdRemainingMs();
    if (remaining > 0) {
      onMuteAudio(false);
      this.notify(`Рекламная подсказка готова через ${Math.ceil(remaining / 1000)} сек.`);
      return;
    }

    onMuteAudio(true);
    let finished = false;
    const finishAd = (adViewed: boolean) => {
      if (finished) return;
      finished = true;
      onMuteAudio(false);
      if (!adViewed) {
        this.notify("Просмотр ролика не завершён. Награда не выдана.");
        return;
      }
      this.lastAdAt = Date.now();
      onReward();
    };

    try {
      window.ID?.showAd?.(() => finishAd(true));
      window.setTimeout(() => finishAd(false), 15000);
    } catch {
      finishAd(false);
    }
  }

  private notify(message: string): void {
    const toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("visible");
    window.setTimeout(() => toast.classList.remove("visible"), 3500);
  }
}
