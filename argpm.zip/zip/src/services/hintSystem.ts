import { ELEMENTS, QUESTS, RECIPES, getElement, type Recipe } from "../data/alchemyData";

export interface HintRecipe {
  recipe: Recipe;
  first: ReturnType<typeof getElement>;
  second: ReturnType<typeof getElement>;
  result: ReturnType<typeof getElement>;
  questRelated: boolean;
}

export function findNextHint(unlocked: ReadonlySet<string>, questIndex: number): HintRecipe | null {
  const quest = QUESTS[Math.min(questIndex, QUESTS.length - 1)];
  const available = RECIPES
    .filter((recipe) =>
      unlocked.has(recipe.a)
      && unlocked.has(recipe.b)
      && !unlocked.has(recipe.result)
    )
    .sort((left, right) => {
      const leftQuest = quest?.targetElementId === left.result ? 1 : 0;
      const rightQuest = quest?.targetElementId === right.result ? 1 : 0;
      return rightQuest - leftQuest;
    });

  const recipe = available[0];
  if (!recipe) return null;

  return {
    recipe,
    first: getElement(recipe.a),
    second: getElement(recipe.b),
    result: getElement(recipe.result),
    questRelated: quest?.targetElementId === recipe.result,
  };
}

export function hasHintElement(unlocked: ReadonlySet<string>, elementId: string): boolean {
  return ELEMENTS.some((element) => element.id === elementId) && unlocked.has(elementId);
}
