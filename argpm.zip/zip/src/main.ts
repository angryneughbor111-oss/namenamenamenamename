import "./styles.css";
import { Application, Assets, Container, Graphics, Sprite, Text, Texture, TextStyle, FederatedPointerEvent, Ticker } from "pixi.js";
import { ELEMENTS, QUESTS, RECIPES, findRecipe, getElement, getElementCategory, type AlchemyElement, type ElementCategory } from "./data/alchemyData";
import { Y8AdManager } from "./services/y8Ads";
import { findNextHint, type HintRecipe } from "./services/hintSystem";

interface SaveData {
  unlocked: string[];
  insight: number;
  questIndex: number;
  muted: boolean;
}

interface ElementCard {
  id: string;
  container: Container;
  dragging: boolean;
}

const STORAGE_KEY = "ashbound-alchemy-save-v1";
const defaultSave: SaveData = {
  unlocked: ["fire", "water", "earth", "air"],
  insight: 0,
  questIndex: 0,
  muted: false,
};

function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...defaultSave, unlocked: [...defaultSave.unlocked] };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      unlocked: Array.isArray(parsed.unlocked) && parsed.unlocked.length ? parsed.unlocked : [...defaultSave.unlocked],
      insight: typeof parsed.insight === "number" ? parsed.insight : 0,
      questIndex: typeof parsed.questIndex === "number" ? parsed.questIndex : 0,
      muted: Boolean(parsed.muted),
    };
  } catch {
    return { ...defaultSave, unlocked: [...defaultSave.unlocked] };
  }
}

let save = loadSave();
let unlocked = new Set(save.unlocked);
let combo = 0;
let comboTimer = 0;
let muted = save.muted;
let adMuted = false;
let highlightedHint: HintRecipe | null = null;
let fullHintPair: { a: string; b: string } | null = null;
let activeCategory: "Все" | ElementCategory = "Все";
let activeSubcategory: "Все уровни" | `T${0 | 1 | 2 | 3 | 4 | 5 | 6}` = "Все уровни";
let sortMode: "discovery" | "alphabet" = "discovery";

async function startGame(): Promise<void> {
const app = new Application();
await app.init({ resizeTo: document.getElementById("canvas-host")!, backgroundAlpha: 0, antialias: true });
const host = document.getElementById("canvas-host")!;
host.appendChild(app.canvas);

const scene = new Container();
app.stage.addChild(scene);

const linkGraphics = new Graphics();
scene.addChild(linkGraphics);

const particles = new Container();
scene.addChild(particles);

const cards: ElementCard[] = [];
let activeCard: ElementCard | null = null;
let dragOffset = { x: 0, y: 0 };

const ring = new Graphics();
scene.addChild(ring);

function drawRing(): void {
  ring.clear();
  const cx = app.screen.width / 2;
  const cy = app.screen.height / 2;
  ring.circle(cx, cy, 72).stroke({ color: 0xc9a24b, width: 1, alpha: 0.22 });
  ring.circle(cx, cy, 96).stroke({ color: 0x78995d, width: 1, alpha: 0.12 });
  ring.moveTo(cx - 112, cy).lineTo(cx - 88, cy).stroke({ color: 0xc9a24b, width: 1, alpha: 0.35 });
  ring.moveTo(cx + 88, cy).lineTo(cx + 112, cy).stroke({ color: 0xc9a24b, width: 1, alpha: 0.35 });
  ring.moveTo(cx, cy - 112).lineTo(cx, cy - 88).stroke({ color: 0xc9a24b, width: 1, alpha: 0.35 });
  ring.moveTo(cx, cy + 88).lineTo(cx, cy + 112).stroke({ color: 0xc9a24b, width: 1, alpha: 0.35 });
}
drawRing();

class SynthAudio {
  private context: AudioContext | null = null;
  private activeSource: AudioBufferSourceNode | null = null;
  private lastPlayed = new Map<string, number>();

  async play(file: string, throttleMs = 80): Promise<void> {
    if (muted || adMuted) return;
    const now = performance.now();
    const previous = this.lastPlayed.get(file) ?? 0;
    if (now - previous < throttleMs) return;
    this.lastPlayed.set(file, now);

    try {
      if (!this.context) this.context = new AudioContext();
      if (this.context.state === "suspended") await this.context.resume();
      if (this.activeSource) {
        try { this.activeSource.stop(); } catch { /* already stopped */ }
        this.activeSource = null;
      }
      const response = await fetch(`./assets/sfx/${file}`);
      if (!response.ok) return;
      const buffer = await response.arrayBuffer();
      const audioBuffer = await this.context.decodeAudioData(buffer);
      const source = this.context.createBufferSource();
      const gain = this.context.createGain();
      gain.gain.value = file === "pickup.wav" || file === "hover_link.wav" ? 0.38 : 0.62;
      source.buffer = audioBuffer;
      source.connect(gain).connect(this.context.destination);
      source.onended = () => {
        if (this.activeSource === source) this.activeSource = null;
      };
      this.activeSource = source;
      source.start();
    } catch {
      // Audio is optional: WebViews, file protocols and AdBlock must not block the game.
    }
  }

  stop(): void {
    if (!this.activeSource) return;
    try { this.activeSource.stop(); } catch { /* already stopped */ }
    this.activeSource = null;
  }
}

const audio = new SynthAudio();

function saveGame(): void {
  save = {
    unlocked: [...unlocked],
    insight: save.insight,
    questIndex: save.questIndex,
    muted,
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(save));
}

function toast(message: string): void {
  const node = document.getElementById("toast")!;
  node.textContent = message;
  node.classList.add("visible");
  window.setTimeout(() => node.classList.remove("visible"), 2600);
}

function showDiscovery(element: AlchemyElement, recipeName: string): void {
  const card = document.getElementById("discovery-card")!;
  document.getElementById("discovery-name")!.textContent = element.name;
  document.getElementById("discovery-category")!.textContent = getElementCategory(element);
  document.getElementById("discovery-description")!.textContent = element.description;
  document.getElementById("discovery-recipe")!.textContent = recipeName;
  card.classList.add("visible");
  window.setTimeout(() => card.classList.remove("visible"), 6000);
}

function showEncyclopedia(element: AlchemyElement): void {
  const modal = document.getElementById("encyclopedia-modal")!;
  const recipe = findRecipeElement(element.id);
  document.getElementById("encyclopedia-name")!.textContent = element.name;
  document.getElementById("encyclopedia-category")!.textContent = getElementCategory(element);
  document.getElementById("encyclopedia-description")!.textContent = element.description;
  document.getElementById("encyclopedia-recipe")!.textContent = recipe
    ? `${getElement(recipe.a).name} + ${getElement(recipe.b).name} = ${element.name}`
    : "Базовый элемент — получен из стартового запаса Гримуара.";
  modal.classList.add("visible");
}

function findRecipeElement(resultId: string) {
  return RECIPES.find((recipe) => recipe.result === resultId);
}

function hexToPixi(hex: string): number {
  return parseInt(hex.replace("#", ""), 16);
}

function createCard(element: AlchemyElement, x?: number, y?: number): ElementCard {
  const container = new Container();
  container.eventMode = "static";
  container.cursor = "grab";

  const shadow = new Graphics();
  shadow.ellipse(0, 48, 42, 9).fill({ color: 0x000000, alpha: 0.30 });
  container.addChild(shadow);

  const icon = new Sprite(Texture.EMPTY);
  icon.width = 72;
  icon.height = 72;
  icon.anchor.set(0.5);
  icon.position.set(0, -3);
  container.addChild(icon);
  void Assets.load(`./assets/items/${element.id}.png`).then((texture) => {
    icon.texture = texture;
  }).catch(() => { /* CSS/DOM fallback remains visible in the grimoire. */ });

  const symbol = new Text({ text: element.symbol, style: new TextStyle({ fontFamily: "Georgia", fontSize: 12, fill: element.color, align: "center" }) });
  symbol.anchor.set(0.5);
  symbol.position.set(0, -48);
  container.addChild(symbol);

  const label = new Text({ text: element.name, style: new TextStyle({ fontFamily: "Georgia", fontSize: element.name.length > 13 ? 10 : 12, fill: "#e5dac0", align: "center", wordWrap: true, wordWrapWidth: 86 }) });
  label.anchor.set(0.5);
  label.position.set(0, 45);
  container.addChild(label);

  const cx = x ?? app.screen.width * (0.18 + Math.random() * 0.64);
  const cy = y ?? app.screen.height * (0.20 + Math.random() * 0.60);
  container.position.set(cx, cy);
  scene.addChild(container);

  const card: ElementCard = { id: element.id, container, dragging: false };

  container.on("pointerdown", (event: FederatedPointerEvent) => {
    event.stopPropagation();
    activeCard = card;
    card.dragging = true;
    container.cursor = "grabbing";
    scene.setChildIndex(container, scene.children.length - 1);
    const point = app.stage.toLocal(event.global);
    dragOffset = { x: container.position.x - point.x, y: container.position.y - point.y };
    void audio.play("pickup.wav");
  });

  container.on("pointermove", () => undefined);
  container.on("pointerup", () => undefined);
  container.on("pointerupoutside", () => undefined);

  cards.push(card);
  return card;
}

app.canvas.addEventListener("pointermove", (event: PointerEvent) => {
  if (!activeCard || !activeCard.dragging) return;
  const rect = app.canvas.getBoundingClientRect();
  const x = (event.clientX - rect.x) * (app.screen.width / rect.width);
  const y = (event.clientY - rect.y) * (app.screen.height / rect.height);
  activeCard.container.position.set(x + dragOffset.x, y + dragOffset.y);
});

app.canvas.addEventListener("pointerup", (event: PointerEvent) => {
  if (!activeCard) return;
  finishDrag({ stopPropagation: () => event.stopPropagation(), global: event } as unknown as FederatedPointerEvent);
});

app.canvas.addEventListener("pointercancel", () => {
  if (!activeCard) return;
  activeCard.dragging = false;
  activeCard.container.cursor = "grab";
  activeCard = null;
  linkGraphics.clear();
});

function finishDrag(event: FederatedPointerEvent): void {
  if (!activeCard) return;
  const source = activeCard;
  source.dragging = false;
  source.container.cursor = "grab";

  const sourcePoint = source.container.position;
  let target: ElementCard | null = null;
  let nearest = 82;
  for (const card of cards) {
    if (card === source) continue;
    const distance = Math.hypot(card.container.position.x - sourcePoint.x, card.container.position.y - sourcePoint.y);
    if (distance < nearest) {
      nearest = distance;
      target = card;
    }
  }

  if (target) craft(source, target); else {
    linkGraphics.clear();
  }
  activeCard = null;
  event.stopPropagation();
}

function removeCard(card: ElementCard): void {
  const index = cards.indexOf(card);
  if (index >= 0) cards.splice(index, 1);
  scene.removeChild(card.container);
  card.container.destroy({ children: true });
}

function craft(source: ElementCard, target: ElementCard): void {
  const recipe = findRecipe(source.id, target.id);
  if (!recipe) {
    combo = 0;
    updateStats();
    void audio.play("craft_fail.wav");
    linkGraphics.clear();
    spawnParticles(source.container.position.x, source.container.position.y, "#c98a55");
    return;
  }

  combo = combo >= 3 ? 3 : combo + 1;
  window.clearTimeout(comboTimer);
  comboTimer = window.setTimeout(() => { combo = 0; updateStats(); }, 7000);

  fullHintPair = null;
  highlightedHint = null;
  linkGraphics.clear();
  const element = getElement(recipe.result);
  const first = getElement(source.id);
  const second = getElement(target.id);
  const newElement = !unlocked.has(element.id);
  unlocked.add(element.id);

  if (newElement) {
    save.insight += 10;
    showDiscovery(element, `${first.name} + ${second.name}`);
  }

  const center = {
    x: (source.container.position.x + target.container.position.x) / 2,
    y: (source.container.position.y + target.container.position.y) / 2,
  };
  removeCard(source);
  removeCard(target);
  createCard(element, center.x, center.y);

  if (combo === 2) void audio.play("combo_x2.wav");
  else if (combo === 3) void audio.play("combo_x3.wav");
  else void audio.play("craft_success.wav");

  if (combo >= 2) save.insight += combo * 5;
  spawnParticles(center.x, center.y, element.color);
  updateStats();
  renderGrimoire();
  updateQuest();
  saveGame();
}

function spawnParticles(x: number, y: number, color: string): void {
  for (let i = 0; i < 26; i++) {
    const dot = new Graphics();
    dot.circle(0, 0, 1 + Math.random() * 2.5).fill({ color: hexToPixi(color), alpha: 0.9 });
    dot.position.set(x, y);
    particles.addChild(dot);
    const angle = Math.random() * Math.PI * 2;
    const speed = 2 + Math.random() * 5;
    const life = 38 + Math.random() * 20;
    let elapsed = 0;
    const ticker = (tickerInstance: Ticker) => {
      elapsed += tickerInstance.deltaTime;
      dot.position.x += Math.cos(angle) * speed * tickerInstance.deltaTime;
      dot.position.y += Math.sin(angle) * speed * tickerInstance.deltaTime;
      dot.alpha = Math.max(0, 1 - elapsed / life);
      if (elapsed >= life) {
        app.ticker.remove(ticker);
        particles.removeChild(dot);
        dot.destroy();
      }
    };
    app.ticker.add(ticker);
  }
}

function screenShake(): void {
  let count = 7;
  const ticker = (tickerInstance: Ticker) => {
    count -= tickerInstance.deltaTime;
    scene.position.set((Math.random() - 0.5) * 5, (Math.random() - 0.5) * 5);
    if (count <= 0) {
      app.ticker.remove(ticker);
      scene.position.set(0, 0);
    }
  };
  app.ticker.add(ticker);
}

function renderCategoryTabs(): void {
  const tabs = document.getElementById("category-tabs")!;
  const categories: ("Все" | ElementCategory)[] = [
    "Все", "Стихии", "Природа", "Минералы и Металлы", "Растения", "Химия и Снадобья", "Ремесло",
  ];
  tabs.replaceChildren();

  for (const category of categories) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "category-tab";
    button.classList.toggle("active", activeCategory === category);

    const elements = ELEMENTS.filter((element) =>
      category === "Все" || getElementCategory(element) === category
    );
    const opened = elements.filter((element) => unlocked.has(element.id)).length;
    const categoryIcons: Record<"Все" | ElementCategory, string> = {
      "Все": "✦", "Стихии": "△", "Природа": "☁", "Минералы и Металлы": "◆",
      "Растения": "❧", "Химия и Снадобья": "⚗", "Ремесло": "⚒",
    };
    button.innerHTML = `<span class="category-icon">${categoryIcons[category]}</span><span class="category-name">${category === "Все" ? "Все" : category}</span><small>${opened}/${elements.length}</small>`;
    button.addEventListener("click", () => {
      activeCategory = category;
      activeSubcategory = "Все уровни";
      renderCategoryTabs();
      renderGrimoire();
    });
    tabs.appendChild(button);
  }
}

function renderSubcategoryTabs(): void {
  const tabs = document.getElementById("subcategory-tabs");
  if (!tabs) return;
  const options: ("Все уровни" | `T${0 | 1 | 2 | 3 | 4 | 5 | 6}`)[] = [
    "Все уровни", "T0", "T1", "T2", "T3", "T4", "T5", "T6",
  ];
  tabs.replaceChildren();

  for (const option of options) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "subcategory-tab";
    button.classList.toggle("active", activeSubcategory === option);
    button.textContent = option;
    button.addEventListener("click", () => {
      activeSubcategory = option;
      renderSubcategoryTabs();
      renderGrimoire();
    });
    tabs.appendChild(button);
  }
}

function renderGrimoire(): void {
  const list = document.getElementById("element-list")!;
  const query = (document.getElementById("element-search") as HTMLInputElement).value.trim().toLowerCase();
  list.replaceChildren();

  renderSubcategoryTabs();
  let visibleElements = ELEMENTS.filter((element) => unlocked.has(element.id));
  visibleElements = visibleElements.filter((element) =>
    activeCategory === "Все" || getElementCategory(element) === activeCategory
  );
  if (activeSubcategory !== "Все уровни") {
    const tier = Number(activeSubcategory.slice(1)) as 0 | 1 | 2 | 3 | 4 | 5;
    visibleElements = visibleElements.filter((element) => element.tier === tier);
  }
  if (sortMode === "alphabet") {
    visibleElements = [...visibleElements].sort((a, b) => a.name.localeCompare(b.name, "ru"));
  }

  for (const element of visibleElements) {
    if (query && !element.name.toLowerCase().includes(query)) continue;
    const button = document.createElement("div");
    button.setAttribute("role", "button");
    button.tabIndex = 0;
    button.className = "element-chip";
    if (fullHintPair && (fullHintPair.a === element.id || fullHintPair.b === element.id)) {
      button.classList.add("hint-full");
    } else if (!fullHintPair && highlightedHint?.recipe.a === element.id) {
      button.classList.add("hint-soft");
    }
    button.innerHTML = `<small>T${element.tier}</small><img class="element-icon" src="./assets/items/${element.id}.png" alt="${element.name}" draggable="false" /><b>${element.name}</b><i class="info-button" role="button" aria-label="Показать рецепт" title="Показать рецепт">i</i>`;
    button.addEventListener("click", () => {
      const occupied = cards.find((card) => card.id === element.id);
      if (occupied) {
        occupied.container.position.set(app.screen.width / 2 + (Math.random() - 0.5) * 180, app.screen.height / 2 + (Math.random() - 0.5) * 180);
      } else {
        createCard(element);
      }
      void audio.play("hover_link.wav");
    });
    button.addEventListener("keydown", (event) => {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        const occupied = cards.find((card) => card.id === element.id);
        if (occupied) occupied.container.position.set(app.screen.width / 2, app.screen.height / 2);
        else createCard(element);
        void audio.play("hover_link.wav");
      }
    });
    button.querySelector(".info-button")?.addEventListener("click", (event) => {
      event.stopPropagation();
      showEncyclopedia(element);
    });
    button.addEventListener("contextmenu", (event) => {
      event.preventDefault();
      showEncyclopedia(element);
    });
    list.appendChild(button);
  }
}

function updateStats(): void {
  document.getElementById("element-count")!.textContent = `${unlocked.size} / ${ELEMENTS.length}`;
  document.getElementById("open-count")!.textContent = `${unlocked.size} открыто`;
  document.getElementById("stage-progress")!.textContent = `${unlocked.size} элемента открыто`;
  renderCategoryTabs();
  document.getElementById("insight-count")!.textContent = String(save.insight);
  document.getElementById("combo-count")!.textContent = combo > 0 ? `x${combo}` : "x1";
  const muteButton = document.getElementById("mute-btn")!;
  muteButton.textContent = muted || adMuted ? "×" : "♪";
  muteButton.classList.toggle("muted", muted || adMuted);
}

function updateQuest(): void {
  const quest = QUESTS[Math.min(save.questIndex, QUESTS.length - 1)];
  document.getElementById("quest-title")!.textContent = quest.title;
  document.getElementById("quest-lore")!.textContent = quest.loreHint;
  const reward = document.getElementById("quest-reward") as HTMLButtonElement;
  reward.disabled = !unlocked.has(quest.targetElementId);
  reward.textContent = unlocked.has(quest.targetElementId) ? "Получить награду" : "Найдите элемент";
}

function clearStage(): void {
  highlightedHint = null;
  fullHintPair = null;
  linkGraphics.clear();
  while (cards.length) removeCard(cards[0]);
  for (const id of ["fire", "water", "earth", "air"] as const) {
    if (unlocked.has(id)) createCard(getElement(id));
  }
  linkGraphics.clear();
}

function clearHintHighlights(): void {
  highlightedHint = null;
  fullHintPair = null;
  linkGraphics.clear();
  renderGrimoire();
}

function applySoftHint(hint: HintRecipe): void {
  highlightedHint = hint;
  fullHintPair = null;
  linkGraphics.clear();
  renderGrimoire();
  toast(hint.questRelated
    ? `Контракт близок: попробуйте соединить ${hint.first.name} с Т${hint.second.tier} элементом «${hint.second.name}».`
    : `Попробуйте соединить ${hint.first.name} с чем-то из категории T${hint.second.tier}: «${hint.second.name}».`);
}

function applyFullHint(hint: HintRecipe): void {
  highlightedHint = hint;
  fullHintPair = { a: hint.recipe.a, b: hint.recipe.b };

  const first = getElement(hint.recipe.a);
  const second = getElement(hint.recipe.b);
  let firstCard = cards.find((card) => card.id === first.id);
  let secondCard = cards.find((card) => card.id === second.id);

  const centerX = app.screen.width / 2;
  const centerY = app.screen.height / 2;
  if (!firstCard) firstCard = createCard(first, centerX - 92, centerY);
  else firstCard.container.position.set(centerX - 92, centerY);
  if (!secondCard) secondCard = createCard(second, centerX + 92, centerY);
  else secondCard.container.position.set(centerX + 92, centerY);

  linkGraphics.clear();
  linkGraphics.moveTo(firstCard.container.position.x, firstCard.container.position.y)
    .lineTo(secondCard.container.position.x, secondCard.container.position.y)
    .stroke({ color: 0xe2c46b, width: 4, alpha: 0.9 });
  renderGrimoire();
  toast(`Полная подсказка: ${first.name} + ${second.name} → ${hint.result.name}`);
}

app.ticker.add(() => {
  ring.rotation += 0.002;
  if (activeCard) {
    linkGraphics.clear();
    let nearest: ElementCard | null = null;
    let nearestDistance = 116;
    for (const card of cards) {
      if (card === activeCard) continue;
      const distance = Math.hypot(card.container.position.x - activeCard.container.position.x, card.container.position.y - activeCard.container.position.y);
      if (distance < nearestDistance) {
        nearest = card;
        nearestDistance = distance;
      }
    }
    if (nearest) {
      linkGraphics.moveTo(activeCard.container.position.x, activeCard.container.position.y)
        .lineTo(nearest.container.position.x, nearest.container.position.y)
        .stroke({ color: 0xd5b85c, width: 3, alpha: 0.7 });
      void audio.play("hover_link.wav", 500);
    }
  } else if (fullHintPair) {
    const first = cards.find((card) => card.id === fullHintPair?.a);
    const second = cards.find((card) => card.id === fullHintPair?.b);
    if (first && second) {
      linkGraphics.clear();
      linkGraphics.moveTo(first.container.position.x, first.container.position.y)
        .lineTo(second.container.position.x, second.container.position.y)
        .stroke({ color: 0xe2c46b, width: 4, alpha: 0.9 });
    }
  }
});

window.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  document.getElementById("discovery-card")?.classList.remove("visible");
  document.getElementById("encyclopedia-modal")?.classList.remove("visible");
});
(document.getElementById("element-search") as HTMLInputElement).addEventListener("input", renderGrimoire);
(document.getElementById("element-sort") as HTMLSelectElement).addEventListener("change", (event) => {
  sortMode = (event.currentTarget as HTMLSelectElement).value === "alphabet" ? "alphabet" : "discovery";
  renderGrimoire();
});
document.getElementById("discovery-close")?.addEventListener("click", () => {
  document.getElementById("discovery-card")?.classList.remove("visible");
});
document.getElementById("encyclopedia-close")?.addEventListener("click", () => {
  document.getElementById("encyclopedia-modal")?.classList.remove("visible");
});
document.getElementById("discovery-card")?.addEventListener("pointerdown", (event) => {
  if (event.target === event.currentTarget) document.getElementById("discovery-card")?.classList.remove("visible");
});
document.getElementById("encyclopedia-modal")?.addEventListener("pointerdown", (event) => {
  if (event.target === event.currentTarget) document.getElementById("encyclopedia-modal")?.classList.remove("visible");
});
document.getElementById("clear-btn")!.addEventListener("click", clearStage);
document.getElementById("reset-btn")!.addEventListener("click", () => {
  if (!window.confirm("Сбросить весь прогресс Ashbound Alchemy?")) return;
  unlocked = new Set(["fire", "water", "earth", "air"]);
  save = { ...defaultSave, unlocked: ["fire", "water", "earth", "air"] };
  combo = 0;
  localStorage.removeItem(STORAGE_KEY);
  clearStage();
  updateStats();
  renderGrimoire();
  updateQuest();
  toast("Прогресс сброшен");
});

document.getElementById("mute-btn")!.addEventListener("click", () => {
  muted = !muted;
  if (muted) audio.stop();
  updateStats();
  saveGame();
});

document.getElementById("quest-reward")!.addEventListener("click", () => {
  const quest = QUESTS[save.questIndex];
  if (!quest || !unlocked.has(quest.targetElementId)) return;
  save.insight += quest.rewardInsight;
  void audio.play("quest_complete.wav");
  toast(`Контракт завершён: +${quest.rewardInsight} Озарения`);
  if (save.questIndex < QUESTS.length - 1) {
    save.questIndex += 1;
  } else {
    toast("Все доступные контракты завершены");
  }
  saveGame();
  updateStats();
  updateQuest();
});

const adConfig = window.__ASHBOUND_CONFIG__ ?? { appId: "ashbound-alchemy-portal", adCooldownMs: 120000 };
const adManager = new Y8AdManager(adConfig);
adManager.init();

const hintButton = document.getElementById("hint-btn") as HTMLButtonElement;
const fullHintButton = document.getElementById("full-hint-btn") as HTMLButtonElement;

hintButton.addEventListener("click", () => {
  const hint = findNextHint(unlocked, save.questIndex);
  if (!hint) {
    toast("Доступных сочетаний пока нет. Откройте новый элемент или сбросьте поиск.");
    return;
  }
  applySoftHint(hint);
});

function updateFullHintButton(): void {
  const offlineRemaining = adManager.getOfflineRemainingMs();
  const adAvailable = adManager.isAdAvailable();
  const adRemaining = adManager.getAdRemainingMs();

  if (adAvailable && adRemaining <= 0) {
    fullHintButton.innerHTML = "Полная подсказка <small>🎬 просмотр рекламы</small>";
  } else if (offlineRemaining <= 0) {
    fullHintButton.innerHTML = "Полная подсказка <small>офлайн-заряд готов</small>";
  } else if (save.insight >= 25) {
    fullHintButton.innerHTML = "Полная подсказка <small>25 Озарения</small>";
  } else {
    fullHintButton.innerHTML = `Полная подсказка <small>заряд через ${Math.ceil(offlineRemaining / 1000)} сек.</small>`;
  }
}

fullHintButton.addEventListener("click", () => {
  const hint = findNextHint(unlocked, save.questIndex);
  if (!hint) {
    toast("Нет доступного неоткрытого рецепта для полной подсказки.");
    return;
  }

  const reveal = () => {
    applyFullHint(hint);
  };

  if (adManager.isAdAvailable()) {
    if (adManager.getAdRemainingMs() <= 0) {
      adManager.showRewardedAd(reveal, (mutedState) => {
        adMuted = mutedState;
        if (mutedState) audio.stop();
        updateStats();
      }, () => {
        toast("Реклама недоступна. Используйте офлайн-заряд или 25 Озарения.");
        updateFullHintButton();
      });
    } else if (save.insight >= 25) {
      save.insight -= 25;
      saveGame();
      updateStats();
      reveal();
      updateFullHintButton();
    } else {
      toast("Рекламный ролик на кулдауне. Накопите 25 Озарения или дождитесь заряда.");
    }
  } else if (adManager.consumeOfflineCharge(reveal)) {
    updateFullHintButton();
  } else if (save.insight >= 25) {
    save.insight -= 25;
    saveGame();
    updateStats();
    reveal();
    updateFullHintButton();
  }
});

window.setInterval(updateFullHintButton, 1000);

window.addEventListener("resize", () => drawRing());

renderGrimoire();
updateStats();
updateQuest();
clearStage();
}

startGame().catch((error: unknown) => {
  console.error("Ashbound Alchemy initialization failed", error);
  document.getElementById("toast")?.classList.add("visible");
});
