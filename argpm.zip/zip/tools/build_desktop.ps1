$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath (Resolve-Path (Join-Path $PSScriptRoot '..'))

npm.cmd run build

Remove-Item -Recurse -Force 'build\desktop-dist' -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force 'dist-desktop' -ErrorAction SilentlyContinue

& '.venv\Scripts\pyinstaller.exe' --noconfirm --clean --distpath 'dist-desktop' --workpath 'build\desktop-dist' 'tools\AshboundAlchemy.spec'

Write-Host "Desktop build: $((Resolve-Path 'dist-desktop\AshboundAlchemy').Path)"
Write-Host "Launch: dist-desktop\AshboundAlchemy\AshboundAlchemy.exe"
