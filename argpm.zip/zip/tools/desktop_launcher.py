from __future__ import annotations

import http.server
import socket
import sys
import threading
import webbrowser
from pathlib import Path
import tkinter as tk
from tkinter import ttk


def find_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return int(sock.getsockname()[1])


def web_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(getattr(sys, "_MEIPASS")) / "dist"
    return Path(__file__).resolve().parents[1] / "dist"


class AshboundDesktop:
    def __init__(self) -> None:
        self.root = web_root()
        self.port = find_free_port()
        self.server: http.server.ThreadingHTTPServer | None = None
        self.server_thread: threading.Thread | None = None

        self.window = tk.Tk()
        self.window.title("Ashbound Alchemy Desktop")
        self.window.geometry("420x230")
        self.window.resizable(False, False)

        style = ttk.Style(self.window)
        style.theme_use("vista" if "vista" in style.theme_names() else "clam")

        frame = ttk.Frame(self.window, padding=24)
        frame.pack(fill="both", expand=True)

        ttk.Label(frame, text="ASHBOUND ALCHEMY", font=("Georgia", 17, "bold")).pack(pady=(4, 6))
        ttk.Label(frame, text="Локальная desktop-сборка готова", foreground="#4d6b45").pack(pady=(0, 12))

        self.status = ttk.Label(frame, text="Запуск локального сервера...")
        self.status.pack(pady=(0, 12))

        actions = ttk.Frame(frame)
        actions.pack()
        self.open_button = ttk.Button(actions, text="Открыть игру", command=self.open_game)
        self.open_button.pack(side="left", padx=5)
        ttk.Button(actions, text="Закрыть", command=self.close).pack(side="left", padx=5)

        self.window.protocol("WM_DELETE_WINDOW", self.close)

    @property
    def url(self) -> str:
        return f"http://127.0.0.1:{self.port}/"

    def start(self) -> None:
        if not (self.root / "index.html").is_file():
            self.status.configure(text="Ошибка: dist/index.html не найден")
            return

        root = self.root

        class QuietHandler(http.server.SimpleHTTPRequestHandler):
            def __init__(self, *args: object, **kwargs: object) -> None:
                super().__init__(*args, directory=str(root), **kwargs)

            def log_message(self, format: str, *args: object) -> None:
                return

        self.server = http.server.ThreadingHTTPServer(("127.0.0.1", self.port), QuietHandler)
        self.server_thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.server_thread.start()
        self.status.configure(text=f"Сервер: {self.url}")
        self.window.after(350, self.open_game)

    def open_game(self) -> None:
        webbrowser.open(self.url, new=1, autoraise=True)

    def close(self) -> None:
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
        self.window.destroy()


def main() -> None:
    app = AshboundDesktop()
    app.start()
    app.window.mainloop()


if __name__ == "__main__":
    main()
