import re
from pathlib import Path

source = (Path(__file__).resolve().parents[1] / "src" / "data" / "alchemyData.ts").read_text(encoding="utf-8")

elements = set(re.findall(r'\{ id: "([^"]+)"', source[:source.index("export function getElementCategory")]))
recipes = re.findall(r'\{ a: "([^"]+)", b: "([^"]+)", result: "([^"]+)" \}', source)

unknown = sorted({item for a, b, result in recipes for item in (a, b, result) if item not in elements})
print(f"ELEMENTS={len(elements)} RECIPES={len(recipes)}")
print("UNKNOWN=" + (",".join(unknown) if unknown else "none"))

pairs: dict[tuple[str, str], list[str]] = {}
for a, b, result in recipes:
    pair = tuple(sorted((a, b)))
    pairs.setdefault(pair, []).append(result)
conflicts = {pair: results for pair, results in pairs.items() if len(set(results)) > 1}
print("CONFLICT_PAIRS=" + str(conflicts))

reached = {"fire", "water", "earth", "air"}
changed = True
while changed:
    changed = False
    for a, b, result in recipes:
        if a in reached and b in reached and result not in reached:
            reached.add(result)
            changed = True

unreachable = sorted(elements - reached)
print("UNREACHABLE=" + (",".join(unreachable) if unreachable else "none"))
print("REACHED=" + str(len(reached)))

if unknown or conflicts or unreachable:
    raise SystemExit(1)
