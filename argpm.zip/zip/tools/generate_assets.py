from pathlib import Path
import re
import hashlib

import librosa
import numpy as np
import skia
import soundfile as sf
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "public"
ASSETS = PUBLIC / "assets"
SFX = ASSETS / "sfx"
SAMPLE_RATE = 44100
ITEM_ICON_SIZE = 64
ITEM_PIXEL_BASE_SIZE = 32


def ensure_dirs():
    PUBLIC.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)
    SFX.mkdir(parents=True, exist_ok=True)


def render_flask(size: int) -> Image.Image:
    surface = skia.Surface(size, size)
    canvas = surface.getCanvas()
    canvas.clear(skia.Color4f(0.07, 0.06, 0.08, 1).toColor())

    shadow = skia.ImageFilters.DropShadow(0, size * 0.018, size * 0.018, size * 0.018,
                                          skia.ColorSetARGB(180, 0, 0, 0))
    paint = skia.Paint(AntiAlias=True)
    paint.setImageFilter(shadow)

    gradient = skia.GradientShader.MakeLinear(
        [skia.Point(size * 0.35, size * 0.15), skia.Point(size * 0.68, size * 0.88)],
        [skia.ColorSetARGB(255, 196, 145, 66), skia.ColorSetARGB(255, 74, 48, 30)],
        [0.0, 1.0], skia.TileMode.kClamp,
    )
    metal = skia.Paint(AntiAlias=True)
    metal.setShader(gradient)
    metal.setImageFilter(shadow)

    neck_rect = skia.Rect.MakeXYWH(size * 0.42, size * 0.11, size * 0.16, size * 0.24)
    canvas.drawRRect(skia.RRect.MakeRectXY(neck_rect, size * 0.03, size * 0.03), metal)
    canvas.drawRect(skia.Rect.MakeXYWH(size * 0.45, size * 0.10, size * 0.10, size * 0.04), metal)

    blob_scale = 1.0
    noise = skia.PerlinNoiseShader.MakeFractalNoise(size * 0.012, size * 0.012, 3, 0.0)
    liquid_shader = skia.GradientShader.MakeRadial(
        skia.Point(size * 0.48, size * 0.62), size * 0.24,
        [skia.ColorSetARGB(255, 216, 128, 50), skia.ColorSetARGB(255, 104, 49, 31)],
        [0.0, 1.0], skia.TileMode.kClamp,
    )

    glass = skia.Paint(AntiAlias=True)
    glass.setColor(skia.ColorSetARGB(115, 170, 205, 196))
    glass.setStyle(skia.Paint.kFill_Style)
    glass.setImageFilter(skia.ImageFilters.Blur(size * 0.006, size * 0.006))

    body = skia.Path()
    body.moveTo(size * 0.34, size * 0.48)
    body.cubicTo(size * 0.31, size * 0.62, size * 0.28, size * 0.74, size * 0.34, size * 0.82)
    body.cubicTo(size * 0.40, size * 0.91, size * 0.60, size * 0.91, size * 0.66, size * 0.82)
    body.cubicTo(size * 0.72, size * 0.74, size * 0.69, size * 0.62, size * 0.66, size * 0.48)
    body.close()
    canvas.drawPath(body, glass)

    liquid = skia.Path()
    liquid.moveTo(size * 0.33, size * 0.68)
    liquid.cubicTo(size * 0.43, size * 0.64, size * 0.55, size * 0.72, size * 0.67, size * 0.67)
    liquid.lineTo(size * 0.66, size * 0.82)
    liquid.cubicTo(size * 0.60, size * 0.88, size * 0.40, size * 0.88, size * 0.34, size * 0.82)
    liquid.close()
    liquid_paint = skia.Paint(AntiAlias=True)
    liquid_paint.setShader(liquid_shader)
    liquid_paint.setImageFilter(skia.ImageFilters.Blur(size * 0.003, size * 0.003))
    canvas.drawPath(liquid, liquid_paint)

    liquid_noise_paint = skia.Paint(AntiAlias=True)
    liquid_noise_paint.setShader(noise)
    liquid_noise_paint.setAlphaf(0.12)
    canvas.drawPath(liquid, liquid_noise_paint)

    rim = skia.Paint(AntiAlias=True)
    rim.setColor(skia.ColorSetARGB(255, 196, 162, 89))
    rim.setStyle(skia.Paint.kStroke_Style)
    rim.setStrokeWidth(max(1.0, size * 0.018))
    rim_rect = skia.Rect.MakeXYWH(size * 0.41, size * 0.29, size * 0.18, size * 0.065)
    canvas.drawRRect(skia.RRect.MakeRectXY(rim_rect, size * 0.02, size * 0.02), rim)

    outline = skia.Paint(AntiAlias=True)
    outline.setColor(skia.ColorSetARGB(230, 190, 214, 204))
    outline.setStyle(skia.Paint.kStroke_Style)
    outline.setStrokeWidth(max(1.0, size * 0.012))
    canvas.drawPath(body, outline)

    glint = skia.Paint(AntiAlias=True)
    glint.setColor(skia.ColorSetARGB(210, 220, 238, 229))
    glint.setStrokeWidth(max(1.0, size * 0.018))
    canvas.drawLine(size * 0.38, size * 0.57, size * 0.38, size * 0.72, glint)

    image = surface.makeImageSnapshot()
    encoded = image.encodeToData()
    from io import BytesIO
    pil_image = Image.open(BytesIO(encoded.bytes())).convert("RGBA")
    return pil_image.resize((size, size), Image.Resampling.LANCZOS)


def parse_elements() -> list[tuple[str, str, str, str]]:
    source = (ROOT / "src" / "data" / "alchemyData.ts").read_text(encoding="utf-8")
    elements = []
    for block in re.findall(r"\{ id: .*? \}", source):
        element_id = re.search(r'id: "([^"]+)"', block)
        name = re.search(r'name: "([^"]+)"', block)
        symbol = re.search(r'symbol: "([^"]+)"', block)
        color = re.search(r'color: "(#[0-9a-fA-F]{6})"', block)
        if element_id and name and symbol and color:
            elements.append((element_id.group(1), name.group(1), symbol.group(1), color.group(1)))
    return elements


def category_for_element(element_id: str) -> str:
    if element_id in {"fire", "water", "earth", "air", "steam", "dust", "ash", "heat", "hot_charcoal"}:
        return "elements"
    if element_id in {"fertile_soil", "fertilizer", "sprout", "herbs", "wood", "resin", "charcoal", "canvas"}:
        return "plants"
    if element_id in {"stone", "sand", "salt", "clay", "ceramic", "lime", "plaster", "mortar", "ore", "metal", "alloy", "refined_metal", "glass", "quartz", "crystal", "cast_iron", "whetstone"}:
        return "minerals"
    if element_id in {"flask", "vial", "decoction", "mash", "spirit", "tincture", "balm", "essential_oil", "lye", "cleaning_solution", "tar", "lamp_oil", "soap", "ink", "essence", "panacea"}:
        return "alchemy"
    return "nature"


def hex_rgba(value: str, alpha: int = 255) -> skia.Color:
    value = value.lstrip("#")
    return skia.ColorSetARGB(alpha, int(value[0:2], 16), int(value[2:4], 16), int(value[4:6], 16))


def render_item_icon(element_id: str, name: str, symbol: str, color: str) -> Image.Image:
    size = ITEM_PIXEL_BASE_SIZE
    surface = skia.Surface(size, size)
    canvas = surface.getCanvas()
    canvas.clear(skia.ColorSetARGB(0, 0, 0, 0))

    base = hex_rgba(color)
    dark = skia.ColorSetARGB(255, max(20, (base >> 16) & 255) // 2,
                             max(20, (base >> 8) & 255) // 2,
                             max(20, base & 255) // 2)
    light = skia.ColorSetARGB(255, min(255, ((base >> 16) & 255) + 55),
                              min(255, ((base >> 8) & 255) + 55),
                              min(255, (base & 255) + 55))

    paint = skia.Paint(AntiAlias=False)
    category = category_for_element(element_id)
    seed = int(hashlib.sha1(element_id.encode("utf-8")).hexdigest()[:8], 16)

    paint.setColor(dark)
    canvas.drawRect(skia.Rect.MakeXYWH(4, 25, 24, 3), paint)

    if category == "elements":
        if element_id in {"fire", "heat", "hot_charcoal"}:
            path = skia.Path()
            path.moveTo(16, 27); path.cubicTo(7, 23, 8, 15, 14, 7)
            path.cubicTo(15, 13, 21, 13, 23, 7); path.cubicTo(27, 18, 23, 25, 16, 27); path.close()
            paint.setColor(base); canvas.drawPath(path, paint)
            paint.setColor(light); canvas.drawRect(skia.Rect.MakeXYWH(15, 16, 4, 8), paint)
        elif element_id in {"water", "steam", "ice", "spirit"}:
            path = skia.Path(); path.moveTo(16, 6); path.cubicTo(10, 13, 8, 18, 11, 23)
            path.cubicTo(14, 28, 22, 27, 24, 21); path.cubicTo(26, 15, 20, 10, 16, 6); path.close()
            paint.setColor(base); canvas.drawPath(path, paint)
            paint.setColor(light); canvas.drawRect(skia.Rect.MakeXYWH(11, 12, 3, 8), paint)
        elif element_id in {"earth", "mud", "dust", "ash"}:
            paint.setColor(base); canvas.drawRect(skia.Rect.MakeXYWH(7, 11, 18, 15), paint)
            paint.setColor(dark); canvas.drawRect(skia.Rect.MakeXYWH(11, 7, 12, 19), paint)
            paint.setColor(light); canvas.drawRect(skia.Rect.MakeXYWH(9, 13, 5, 5), paint)
        else:
            paint.setColor(base); canvas.drawCircle(16, 16, 9, paint)
            paint.setColor(light); canvas.drawCircle(12, 12, 3, paint)
    elif category == "plants":
        paint.setColor(dark); canvas.drawRect(skia.Rect.MakeXYWH(15, 12, 3, 16), paint)
        paint.setColor(base)
        canvas.drawCircle(11, 13, 7, paint); canvas.drawCircle(21, 10, 6, paint)
        paint.setColor(light); canvas.drawRect(skia.Rect.MakeXYWH(9, 10, 3, 3), paint)
    elif category == "minerals":
        paint.setColor(base)
        canvas.drawRect(skia.Rect.MakeXYWH(9, 10, 14, 15), paint)
        paint.setColor(dark); canvas.drawRect(skia.Rect.MakeXYWH(5, 14, 22, 11), paint)
        paint.setColor(light)
        canvas.drawRect(skia.Rect.MakeXYWH(11, 8, 5, 5), paint)
        canvas.drawRect(skia.Rect.MakeXYWH(19, 12, 3, 3), paint)
    elif category == "alchemy":
        paint.setColor(base); canvas.drawRect(skia.Rect.MakeXYWH(11, 7, 10, 5), paint)
        paint.setColor(light); canvas.drawRect(skia.Rect.MakeXYWH(13, 12, 6, 4), paint)
        paint.setColor(base)
        path = skia.Path(); path.moveTo(13, 16); path.lineTo(19, 16); path.lineTo(23, 24)
        path.lineTo(9, 24); path.close(); canvas.drawPath(path, paint)
        paint.setColor(dark); canvas.drawRect(skia.Rect.MakeXYWH(12, 22, 8, 3), paint)
    else:
        paint.setColor(base); canvas.drawCircle(16, 16, 10, paint)
        paint.setColor(dark); canvas.drawRect(skia.Rect.MakeXYWH(7, 14, 18, 4), paint)
        paint.setColor(light); canvas.drawRect(skia.Rect.MakeXYWH(11, 10, 4, 4), paint)

    variant = seed % 4
    paint.setColor(light)
    if variant == 0:
        canvas.drawRect(skia.Rect.MakeXYWH(5, 5, 2, 2), paint)
    elif variant == 1:
        canvas.drawRect(skia.Rect.MakeXYWH(24, 7, 2, 2), paint)
    elif variant == 2:
        canvas.drawRect(skia.Rect.MakeXYWH(26, 24, 2, 2), paint)
    else:
        canvas.drawRect(skia.Rect.MakeXYWH(5, 23, 2, 2), paint)

    image = surface.makeImageSnapshot()
    encoded = image.encodeToData()
    from io import BytesIO
    pil_image = Image.open(BytesIO(encoded.bytes())).convert("RGBA")
    return pil_image.resize((ITEM_ICON_SIZE, ITEM_ICON_SIZE), Image.Resampling.NEAREST)


def render_item_icon_improved(element_id: str, name: str, symbol: str, color: str) -> Image.Image:
    size = ITEM_ICON_SIZE
    surface = skia.Surface(size, size)
    canvas = surface.getCanvas()
    canvas.clear(skia.ColorSetARGB(0, 0, 0, 0))

    base = hex_rgba(color)
    dark = skia.ColorSetARGB(255,
                             max(12, (base >> 16 & 255) * 58 // 100),
                             max(12, (base >> 8 & 255) * 58 // 100),
                             max(12, (base & 255) * 58 // 100))
    light = skia.ColorSetARGB(255,
                              min(255, (base >> 16 & 255) + 58),
                              min(255, (base >> 8 & 255) + 58),
                              min(255, (base & 255) + 58))

    outline = skia.Paint(AntiAlias=False)
    outline.setStyle(skia.Paint.kStroke_Style)
    outline.setStrokeWidth(3)
    outline.setColor(dark)
    solid = skia.Paint(AntiAlias=False)
    solid.setStyle(skia.Paint.kFill_Style)
    solid.setColor(base)
    highlight = skia.Paint(AntiAlias=False)
    highlight.setStyle(skia.Paint.kFill_Style)
    highlight.setColor(light)

    if element_id in {"fire", "heat", "hot_charcoal"}:
        path = skia.Path(); path.moveTo(32, 6); path.cubicTo(34, 22, 50, 24, 47, 43)
        path.cubicTo(44, 58, 18, 58, 13, 43); path.cubicTo(8, 28, 24, 25, 32, 6); path.close()
        canvas.drawPath(path, solid); canvas.drawPath(path, outline)
        canvas.drawRect(skia.Rect.MakeXYWH(27, 30, 8, 22), highlight)
    elif element_id in {"water", "steam", "ice", "spirit"}:
        path = skia.Path(); path.moveTo(32, 7); path.cubicTo(20, 22, 12, 35, 15, 47)
        path.cubicTo(18, 59, 46, 59, 49, 46); path.cubicTo(52, 34, 44, 22, 32, 7); path.close()
        canvas.drawPath(path, solid); canvas.drawPath(path, outline)
        canvas.drawRect(skia.Rect.MakeXYWH(23, 20, 7, 18), highlight)
    elif element_id in {"earth", "mud", "fertile_soil", "sand", "dust", "ash"}:
        canvas.drawRect(skia.Rect.MakeXYWH(10, 24, 44, 28), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(16, 18, 32, 12), highlight)
        canvas.drawRect(skia.Rect.MakeXYWH(10, 24, 44, 28), outline)
        canvas.drawRect(skia.Rect.MakeXYWH(20, 34, 8, 6), outline)
        canvas.drawRect(skia.Rect.MakeXYWH(40, 38, 7, 5), outline)
    elif element_id in {"stone", "salt", "sand", "lime", "quartz", "crystal", "ore", "whetstone"}:
        path = skia.Path(); path.moveTo(16, 18); path.lineTo(38, 10); path.lineTo(54, 25)
        path.lineTo(49, 51); path.lineTo(22, 56); path.lineTo(8, 41); path.close()
        canvas.drawPath(path, solid); canvas.drawPath(path, outline)
        canvas.drawRect(skia.Rect.MakeXYWH(20, 21, 10, 9), highlight)
        canvas.drawRect(skia.Rect.MakeXYWH(38, 36, 7, 6), outline)
    elif element_id in {"sprout", "fertilizer", "herbs", "wood", "resin", "charcoal", "canvas", "fertile_soil"}:
        canvas.drawRect(skia.Rect.MakeXYWH(30, 24, 7, 33), outline)
        canvas.drawRect(skia.Rect.MakeXYWH(11, 16, 24, 16), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(34, 10, 20, 22), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(14, 20, 8, 7), highlight)
        canvas.drawRect(skia.Rect.MakeXYWH(38, 14, 7, 8), highlight)
    elif element_id in {"flask", "vial", "glass", "spirit", "tincture", "balm", "decoction", "essence", "panacea", "lamp_oil"}:
        canvas.drawRect(skia.Rect.MakeXYWH(25, 7, 14, 8), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(29, 15, 6, 12), outline)
        path = skia.Path(); path.moveTo(20, 26); path.lineTo(44, 26); path.lineTo(51, 48)
        path.lineTo(43, 57); path.lineTo(21, 57); path.lineTo(13, 48); path.close()
        canvas.drawPath(path, solid); canvas.drawPath(path, outline)
        canvas.drawRect(skia.Rect.MakeXYWH(21, 38, 22, 12), highlight)
    elif element_id in {"metal", "alloy", "refined_metal", "cast_iron", "ore", "whetstone"}:
        canvas.drawRect(skia.Rect.MakeXYWH(10, 18, 44, 34), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(17, 10, 30, 12), outline)
        canvas.drawRect(skia.Rect.MakeXYWH(10, 18, 44, 34), outline)
        canvas.drawRect(skia.Rect.MakeXYWH(16, 23, 10, 7), highlight)
        canvas.drawRect(skia.Rect.MakeXYWH(38, 39, 8, 5), outline)
    elif category_for_element(element_id) == "plants":
        canvas.drawRect(skia.Rect.MakeXYWH(29, 28, 7, 25), outline)
        canvas.drawRect(skia.Rect.MakeXYWH(13, 20, 20, 16), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(34, 13, 18, 18), solid)
    elif category_for_element(element_id) == "alchemy":
        canvas.drawRect(skia.Rect.MakeXYWH(24, 8, 16, 7), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(28, 15, 8, 14), highlight)
        canvas.drawRect(skia.Rect.MakeXYWH(16, 29, 32, 24), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(16, 29, 32, 24), outline)
    else:
        seed = int(hashlib.sha1(element_id.encode("utf-8")).hexdigest()[:8], 16)
        canvas.drawRect(skia.Rect.MakeXYWH(10 + seed % 6, 10 + seed % 8, 44 - seed % 8, 40), solid)
        canvas.drawRect(skia.Rect.MakeXYWH(16, 16, 12, 10), highlight)
        canvas.drawRect(skia.Rect.MakeXYWH(10 + seed % 6, 10 + seed % 8, 44 - seed % 8, 40), outline)

    seed = int(hashlib.sha1(element_id.encode("utf-8")).hexdigest()[:8], 16)
    canvas.drawRect(skia.Rect.MakeXYWH(6, 6 + seed % 5, 3, 3), highlight)
    canvas.drawRect(skia.Rect.MakeXYWH(55 - seed % 5, 49, 3, 3), outline)

    encoded = surface.makeImageSnapshot().encodeToData()
    from io import BytesIO
    pil_image = Image.open(BytesIO(encoded.bytes())).convert("RGBA")
    return pil_image.resize((ITEM_ICON_SIZE, ITEM_ICON_SIZE), Image.Resampling.NEAREST)


def generate_item_icons():
    items_dir = ASSETS / "items"
    items_dir.mkdir(parents=True, exist_ok=True)
    elements = parse_elements()
    for element_id, name, symbol, color in elements:
        render_item_icon_improved(element_id, name, symbol, color).save(items_dir / f"{element_id}.png", format="PNG", optimize=True)
    print(f"Generated {len(elements)} unique 64px pixel-art item icons (32px source).")


def normalize_stereo(signal: np.ndarray) -> np.ndarray:
    if signal.ndim == 1:
        signal = np.stack([signal, signal], axis=-1)
    peak = float(np.max(np.abs(signal)))
    if peak > 0:
        signal = signal * (0.92 / peak)
    return np.clip(signal, -1.0, 1.0).astype(np.float32)


def adsr(length: int, attack: float, decay: float, sustain: float, release: float) -> np.ndarray:
    envelope = np.ones(length, dtype=np.float64)
    attack_n = min(length, int(length * attack))
    decay_n = min(length - attack_n, int(length * decay))
    release_n = min(length - attack_n - decay_n, int(length * release))
    sustain_n = length - attack_n - decay_n - release_n
    envelope[:attack_n] = np.linspace(0.0, 1.0, attack_n)
    envelope[attack_n:attack_n + decay_n] = np.linspace(1.0, sustain, decay_n)
    envelope[attack_n + decay_n:attack_n + decay_n + sustain_n] = sustain
    if release_n:
        envelope[-release_n:] = np.linspace(sustain, 0.0, release_n)
    return envelope


def low_pass(signal: np.ndarray, cutoff: float) -> np.ndarray:
    alpha = 2.0 * np.pi * cutoff / SAMPLE_RATE
    alpha = alpha / (1.0 + alpha)
    result = np.empty_like(signal)
    result[0] = signal[0]
    for i in range(1, len(signal)):
        result[i] = result[i - 1] + alpha * (signal[i] - result[i - 1])
    return result


def add_metal_ring(time: np.ndarray, fundamental: float, level: float = 1.0) -> np.ndarray:
    ring = np.zeros_like(time)
    for overtone, amplitude in [(1.0, 1.0), (2.71, 0.48), (4.13, 0.28), (5.72, 0.16)]:
        modulation = 0.008 * np.sin(2 * np.pi * (fundamental * 0.37) * time)
        ring += amplitude * np.sin(2 * np.pi * fundamental * overtone * time + modulation)
    ring *= level * adsr(len(time), 0.003, 0.13, 0.22, 0.84)
    return ring


def fm_tone(time: np.ndarray, carrier: float, ratio: float, index: float, envelope: np.ndarray) -> np.ndarray:
    modulator = np.sin(2 * np.pi * carrier * ratio * time)
    return envelope * np.sin(2 * np.pi * carrier * time + index * modulator)


def write_wav(name: str, mono: np.ndarray) -> None:
    sf.write(SFX / name, normalize_stereo(mono), SAMPLE_RATE, subtype="PCM_16")


def generate_sounds():
    rng = np.random.default_rng(1948)

    t = np.arange(SAMPLE_RATE, dtype=np.float64) / SAMPLE_RATE
    impact = fm_tone(t, 74, 1.85, 4.2, adsr(len(t), 0.002, 0.10, 0.12, 0.88))
    wood = low_pass(rng.uniform(-1, 1, len(t)) * adsr(len(t), 0.001, 0.025, 0.05, 0.92), 920)
    wood *= 0.18
    pickup = impact * 0.60 + wood + add_metal_ring(t, 612, 0.30)
    write_wav("pickup.wav", pickup)

    t = np.arange(SAMPLE_RATE, dtype=np.float64) / SAMPLE_RATE
    hum = fm_tone(t, 48, 0.51, 1.7, adsr(len(t), 0.24, 0.12, 0.42, 0.24))
    harmonics = sum((np.sin(2 * np.pi * 48 * overtone * t + 0.37 * overtone) * level
                     for overtone, level in [(1, 0.48), (1.5, 0.22), (2.02, 0.11), (3.04, 0.06)]),
                    np.zeros_like(t))
    hover = low_pass(hum * 0.7 + harmonics * adsr(len(t), 0.16, 0.18, 0.32, 0.34), 1800)
    write_wav("hover_link.wav", hover)

    t = np.arange(round(SAMPLE_RATE * 1.8), dtype=np.float64) / SAMPLE_RATE
    bass = fm_tone(t, 58, 1.0, 2.8, adsr(len(t), 0.008, 0.18, 0.20, 0.68))
    glass = add_metal_ring(t, 710, 0.38)
    hiss = low_pass(rng.uniform(-1, 1, len(t)) * adsr(len(t), 0.03, 0.18, 0.10, 0.70), 4200)
    success = bass * 0.85 + glass + hiss * 0.16
    write_wav("craft_success.wav", success)

    t = np.arange(round(SAMPLE_RATE * 0.32), dtype=np.float64) / SAMPLE_RATE
    soft_click = fm_tone(t, 96, 2.35, 3.6, adsr(len(t), 0.002, 0.02, 0.03, 0.96))
    dull = low_pass(rng.uniform(-1, 1, len(t)) * adsr(len(t), 0.001, 0.035, 0.02, 0.94), 520)
    write_wav("craft_fail.wav", soft_click * 0.24 + dull * 0.08)

    def combo_tones(name: str, multiplier: int):
        duration = 1.35 if multiplier == 2 else 1.55
        base = np.arange(round(SAMPLE_RATE * duration), dtype=np.float64) / SAMPLE_RATE
        frequencies = [392, 523, 659] if multiplier == 2 else [392, 466, 587, 784]
        chord = np.zeros_like(base)
        for index, frequency in enumerate(frequencies):
            start = index * 0.10
            segment = np.maximum(0.0, base - start)
            local_env = adsr(len(segment), 0.006, 0.16, 0.38, 0.60)
            local_env[:min(len(segment), int(start * SAMPLE_RATE))] = 0
            tone = fm_tone(segment, frequency, 2.02, 1.25, local_env)
            chord += tone * (0.24 if index else 0.32)
        chord = librosa.effects.pitch_shift(chord, sr=SAMPLE_RATE, n_steps=multiplier - 1)
        write_wav(name, chord)

    combo_tones("combo_x2.wav", 2)
    combo_tones("combo_x3.wav", 3)

    t = np.arange(round(SAMPLE_RATE * 2.4), dtype=np.float64) / SAMPLE_RATE
    bell = add_metal_ring(t, 92, 0.72)
    scroll = low_pass(rng.uniform(-1, 1, len(t)) * adsr(len(t), 0.08, 0.32, 0.08, 0.55), 2600)
    scroll = scroll * librosa.effects.harmonic(scroll, margin=2.0) * 0.12
    quest = bell + scroll
    write_wav("quest_complete.wav", quest)


def generate_icons():
    flask = render_flask(512)
    flask.save(ASSETS / "flask_logo.png", format="PNG", optimize=True)

    icon_512 = flask.resize((512, 512), Image.Resampling.LANCZOS)
    icon_512.save(PUBLIC / "icon-512.png", format="PNG", optimize=True)

    ico = Image.new("RGBA", (256, 256), (16, 14, 18, 255))
    ico.alpha_composite(flask.resize((256, 256), Image.Resampling.LANCZOS), (0, 0))
    ico.save(PUBLIC / "favicon.ico", format="ICO", sizes=[(16, 16), (32, 32), (64, 64), (256, 256)])


def main():
    ensure_dirs()
    generate_icons()
    generate_item_icons()
    generate_sounds()
    print("Generated Ashbound Alchemy icons and procedural WAV assets.")


if __name__ == "__main__":
    main()
