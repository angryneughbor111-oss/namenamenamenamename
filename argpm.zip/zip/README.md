# Ashbound Alchemy

Браузерный прототип алхимического крафта на PixiJS v8.

## Генерация ассетов в Windows

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python tools/generate_assets.py
```

## Установка и сборка веб-клиента

```powershell
npm install
npm run build
npm run dev
```

Для локального запуска достаточно открыть запущенный Vite-адрес. Собранный каталог `dist` работает относительно подкаталога портала при наличии обязательных ассетов в `public/assets`.

## Desktop-проверка Windows через PyInstaller

```powershell
.venv\Scripts\activate
pip install -r requirements.txt
npm install
npm run desktop:build
```

Готовая one-dir-сборка создаётся в `dist-desktop/AshboundAlchemy`. Запускайте:

```powershell
.\dist-desktop\AshboundAlchemy\AshboundAlchemy.exe
```

EXE запускает локальный HTTP-сервер для готового `dist`, открывает системный браузер и показывает компактное окно управления сервером. Для портативного запуска не требуется Node.js или запущенный Vite-сервер.

Y8 SDK загружается извне по HTTPS. При отсутствии сети, блокировке рекламы или недоступности SDK игра продолжает работать без рекламы и предлагает офлайн-подсказку и кулдаун.
