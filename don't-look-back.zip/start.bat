@echo off
chcp 65001 >nul
title DON'T LOOK BACK - Запуск
cls
echo ===================================================
echo   DON'T LOOK BACK - PS1 3D Horror Game
echo ===================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
  echo [ОШИБКА] Node.js не найден на этом компьютере.
  echo.
  echo Чтобы играть без установки программ, откройте онлайн:
  echo https://ais-pre-qpa2g6mp7dftdiiphduxv7-335126092557.europe-west2.run.app
  echo.
  echo Либо установите Node.js с официального сайта: https://nodejs.org
  echo.
  pause
  exit /b 1
)

if not exist "node_modules\" (
  echo Установка необходимых модулей (только при первом запуске)...
  call npm install
)

echo.
echo Запуск локального сервера...
echo Открываем http://localhost:3000 в браузере...
start http://localhost:3000
call npm run dev
pause
