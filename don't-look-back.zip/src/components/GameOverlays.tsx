/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useState } from 'react';
import type { HudSnapshot } from '../game/types';

interface GameOverlaysProps {
  hud: HudSnapshot;
  contextLost: boolean;
  onToggleMute: () => void;
  onStart: () => void;
  onResume: () => void;
  onMainMenu: () => void;
}

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function GameOverlays({
  hud,
  contextLost,
  onToggleMute,
  onStart,
  onResume,
  onMainMenu,
}: GameOverlaysProps) {
  const [isInitializing, setIsInitializing] = useState(false);
  const [initProgress, setInitProgress] = useState(0);
  const [initLog, setInitLog] = useState('');

  // Handle stylized loading progress bar when user clicks Start Game
  useEffect(() => {
    if (!isInitializing) return;

    let current = 0;
    const interval = setInterval(() => {
      // Step increment with realistic pauses
      const delta = Math.floor(Math.random() * 9) + 4;
      current = Math.min(100, current + delta);
      setInitProgress(current);

      if (current < 25) {
        setInitLog('[01/05] ПОДКЛЮЧЕНИЕ К СЕТИ MAWRG ENTERPRISES...');
      } else if (current < 50) {
        setInitLog('[02/05] СКАНИРОВАНИЕ БИОМЕТРИИ И ДОСТУПА В ОФИС...');
      } else if (current < 75) {
        setInitLog('[03/05] ВНИМАНИЕ: ДИЗЕЛЬ-ГЕНЕРАТОР В ПОДВАЛЕ ОБЕСТОЧЕН!');
      } else if (current < 95) {
        setInitLog('[04/05] ТРЕВОГА: ОБЪЕКТ MAWRG АКТИВИРОВАН В КОРИДОРАХ...');
      } else {
        setInitLog('[05/05] ДОСТУП РАЗРЕШЕН. ВХОД В КОМПЛЕКС...');
      }

      if (current >= 100) {
        clearInterval(interval);
        setTimeout(() => {
          setIsInitializing(false);
          setInitProgress(0);
          onStart();
        }, 320);
      }
    }, 75);

    return () => clearInterval(interval);
  }, [isInitializing, onStart]);

  if (contextLost) {
    return (
      <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/95 p-6">
        <div className="max-w-md w-full border border-zinc-800 bg-zinc-950 p-6 text-center">
          <h2 className="font-display text-3xl font-bold tracking-wide text-zinc-100">
            Сбой графического контекста
          </h2>
          <p className="mt-2 text-sm text-zinc-400">
            3D-визуализация была временно приостановлена браузером.
          </p>
          <button
            type="button"
            onClick={() => window.location.reload()}
            className="mt-5 px-6 py-2.5 bg-red-800 hover:bg-red-700 text-white text-sm font-medium transition-colors cursor-pointer"
          >
            Перезагрузить страницу
          </button>
        </div>
      </div>
    );
  }

  if (hud.phase === 'title') {
    return (
      <div className="fixed inset-0 z-20 flex flex-col justify-between pointer-events-auto">
        <div className="absolute inset-0 ps1-scanlines opacity-35 pointer-events-none" />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'linear-gradient(90deg, rgba(5,6,8,0.94) 0%, rgba(5,6,8,0.80) 52%, rgba(5,6,8,0.35) 100%)',
          }}
        />

        {/* Stylized Loading / Initializing Screen Modal */}
        {isInitializing && (
          <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/90 p-6">
            <div className="max-w-xl w-full border border-amber-800/80 bg-zinc-950/95 p-8 shadow-[0_0_50px_rgba(245,158,11,0.2)]">
              <div className="flex items-center justify-between border-b border-amber-900/40 pb-3 mb-6">
                <span className="font-mono text-xs tracking-widest text-amber-500 font-bold uppercase">
                  [СИСТЕМНАЯ ЗАГРУЗКА ОБЪЕКТА]
                </span>
                <span className="font-mono text-xs text-amber-400">
                  ПРОТОКОЛ: 0x7F-MAWRG
                </span>
              </div>

              {/* Progress percentage display */}
              <div className="flex items-baseline justify-between mb-2">
                <span className="font-mono text-sm tracking-wide text-zinc-300">
                  {initLog}
                </span>
                <span className="font-mono text-2xl font-bold text-amber-400">
                  {initProgress}%
                </span>
              </div>

              {/* Graphical Segmented Progress Bar */}
              <div className="w-full h-5 bg-zinc-900 border border-amber-700/60 p-0.5 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-600 via-amber-500 to-red-600 transition-all duration-75 ease-out shadow-[0_0_12px_rgba(245,158,11,0.6)]"
                  style={{ width: `${initProgress}%` }}
                />
              </div>

              {/* Diagnostic Terminal Feed */}
              <div className="mt-5 bg-black/80 border border-zinc-900 p-3 font-mono text-[11px] text-zinc-500 space-y-1">
                <div>&gt; AUTH_KEY: VERIFIED (LEVEL 3 CLEARANCE)</div>
                <div>&gt; FACILITY_GRID: SUBSURFACE TECHNICAL SECTOR B</div>
                <div>&gt; EMERGENCY_GENERATOR: OFFLINE [FUSES REQUIRED: 3]</div>
                {initProgress > 60 && (
                  <div className="text-red-400 font-bold">
                    &gt; ВНИМАНИЕ: СУБЪЕКТ MAWRG СВОБОДЕН В КОМПЛЕКСЕ
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="relative z-10 flex-1 flex items-center px-8 md:px-16">
          <div className="max-w-xl w-full">
            {/* Retro Antagonist Security Monitor */}
            <div className="mb-6 inline-flex items-center gap-4 border border-red-900/50 bg-zinc-950/90 px-4 py-2.5 shadow-[0_0_30px_rgba(220,38,38,0.2)]">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-ping" />
                <span className="w-2.5 h-2.5 bg-red-600 rounded-full" />
              </div>
              <div className="flex flex-col">
                <span className="font-mono text-[11px] font-bold tracking-widest text-red-400 uppercase">
                  СУБЪЕКТ: MAWRG // УГРОЗА КЛАССА А
                </span>
                <span className="font-mono text-[9px] text-zinc-500 uppercase">
                  КАМЕРЫ 01-09: ПОТЕРЯ СИГНАЛА
                </span>
              </div>
            </div>

            <h1 className="font-display text-4xl md:text-5xl font-extrabold tracking-tight text-zinc-100 leading-[1.05]">
              MAWRG&apos;S OFFICE: HORROR ESCAPE
            </h1>

            <p className="mt-4 text-sm md:text-base text-zinc-300 leading-relaxed">
              Вы заперты в офисном комплексе и подвальных лабораториях Mawrg Enterprises. Найдите 3 предохранителя, запустите дизельный генератор в подвале, перекусите сигнализацию кусачками, разбейте доски молотком и заберите ключ безопасности, чтобы сбежать через гермошлюз.
            </p>

            <div className="mt-7 flex items-center gap-4">
              <button
                type="button"
                data-start="true"
                onClick={() => setIsInitializing(true)}
                className="px-8 py-3.5 bg-red-800 hover:bg-red-700 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-red-400 text-white text-sm font-bold tracking-wider uppercase transition-colors cursor-pointer shadow-[0_0_20px_rgba(220,38,38,0.35)]"
              >
                ИНИЦИИРОВАТЬ ВХОД
              </button>
            </div>
          </div>
        </div>

        <footer className="relative z-10 px-8 md:px-16 pb-6">
          <p className="text-xs text-zinc-400 tracking-wide">
            Управление: WASD — Ходьба · Мышь — Обзор · Shift — Бег · Ctrl / C — Присесть · E — Действие · F — Фонарик · Esc — Пауза
          </p>
        </footer>
      </div>
    );
  }

  if (hud.phase === 'paused') {
    return (
      <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/75 p-6 pointer-events-auto">
        <div
          className="max-w-md w-full border border-zinc-800 p-6"
          style={{ backgroundColor: 'rgba(10, 12, 16, 0.96)' }}
        >
          <h2 className="font-display text-3xl font-bold tracking-wide text-zinc-100">
            ПАУЗА
          </h2>

          <div className="mt-5 flex flex-col gap-2.5">
            <button
              type="button"
              onClick={onResume}
              className="w-full py-2.5 bg-zinc-100 hover:bg-white text-zinc-950 text-sm font-semibold transition-colors cursor-pointer"
            >
              Продолжить
            </button>
            <button
              type="button"
              onClick={onToggleMute}
              className="w-full py-2.5 border border-zinc-700 hover:border-zinc-500 text-zinc-200 text-sm font-medium transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{hud.muted ? '🔇 Звук: Выключен' : '🔊 Звук: Включен'}</span>
            </button>
            <button
              type="button"
              onClick={onStart}
              className="w-full py-2.5 border border-zinc-700 hover:border-zinc-500 text-zinc-200 text-sm font-medium transition-colors cursor-pointer"
            >
              Начать заново
            </button>
            <button
              type="button"
              onClick={onMainMenu}
              className="w-full py-2.5 border border-zinc-800 hover:border-zinc-600 text-zinc-400 hover:text-zinc-200 text-sm font-medium transition-colors cursor-pointer"
            >
              Главное меню
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (hud.phase === 'defeat') {
    const fusesFound = hud.fusesCarried + hud.fusesInstalled;
    return (
      <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/80 p-6 pointer-events-auto">
        <div
          className="max-w-md w-full border border-red-900/60 p-7"
          style={{ backgroundColor: 'rgba(12, 8, 10, 0.96)' }}
        >
          <h2 className="font-display text-5xl font-bold tracking-tight text-red-500">
            ВЫ ПОГИБЛИ
          </h2>
          <p className="mt-2 text-sm text-zinc-300">
            Существо настигло вас в темноте офиса.
          </p>

          <div className="mt-6 grid grid-cols-3 gap-3 border-y border-zinc-800/90 py-4 text-left">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-zinc-500">Время</div>
              <div className="mt-1 font-mono-tabular text-lg font-semibold text-zinc-100">
                {formatTime(hud.elapsedSeconds)}
              </div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-zinc-500">Предохр.</div>
              <div className="mt-1 font-mono-tabular text-lg font-semibold text-zinc-100">
                {fusesFound}/{hud.totalFuses}
              </div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-zinc-500">Питание</div>
              <div className="mt-1 text-sm font-semibold text-zinc-200">
                {hud.powerRestored ? 'В норме' : 'Отключено'}
              </div>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              type="button"
              data-start="true"
              onClick={onStart}
              className="flex-1 py-3 bg-red-800 hover:bg-red-700 text-white text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Попробовать снова
            </button>
            <button
              type="button"
              onClick={onMainMenu}
              className="px-5 py-3 border border-zinc-800 hover:border-zinc-600 text-zinc-300 text-sm font-medium transition-colors cursor-pointer"
            >
              Главное меню
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (hud.phase === 'victory') {
    return (
      <div className="fixed inset-0 z-20 flex items-center justify-center bg-black/80 p-6 pointer-events-auto">
        <div
          className="max-w-md w-full border border-emerald-900/60 p-7"
          style={{ backgroundColor: 'rgba(8, 12, 11, 0.96)' }}
        >
          <h2 className="font-display text-5xl font-bold tracking-tight text-emerald-400">
            ПОБЕГ УДАЛСЯ!
          </h2>
          <p className="mt-2 text-sm text-zinc-300">
            Вы обесточили сигнализацию, разбили доски молотком и выбрались на поверхность.
          </p>

          <div className="mt-6 grid grid-cols-3 gap-3 border-y border-zinc-800/90 py-4 text-left">
            <div>
              <div className="text-[11px] uppercase tracking-wider text-zinc-500">Время</div>
              <div className="mt-1 font-mono-tabular text-lg font-semibold text-zinc-100">
                {formatTime(hud.elapsedSeconds)}
              </div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-zinc-500">Предохр.</div>
              <div className="mt-1 font-mono-tabular text-lg font-semibold text-zinc-100">
                {hud.fusesInstalled}/{hud.totalFuses}
              </div>
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-wider text-zinc-500">Батарея</div>
              <div className="mt-1 font-mono-tabular text-lg font-semibold text-zinc-100">
                {hud.battery}%
              </div>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              type="button"
              data-start="true"
              onClick={onStart}
              className="flex-1 py-3 bg-emerald-700 hover:bg-emerald-600 text-white text-sm font-semibold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Играть снова
            </button>
            <button
              type="button"
              onClick={onMainMenu}
              className="px-5 py-3 border border-zinc-800 hover:border-zinc-600 text-zinc-300 text-sm font-medium transition-colors cursor-pointer"
            >
              Главное меню
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
}
