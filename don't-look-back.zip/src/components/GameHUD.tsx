import type { HudSnapshot, InventoryItemType } from '../game/types';

interface GameHUDProps {
  hud: HudSnapshot;
  onPause: () => void;
  onSelectSlot?: (index: number) => void;
}

function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

function getItemInfo(type: InventoryItemType | null): { name: string; icon: string; color: string } {
  switch (type) {
    case 'hammer':
      return { name: 'Молоток', icon: '🔨', color: 'text-amber-400 border-amber-500' };
    case 'wire_cutters':
      return { name: 'Кусачки', icon: '✂', color: 'text-red-400 border-red-500' };
    case 'exit_key':
      return { name: 'Ключ', icon: '🔑', color: 'text-yellow-400 border-yellow-500' };
    case 'nvg':
      return { name: 'ПНВ', icon: '🥽', color: 'text-emerald-400 border-emerald-500' };
    default:
      return { name: 'Пусто', icon: '—', color: 'text-zinc-600 border-zinc-800' };
  }
}

export function GameHUD({ hud, onPause }: GameHUDProps) {
  if (hud.phase !== 'playing') return null;

  const totalFound = hud.fusesCarried + hud.fusesInstalled;

  // Circular gauge math (radius 22, circumference ~138.2)
  const radius = 22;
  const circumference = 2 * Math.PI * radius;
  const flashOffset = circumference - (hud.battery / 100) * circumference;
  const nvgOffset = circumference - (hud.nvgBattery / 100) * circumference;

  const flashColor =
    hud.battery <= 20 ? '#ef4444' : hud.battery <= 45 ? '#f59e0b' : '#38bdf8';

  return (
    <div className="fixed inset-0 z-10 pointer-events-none select-none">
      {/* Subtle PS1 scanline texture */}
      <div className="absolute inset-0 ps1-scanlines opacity-25" />

      {/* Danger Vignette */}
      <div
        className="absolute inset-0 transition-opacity duration-200"
        style={{
          opacity: hud.dangerLevel > 0.12 ? hud.dangerLevel * 0.72 : 0.25,
          background:
            hud.dangerLevel > 0.12
              ? 'radial-gradient(circle at 50% 50%, rgba(0,0,0,0) 45%, rgba(127, 29, 29, 0.78) 100%)'
              : 'radial-gradient(circle at 50% 50%, rgba(0,0,0,0) 58%, rgba(0, 0, 0, 0.7) 100%)',
        }}
      />

      {/* NVG Night Vision Phosphor Filter Overlay */}
      {hud.nvgOn && (
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.08) 0%, rgba(6, 78, 59, 0.38) 80%, rgba(0, 0, 0, 0.85) 100%)',
          }}
        >
          {/* Night Vision phosphor grain & tactical indicators */}
          <div className="absolute inset-0 bg-emerald-500/10 mix-blend-overlay" />
          <div className="absolute top-5 left-1/2 -translate-x-1/2 px-4 py-1 bg-black/80 border border-emerald-500/60 font-mono text-[11px] font-bold tracking-widest text-emerald-400">
            [ПНВ АКТИВЕН // ЗАРЯД: {hud.nvgBattery}%]
          </div>
          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 flex items-center gap-6 font-mono text-[10px] text-emerald-500/80">
            <span>ISO 12800</span>
            <span>IR-ILLUM: AUTO</span>
            <span>AMP: ACTIVE</span>
          </div>
        </div>
      )}

      {/* Top-Left: Location, Objective & Fuse Row */}
      <div className="absolute top-5 left-5 flex flex-col gap-2.5 max-w-xs">
        <div
          className="px-3.5 py-2.5 border border-zinc-800/90"
          style={{ backgroundColor: 'rgba(8, 10, 13, 0.84)' }}
        >
          <div className="flex items-center justify-between gap-4 text-[11px] uppercase tracking-wider text-zinc-400">
            <span>{hud.roomName}</span>
            <span className="font-mono-tabular text-zinc-500">
              {formatTime(hud.elapsedSeconds)}
            </span>
          </div>
          <p className="mt-1 text-sm font-semibold text-zinc-100 leading-snug">
            {hud.objective}
          </p>

          {/* Fuse Indicator */}
          <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center gap-3 text-xs">
            <span className="text-zinc-400">Предохранители:</span>
            <div className="flex items-center gap-1.5">
              {Array.from({ length: hud.totalFuses }).map((_, idx) => {
                const isInstalled = idx < hud.fusesInstalled;
                const isCarried = !isInstalled && idx < totalFound;
                return (
                  <svg key={idx} viewBox="0 0 24 14" className="w-4 h-2.5" aria-hidden="true">
                    <rect
                      x="1"
                      y="2"
                      width="22"
                      height="10"
                      rx="2"
                      fill={isInstalled ? '#10b981' : isCarried ? '#d97706' : '#18181b'}
                      stroke={isInstalled ? '#34d399' : isCarried ? '#f59e0b' : '#3f3f46'}
                      strokeWidth="1.5"
                    />
                    <rect x="0" y="4" width="3" height="6" fill="#71717a" />
                    <rect x="21" y="4" width="3" height="6" fill="#71717a" />
                  </svg>
                );
              })}
              <span className="font-mono-tabular text-zinc-300 ml-1 font-bold">
                {totalFound}/{hud.totalFuses}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Top-Right: Pause Button */}
      <div className="absolute top-5 right-5 flex items-center gap-2 pointer-events-auto">
        <button
          type="button"
          tabIndex={-1}
          onClick={(e) => {
            e.currentTarget.blur();
            onPause();
          }}
          aria-label="Pause game"
          title="Пауза (P / Esc)"
          className="w-10 h-10 flex items-center justify-center border border-zinc-800 text-zinc-300 hover:text-white hover:border-zinc-600 transition-colors cursor-pointer"
          style={{ backgroundColor: 'rgba(8, 10, 13, 0.84)' }}
        >
          <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor">
            <rect x="6" y="5" width="4" height="14" />
            <rect x="14" y="5" width="4" height="14" />
          </svg>
        </button>
      </div>

      {/* Top-Center: Transient Status Banner */}
      {hud.statusBanner && (
        <div className="absolute top-6 left-1/2 -translate-x-1/2">
          <div
            className="px-4 py-1.5 border border-zinc-700/80 text-xs font-semibold tracking-wide text-zinc-100 whitespace-nowrap shadow-[0_0_15px_rgba(0,0,0,0.6)]"
            style={{ backgroundColor: 'rgba(10, 12, 16, 0.92)' }}
          >
            {hud.statusBanner}
          </div>
        </div>
      )}

      {/* Center Crosshair & Prompt */}
      <div className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex flex-col items-center">
        <div
          className={`w-1.5 h-1.5 rounded-full transition-transform duration-150 ${
            hud.promptText ? 'bg-amber-400 scale-150' : 'bg-zinc-200/75'
          }`}
        />
        {hud.promptText && (
          <div
            className="mt-4 px-3 py-1.5 border border-zinc-700/85 text-center whitespace-nowrap shadow-[0_0_20px_rgba(0,0,0,0.8)]"
            style={{ backgroundColor: 'rgba(8, 10, 13, 0.92)' }}
          >
            <div className="text-xs font-bold text-amber-300 tracking-wide">
              {hud.promptText}
            </div>
            {hud.promptSubtext && (
              <div className="text-[11px] text-zinc-400 mt-0.5">{hud.promptSubtext}</div>
            )}
          </div>
        )}
      </div>

      {/* Bottom-Center: 3-Slot Inventory Bar */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1.5 pointer-events-auto">
        <div className="flex items-center gap-2">
          {hud.inventory.map((item, idx) => {
            const isActive = idx === hud.activeSlotIndex;
            const info = getItemInfo(item);
            return (
              <div
                key={idx}
                className={`w-20 h-16 border flex flex-col items-center justify-between p-1.5 transition-all ${
                  isActive
                    ? 'border-amber-400 bg-amber-950/40 shadow-[0_0_14px_rgba(245,158,11,0.35)] scale-105'
                    : 'border-zinc-800/90 bg-zinc-950/80 hover:border-zinc-700'
                }`}
              >
                <div className="w-full flex items-center justify-between text-[10px] font-mono">
                  <span className={isActive ? 'text-amber-400 font-bold' : 'text-zinc-500'}>
                    [{idx + 1}]
                  </span>
                  {isActive && <span className="text-[9px] text-amber-300 uppercase">АКТИВ</span>}
                </div>
                <div className="text-lg leading-none">{info.icon}</div>
                <div
                  className={`text-[10px] font-medium tracking-tight truncate max-w-[70px] ${
                    item ? (isActive ? 'text-zinc-100 font-semibold' : 'text-zinc-300') : 'text-zinc-600'
                  }`}
                >
                  {info.name}
                </div>
              </div>
            );
          })}
        </div>
        <span className="text-[10px] text-zinc-500 font-mono tracking-wide">
          [1-3] или Колесико / СКМ для выбора слота
        </span>
      </div>

      {/* Bottom-Left: Circular SVG Battery Gauges (Vertical Stack) */}
      <div className="absolute bottom-5 left-5 flex flex-col gap-2 pointer-events-auto z-10">
        {/* 1. Flashlight Battery Dial */}
        <div
          className="flex items-center gap-2.5 px-3 py-1.5 border border-zinc-800/90 w-44"
          style={{ backgroundColor: 'rgba(8, 10, 13, 0.88)' }}
        >
          <div className="relative w-11 h-11 flex items-center justify-center">
            <svg className="w-11 h-11 -rotate-90" viewBox="0 0 52 52">
              <circle
                cx="26"
                cy="26"
                r={radius}
                className="stroke-zinc-800"
                strokeWidth="4"
                fill="none"
              />
              <circle
                cx="26"
                cy="26"
                r={radius}
                stroke={flashColor}
                strokeWidth="4"
                strokeDasharray={circumference}
                strokeDashoffset={flashOffset}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-150"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-[10px] font-mono font-bold text-zinc-200">
              <span>{hud.battery}%</span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-zinc-200 flex items-center gap-1">
              🔦 Фонарь [F]
            </span>
            <span
              className={`text-[10px] font-mono font-bold ${
                hud.flashlightOn
                  ? hud.flashlightFlickering
                    ? 'text-red-400'
                    : 'text-amber-300'
                  : 'text-zinc-500'
              }`}
            >
              {hud.flashlightOn ? (hud.flashlightFlickering ? 'СЛАБЫЙ' : 'ВКЛ') : 'ВЫКЛ'}
            </span>
          </div>
        </div>

        {/* 2. NVG Battery Dial */}
        <div
          className={`flex items-center gap-2.5 px-3 py-1.5 border transition-colors w-44 ${
            hud.hasNvg ? 'border-zinc-800/90' : 'border-zinc-900/60 opacity-60'
          }`}
          style={{ backgroundColor: 'rgba(8, 10, 13, 0.88)' }}
        >
          <div className="relative w-11 h-11 flex items-center justify-center">
            <svg className="w-12 h-12 -rotate-90" viewBox="0 0 52 52">
              <circle
                cx="26"
                cy="26"
                r={radius}
                className="stroke-zinc-800"
                strokeWidth="4"
                fill="none"
              />
              <circle
                cx="26"
                cy="26"
                r={radius}
                stroke={hud.hasNvg ? '#10b981' : '#3f3f46'}
                strokeWidth="4"
                strokeDasharray={circumference}
                strokeDashoffset={hud.hasNvg ? nvgOffset : circumference}
                strokeLinecap="round"
                fill="none"
                className="transition-all duration-150"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-[10px] font-mono font-bold text-zinc-200">
              <span>{hud.hasNvg ? `${hud.nvgBattery}%` : '—'}</span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-xs font-semibold text-zinc-200 flex items-center gap-1">
              🥽 ПНВ [N]
            </span>
            <span
              className={`text-[10px] font-mono font-bold ${
                hud.hasNvg
                  ? hud.nvgOn
                    ? 'text-emerald-400'
                    : 'text-zinc-500'
                  : 'text-zinc-600'
              }`}
            >
              {hud.hasNvg ? (hud.nvgOn ? 'ВКЛЮЧЕН' : 'ГОТОВ') : 'НЕ НАЙДЕН'}
            </span>
          </div>
        </div>
      </div>

      {/* Bottom-Right: Pointer Lock Cue */}
      {!hud.pointerLocked && (
        <div className="absolute bottom-5 right-5">
          <div
            className="px-3 py-1.5 border border-zinc-800/80 text-[11px] text-zinc-400"
            style={{ backgroundColor: 'rgba(8, 10, 13, 0.78)' }}
          >
            Нажмите на экран для захвата мыши
          </div>
        </div>
      )}
    </div>
  );
}
