/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { GameHUD } from './components/GameHUD';
import { GameOverlays } from './components/GameOverlays';
import { HorrorGameEngine } from './game/engine';
import type { HudSnapshot } from './game/types';

const INITIAL_HUD: HudSnapshot = {
  phase: 'title',
  fusesCarried: 0,
  fusesInstalled: 0,
  totalFuses: 3,
  powerRestored: false,
  hasExitKey: false,
  hasHammer: false,
  hasWireCutters: false,
  hasNvg: false,
  nvgOn: false,
  nvgBattery: 100,
  inventory: [null, null, null],
  activeSlotIndex: 0,
  planksRemoved: false,
  alarmDisabled: false,
  battery: 100,
  flashlightOn: true,
  flashlightFlickering: false,
  objective: 'Find 3 fuses (0/3)',
  promptText: null,
  promptSubtext: null,
  roomName: 'Main Corridor',
  statusBanner: null,
  dangerLevel: 0,
  elapsedSeconds: 0,
  pointerLocked: false,
  muted: false,
};

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<HorrorGameEngine | null>(null);
  const [hud, setHud] = useState<HudSnapshot>(INITIAL_HUD);
  const [contextLost, setContextLost] = useState(false);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    const engine = new HorrorGameEngine(
      container,
      (snapshot) => setHud(snapshot),
      (lost) => setContextLost(lost),
    );
    engine.setBrightness(5.25);
    engine.setFogDensity(0.01);
    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  return (
    <main className="relative w-full h-full overflow-hidden bg-black">
      {/* Isolated WebGL mount container */}
      <div
        ref={mountRef}
        data-testid="game-viewport"
        className="fixed inset-0 w-full h-full"
      />

      <GameHUD
        hud={hud}
        onPause={() => engineRef.current?.pauseGame()}
      />

      <GameOverlays
        hud={hud}
        contextLost={contextLost}
        onToggleMute={() => engineRef.current?.toggleMute()}
        onStart={() => engineRef.current?.startNewGame(true)}
        onResume={() => engineRef.current?.resumeGame()}
        onMainMenu={() => engineRef.current?.returnToTitle()}
      />
    </main>
  );
}
