import type { AABB, InteractableItem, Point2D } from './types';

export const TILE_SIZE = 2.4;
export const WALL_HEIGHT = 3.4;
export const PLAYER_RADIUS = 0.42;
export const PLAYER_EYE_HEIGHT = 1.65;
export const MONSTER_RADIUS = 0.48;

/**
 * 21 columns x 16 rows corporate office & technical basement map.
 * '#' = solid wall, '.' = walkable floor.
 * Door openings are precisely 1-tile wide gaps ('.') flush between wall sections.
 */
export const MAP_LAYOUT: readonly string[] = [
  '#####################', // 0
  '#...#.....#.....#...#', // 1  Cafeteria (1..3) | Security (5..9) | Mawrg's Office (11..15) | Archive (17..19)
  '#...#.....#.....#...#', // 2
  '#...#.....#.....#...#', // 3
  '##.####.#####.####.##', // 4  Doors to Cafeteria (2,4), Security (7,4), Mawrg's (13,4), Archive (18,4)
  '#...................#', // 5  Main Office Corridor & Reception (1..19)
  '#...................#', // 6
  '##.####.#####.####.##', // 7  Doors to Conference (2,7), Basement Gen (7,7), Open Office (13,7), East (18,7)
  '#...#.....#.....#...#', // 8  Conference (1..3) | Basement Gen (5..9) | Workstations (11..15) | East Wing (17..19)
  '#...#.....#.....#...#', // 9
  '#...#.....#.....#...#', // 10
  '#######.#####.#######', // 11 Doors to Sub-Basement Maintenance (7,11) & Surface Exit (13,11)
  '#.......##..........#', // 12 Maintenance Workshop (1..7) & Surface Exit Airlock (10..19)
  '#.......##..........#', // 13
  '#.......##..........#', // 14
  '#####################', // 15
];

export const MAP_ROWS = MAP_LAYOUT.length;
export const MAP_COLS = MAP_LAYOUT[0].length;

export function gridToWorld(col: number, row: number): Point2D {
  return {
    x: (col + 0.5) * TILE_SIZE,
    z: (row + 0.5) * TILE_SIZE,
  };
}

export function worldToGrid(x: number, z: number): { col: number; row: number } {
  return {
    col: Math.floor(x / TILE_SIZE),
    row: Math.floor(z / TILE_SIZE),
  };
}

export function isWallTile(col: number, row: number): boolean {
  if (row < 0 || row >= MAP_ROWS || col < 0 || col >= MAP_COLS) {
    return true;
  }
  return MAP_LAYOUT[row][col] === '#';
}

export interface PlayerSpawnPoint {
  x: number;
  z: number;
  yaw: number;
  locationName: string;
}

export const POSSIBLE_PLAYER_SPAWNS: PlayerSpawnPoint[] = [
  { ...gridToWorld(2.0, 5.5), yaw: -Math.PI / 2, locationName: 'Main Lobby & Reception' },
  { ...gridToWorld(2.0, 2.0), yaw: Math.PI / 2, locationName: 'Corporate Cafeteria' },
  { ...gridToWorld(13.0, 2.0), yaw: Math.PI, locationName: "Mawrg's Executive Suite" },
  { ...gridToWorld(18.0, 5.5), yaw: Math.PI / 2, locationName: 'East Office Wing' },
  { ...gridToWorld(2.0, 9.0), yaw: -Math.PI / 2, locationName: 'Conference Boardroom' },
];

export const PLAYER_SPAWN: PlayerSpawnPoint = POSSIBLE_PLAYER_SPAWNS[0];

export const MONSTER_SPAWN: Point2D = gridToWorld(13.0, 9.0);

export interface WaypointNode {
  id: number;
  x: number;
  z: number;
  neighbors: number[];
}

const RAW_WAYPOINTS: Array<{ col: number; row: number; neighbors: number[] }> = [
  // 0..3: Corridor waypoints
  { col: 2.0, row: 5.5, neighbors: [1, 4, 8] },
  { col: 7.0, row: 5.5, neighbors: [0, 2, 5, 9] },
  { col: 13.0, row: 5.5, neighbors: [1, 3, 6, 10] },
  { col: 18.0, row: 5.5, neighbors: [2, 7, 11] },

  // 4..7: North rooms
  { col: 2.0, row: 2.0, neighbors: [0] },      // Cafeteria
  { col: 7.0, row: 2.0, neighbors: [1] },      // Security Command
  { col: 13.0, row: 2.0, neighbors: [2] },     // Mawrg's Office
  { col: 18.0, row: 2.0, neighbors: [3] },     // Server / Archive

  // 8..11: Mid rooms
  { col: 2.0, row: 9.0, neighbors: [0] },      // Conference Boardroom
  { col: 7.0, row: 9.0, neighbors: [1, 12] },  // Basement Generator Vault
  { col: 13.0, row: 9.0, neighbors: [2, 13] }, // Open Office Workstations
  { col: 18.0, row: 9.0, neighbors: [3] },     // East Wing Alcove

  // 12..14: South basement
  { col: 4.0, row: 13.5, neighbors: [9] },     // Maintenance Workshop
  { col: 13.0, row: 13.5, neighbors: [10, 14] },// Airlock Entrance
  { col: 15.0, row: 13.5, neighbors: [13] },   // Surface Exit Airlock Door
];

export const PATROL_WAYPOINTS: WaypointNode[] = RAW_WAYPOINTS.map((wp, idx) => {
  const pos = gridToWorld(wp.col, wp.row);
  return {
    id: idx,
    x: pos.x,
    z: pos.z,
    neighbors: wp.neighbors,
  };
});

export interface RoomZone {
  name: string;
  minCol: number;
  maxCol: number;
  minRow: number;
  maxRow: number;
}

export const ROOM_ZONES: RoomZone[] = [
  { name: 'Corporate Cafeteria', minCol: 1, maxCol: 3, minRow: 1, maxRow: 3 },
  { name: 'Security Command', minCol: 5, maxCol: 9, minRow: 1, maxRow: 3 },
  { name: "Mawrg's Executive Suite", minCol: 11, maxCol: 15, minRow: 1, maxRow: 3 },
  { name: 'Server & Archive Vault', minCol: 17, maxCol: 19, minRow: 1, maxRow: 3 },
  { name: 'Main Lobby & Reception', minCol: 1, maxCol: 19, minRow: 5, maxRow: 6 },
  { name: 'Conference Boardroom', minCol: 1, maxCol: 3, minRow: 8, maxRow: 10 },
  { name: 'Basement Generator Vault', minCol: 5, maxCol: 9, minRow: 8, maxRow: 10 },
  { name: 'Open Office Workstations', minCol: 11, maxCol: 15, minRow: 8, maxRow: 10 },
  { name: 'East Wing Alcove', minCol: 17, maxCol: 19, minRow: 8, maxRow: 10 },
  { name: 'Maintenance Workshop', minCol: 1, maxCol: 7, minRow: 12, maxRow: 14 },
  { name: 'Emergency Surface Airlock', minCol: 10, maxCol: 19, minRow: 12, maxRow: 14 },
];

export function getRoomNameAt(x: number, z: number): string {
  const { col, row } = worldToGrid(x, z);
  for (const room of ROOM_ZONES) {
    if (col >= room.minCol && col <= room.maxCol && row >= room.minRow && row <= room.maxRow) {
      return room.name;
    }
  }
  return 'Corporate Facility';
}

export function buildWallAABBs(interactables?: readonly InteractableItem[]): AABB[] {
  const aabbs: AABB[] = [];
  for (let row = 0; row < MAP_ROWS; row++) {
    for (let col = 0; col < MAP_COLS; col++) {
      if (MAP_LAYOUT[row][col] === '#') {
        aabbs.push({
          minX: col * TILE_SIZE,
          maxX: (col + 1) * TILE_SIZE,
          minZ: row * TILE_SIZE,
          maxZ: (row + 1) * TILE_SIZE,
        });
      }
    }
  }

  // Closed doors act as solid blocking walls
  if (interactables) {
    for (const item of interactables) {
      if (item.kind === 'door' && !item.isOpen) {
        aabbs.push({
          minX: item.x - 1.1,
          maxX: item.x + 1.1,
          minZ: item.z - 0.35,
          maxZ: item.z + 0.35,
        });
      }
    }
  }

  // Prop collision boxes for furniture & nightstands
  // 1. Generator Unit in Basement
  const genPos = gridToWorld(8.5, 9.2);
  aabbs.push({
    minX: genPos.x - 1.25,
    maxX: genPos.x + 1.25,
    minZ: genPos.z - 1.65,
    maxZ: genPos.z + 1.65,
  });

  // 2. Security Command Console Desk
  const secDesk = gridToWorld(7.0, 2.2);
  aabbs.push({
    minX: secDesk.x - 1.25,
    maxX: secDesk.x + 1.25,
    minZ: secDesk.z - 0.45,
    maxZ: secDesk.z + 0.45,
  });

  // 3. Mawrg's Executive Desk
  const execDesk = gridToWorld(13.0, 2.0);
  aabbs.push({
    minX: execDesk.x - 1.35,
    maxX: execDesk.x + 1.35,
    minZ: execDesk.z - 0.55,
    maxZ: execDesk.z + 0.55,
  });

  // 4. Conference Table
  const confTable = gridToWorld(2.0, 9.0);
  aabbs.push({
    minX: confTable.x - 0.65,
    maxX: confTable.x + 0.65,
    minZ: confTable.z - 1.2,
    maxZ: confTable.z + 1.2,
  });

  // 5. Cafeteria Counter
  const cafeCounter = gridToWorld(3.2, 2.2);
  aabbs.push({
    minX: cafeCounter.x - 0.45,
    maxX: cafeCounter.x + 0.45,
    minZ: cafeCounter.z - 1.1,
    maxZ: cafeCounter.z + 1.1,
  });

  // 6. Nightstands (5 units)
  const nightstandLocations = [
    gridToWorld(6.0, 1.8),   // Security Command Nightstand
    gridToWorld(14.5, 2.5),  // Mawrg's Office Nightstand
    gridToWorld(1.8, 9.8),   // Conference Nightstand
    gridToWorld(2.2, 13.5),  // Maintenance Workbench Nightstand
    gridToWorld(14.5, 9.8),  // Open Office Nightstand
  ];
  for (const nPos of nightstandLocations) {
    aabbs.push({
      minX: nPos.x - 0.45,
      maxX: nPos.x + 0.45,
      minZ: nPos.z - 0.45,
      maxZ: nPos.z + 0.45,
    });
  }

  return aabbs;
}

interface ItemPlacementSlot {
  col: number;
  row: number;
  y: number;
}

const FUSE_SLOTS: ItemPlacementSlot[] = [
  { col: 2.0, row: 2.0, y: 0.82 },  // Cafeteria Dining Table
  { col: 13.0, row: 2.3, y: 0.85 }, // Mawrg's Executive Desk
  { col: 2.0, row: 9.0, y: 0.82 },  // Conference Boardroom Table
  { col: 13.0, row: 9.0, y: 0.82 }, // Open Office Workstation
  { col: 18.0, row: 2.0, y: 0.85 }, // Archive Vault Credenza
  { col: 3.5, row: 13.5, y: 0.82 }, // Maintenance Workshop Bench
];

const BATTERY_SLOTS: ItemPlacementSlot[] = [
  { col: 1.5, row: 9.0, y: 0.78 },  // Conference Side Shelf
  { col: 14.2, row: 8.8, y: 0.82 }, // Open Office Desk 2
  { col: 17.5, row: 13.5, y: 0.78 },// Exit Airlock Console
  { col: 2.8, row: 1.5, y: 0.85 },  // Cafeteria Coffee Stand
  { col: 12.0, row: 1.6, y: 0.85 }, // Mawrg's Bookshelf Alcove
  { col: 6.6, row: 9.8, y: 0.75 },  // Basement Fuel Crate
];

function shuffleArray<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

export function createInitialInteractables(randomize = false): InteractableItem[] {
  // Deterministic positions
  let fuseA = gridToWorld(2.0, 2.0);
  let fuseB = gridToWorld(3.5, 13.5);
  let fuseC = gridToWorld(13.0, 2.3);
  let batA = gridToWorld(1.5, 9.0);
  let batB = gridToWorld(13.0, 9.0);
  let batC = gridToWorld(17.5, 13.5);

  let fuseAY = 0.82;
  let fuseBY = 0.82;
  let fuseCY = 0.85;
  let batAY = 0.78;
  let batBY = 0.82;
  let batCY = 0.78;

  if (randomize) {
    const shuffledFuses = shuffleArray(FUSE_SLOTS);
    fuseA = gridToWorld(shuffledFuses[0].col, shuffledFuses[0].row);
    fuseAY = shuffledFuses[0].y;
    fuseB = gridToWorld(shuffledFuses[1].col, shuffledFuses[1].row);
    fuseBY = shuffledFuses[1].y;
    fuseC = gridToWorld(shuffledFuses[2].col, shuffledFuses[2].row);
    fuseCY = shuffledFuses[2].y;

    const shuffledBats = shuffleArray(BATTERY_SLOTS);
    batA = gridToWorld(shuffledBats[0].col, shuffledBats[0].row);
    batAY = shuffledBats[0].y;
    batB = gridToWorld(shuffledBats[1].col, shuffledBats[1].row);
    batBY = shuffledBats[1].y;
    batC = gridToWorld(shuffledBats[2].col, shuffledBats[2].row);
    batCY = shuffledBats[2].y;
  }

  // Nightstand coordinates
  const nsSec = gridToWorld(6.0, 1.8);
  const nsMawrg = gridToWorld(14.5, 2.5);
  const nsConf = gridToWorld(1.8, 9.8);
  const nsMaint = gridToWorld(2.2, 13.5);
  const nsOffice = gridToWorld(14.5, 9.8);

  const genPanel = gridToWorld(8.35, 9.2);
  const keyCabinet = gridToWorld(7.0, 1.05);

  // Main Exit Door: Prominently centered at South wall of Emergency Airlock
  const exitDoor = gridToWorld(15.0, 14.4);

  return [
    // 5 Interactive Nightstands
    {
      id: 'nightstand_sec',
      kind: 'nightstand',
      label: 'Тумбочка охраны',
      x: nsSec.x,
      y: 0.45,
      z: nsSec.z,
      collected: false,
      isOpen: false,
      containsItemId: 'nvg_tool',
    },
    {
      id: 'nightstand_mawrg',
      kind: 'nightstand',
      label: 'Тумбочка руководителя',
      x: nsMawrg.x,
      y: 0.45,
      z: nsMawrg.z,
      collected: false,
      isOpen: false,
      containsItemId: 'fuse_3',
    },
    {
      id: 'nightstand_conf',
      kind: 'nightstand',
      label: 'Тумбочка в конференц-зале',
      x: nsConf.x,
      y: 0.45,
      z: nsConf.z,
      collected: false,
      isOpen: false,
      containsItemId: 'battery_1',
    },
    {
      id: 'nightstand_maint',
      kind: 'nightstand',
      label: 'Верстачная тумба',
      x: nsMaint.x,
      y: 0.45,
      z: nsMaint.z,
      collected: false,
      isOpen: false,
      containsItemId: 'hammer_tool',
    },
    {
      id: 'nightstand_office',
      kind: 'nightstand',
      label: 'Офисная тумба',
      x: nsOffice.x,
      y: 0.45,
      z: nsOffice.z,
      collected: false,
      isOpen: false,
      containsItemId: 'wire_cutters_tool',
    },

    // Tools & Gadgets
    {
      id: 'nvg_tool',
      kind: 'nvg',
      label: 'Прибор ночного видения (ПНВ)',
      x: nsSec.x,
      y: 0.52,
      z: nsSec.z,
      collected: false,
      insideNightstandId: 'nightstand_sec',
    },
    {
      id: 'hammer_tool',
      kind: 'hammer',
      label: 'Тяжелый молоток',
      x: nsMaint.x,
      y: 0.52,
      z: nsMaint.z,
      collected: false,
      insideNightstandId: 'nightstand_maint',
    },
    {
      id: 'wire_cutters_tool',
      kind: 'wire_cutters',
      label: 'Кусачки для проводов',
      x: nsOffice.x,
      y: 0.52,
      z: nsOffice.z,
      collected: false,
      insideNightstandId: 'nightstand_office',
    },

    // Fuses
    {
      id: 'fuse_1',
      kind: 'fuse',
      label: 'Предохранитель A',
      x: fuseA.x,
      y: fuseAY,
      z: fuseA.z,
      collected: false,
    },
    {
      id: 'fuse_2',
      kind: 'fuse',
      label: 'Предохранитель B',
      x: fuseB.x,
      y: fuseBY,
      z: fuseB.z,
      collected: false,
    },
    {
      id: 'fuse_3',
      kind: 'fuse',
      label: 'Предохранитель C',
      x: nsMawrg.x,
      y: 0.52,
      z: nsMawrg.z,
      collected: false,
      insideNightstandId: 'nightstand_mawrg',
    },

    // Batteries
    {
      id: 'battery_1',
      kind: 'battery',
      label: 'Батарея питания',
      x: nsConf.x,
      y: 0.52,
      z: nsConf.z,
      collected: false,
      insideNightstandId: 'nightstand_conf',
    },
    {
      id: 'battery_2',
      kind: 'battery',
      label: 'Батарея питания',
      x: batB.x,
      y: batBY,
      z: batB.z,
      collected: false,
    },
    {
      id: 'battery_3',
      kind: 'battery',
      label: 'Батарея питания',
      x: batC.x,
      y: batCY,
      z: batC.z,
      collected: false,
    },

    // Doors flush at 1-tile doorways (y = 0)
    {
      id: 'door_cafeteria',
      kind: 'door',
      label: 'Дверь в столовую',
      ...gridToWorld(2.0, 4.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_security',
      kind: 'door',
      label: 'Дверь поста охраны',
      ...gridToWorld(7.0, 4.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_mawrg',
      kind: 'door',
      label: 'Дверь в кабинет Mawrg',
      ...gridToWorld(13.0, 4.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_archive',
      kind: 'door',
      label: 'Дверь в архив',
      ...gridToWorld(18.0, 4.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_conference',
      kind: 'door',
      label: 'Дверь в конференц-зал',
      ...gridToWorld(2.0, 7.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_generator',
      kind: 'door',
      label: 'Гермодверь в генераторную',
      ...gridToWorld(7.0, 7.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_openoffice',
      kind: 'door',
      label: 'Дверь в опенспейс',
      ...gridToWorld(13.0, 7.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_maintenance',
      kind: 'door',
      label: 'Дверь в мастерскую',
      ...gridToWorld(7.0, 11.0),
      y: 0,
      collected: false,
      isOpen: false,
    },
    {
      id: 'door_airlock',
      kind: 'door',
      label: 'Гермошлюз выхода',
      ...gridToWorld(13.0, 11.0),
      y: 0,
      collected: false,
      isOpen: false,
    },

    // Generator & Key Locker
    {
      id: 'generator_panel',
      kind: 'generator',
      label: 'Дизель-генератор (Щит питания)',
      x: genPanel.x,
      y: 1.35,
      z: genPanel.z,
      collected: false,
    },
    {
      id: 'key_cabinet',
      kind: 'key_cabinet',
      label: 'Оружейный шкафчик (Ключ выхода)',
      x: keyCabinet.x,
      y: 1.45,
      z: keyCabinet.z,
      collected: false,
    },

    // Main Exit Door (South Wall of Emergency Airlock)
    {
      id: 'exit_door',
      kind: 'exit_door',
      label: 'ГЛАВНЫЙ ВЫХОД (АВАРИЙНЫЙ ШЛЮЗ)',
      x: exitDoor.x,
      y: 1.4,
      z: exitDoor.z,
      collected: false,
    },
  ];
}

export interface AtmosphericEventZone {
  id: string;
  x: number;
  z: number;
  radius: number;
  kind: 'lamp_spark' | 'whisper_behind' | 'red_surge';
  message: string;
}

export function createEventZones(): AtmosphericEventZone[] {
  const midHall = gridToWorld(7.0, 5.5);
  const officeHall = gridToWorld(13.0, 2.0);
  const cafeHall = gridToWorld(2.0, 2.0);
  return [
    {
      id: 'evt_lamp_spark',
      x: midHall.x,
      z: midHall.z,
      radius: 2.2,
      kind: 'lamp_spark',
      message: 'Флуоресцентная лампа в коридоре с треском моргнула.',
    },
    {
      id: 'evt_red_surge',
      x: officeHall.x,
      z: officeHall.z,
      radius: 2.0,
      kind: 'red_surge',
      message: 'Тень метнулась мимо стола руководителя...',
    },
    {
      id: 'evt_whisper_behind',
      x: cafeHall.x,
      z: cafeHall.z,
      radius: 2.0,
      kind: 'whisper_behind',
      message: 'В темноте столовой что-то заскрежетало...',
    },
  ];
}
