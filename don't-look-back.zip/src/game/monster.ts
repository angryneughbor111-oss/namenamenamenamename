import * as THREE from 'three';
import {
  gridToWorld,
  isWallTile,
  MAP_COLS,
  MAP_ROWS,
  MONSTER_RADIUS,
  MONSTER_SPAWN,
  PATROL_WAYPOINTS,
  worldToGrid,
} from './mapData';
import {
  evaluateMonsterDetection,
  hasLineOfSight,
  resolveCircleAABBs,
} from './rules';
import type { AABB, InteractableItem, MonsterState } from './types';

export function isFurnitureBlockedTile(col: number, row: number): boolean {
  if (col === 13 && row === 2) return true; // Mawrg's Executive Desk
  if (col === 7 && row === 2) return true;  // Security Command Console
  if (col === 2 && row === 9) return true;  // Conference Boardroom Table
  if (col === 3 && row === 2) return true;  // Cafeteria Counter
  if ((col === 8 || col === 9) && row === 9) return true; // Basement Generator
  return false;
}

// Raycast clearance test: checks that the straight line between points does NOT intersect furniture AABBs or closed doors
function isDirectSprintClear(
  x1: number,
  z1: number,
  x2: number,
  z2: number,
  wallAABBs: readonly AABB[],
): boolean {
  if (!hasLineOfSight(x1, z1, x2, z2)) return false;

  const dx = x2 - x1;
  const dz = z2 - z1;
  const dist = Math.hypot(dx, dz);
  if (dist < 0.6) return true;

  const step = 0.35;
  const numSteps = Math.floor(dist / step);
  for (let i = 1; i < numSteps; i++) {
    const t = (i * step) / dist;
    const px = x1 + dx * t;
    const pz = z1 + dz * t;
    for (let b = 0; b < wallAABBs.length; b++) {
      const box = wallAABBs[b];
      if (
        px >= box.minX - 0.22 &&
        px <= box.maxX + 0.22 &&
        pz >= box.minZ - 0.22 &&
        pz <= box.maxZ + 0.22
      ) {
        return false;
      }
    }
  }
  return true;
}

// Breadth-First-Search on the 21x16 office map grid avoiding walls and furniture
function findGridPath(
  startCol: number,
  startRow: number,
  goalCol: number,
  goalRow: number,
): Array<{ col: number; row: number }> {
  if (startCol === goalCol && startRow === goalRow) {
    return [{ col: startCol, row: startRow }];
  }

  const queue: Array<{ col: number; row: number }> = [{ col: startCol, row: startRow }];
  const parent = new Map<string, string>();
  const visited = new Set<string>();
  const startKey = `${startCol},${startRow}`;
  visited.add(startKey);

  const dirs = [
    { dc: 0, dr: -1 },
    { dc: 1, dr: 0 },
    { dc: 0, dr: 1 },
    { dc: -1, dr: 0 },
  ];

  let found = false;
  const goalKey = `${goalCol},${goalRow}`;

  while (queue.length > 0) {
    const cur = queue.shift()!;
    const curKey = `${cur.col},${cur.row}`;
    if (cur.col === goalCol && cur.row === goalRow) {
      found = true;
      break;
    }

    for (const d of dirs) {
      const nc = cur.col + d.dc;
      const nr = cur.row + d.dr;
      const nKey = `${nc},${nr}`;

      const isWalkable =
        nc >= 0 &&
        nc < MAP_COLS &&
        nr >= 0 &&
        nr < MAP_ROWS &&
        !isWallTile(nc, nr) &&
        (!isFurnitureBlockedTile(nc, nr) || (nc === goalCol && nr === goalRow));

      if (isWalkable && !visited.has(nKey)) {
        visited.add(nKey);
        parent.set(nKey, curKey);
        queue.push({ col: nc, row: nr });
      }
    }
  }

  // Fallback: if goal tile itself is blocked (e.g. inside desk), path to nearest visited neighbor of goal
  let endKey = goalKey;
  if (!found) {
    for (const d of dirs) {
      const nc = goalCol + d.dc;
      const nr = goalRow + d.dr;
      const nKey = `${nc},${nr}`;
      if (visited.has(nKey)) {
        found = true;
        endKey = nKey;
        break;
      }
    }
  }

  if (!found) return [];

  // Reconstruct path backwards from goal
  const path: Array<{ col: number; row: number }> = [];
  let curr: string | undefined = endKey;
  while (curr) {
    const [c, r] = curr.split(',').map(Number);
    path.unshift({ col: c, row: r });
    if (curr === startKey) break;
    curr = parent.get(curr);
  }

  return path;
}

export class StalkerMonster {
  readonly group: THREE.Group;
  private headGroup: THREE.Group;
  private leftArm: THREE.Group;
  private rightArm: THREE.Group;
  private leftLeg: THREE.Mesh;
  private rightLeg: THREE.Mesh;
  private disposables: Array<{ dispose: () => void }> = [];

  x = MONSTER_SPAWN.x;
  z = MONSTER_SPAWN.z;
  yaw = Math.PI;

  state: MonsterState = 'patrol';
  private targetWpIdx = 0;
  private lastKnownPlayerX = MONSTER_SPAWN.x;
  private lastKnownPlayerZ = MONSTER_SPAWN.z;
  private searchTimer = 0;
  private walkCycle = 0;
  private stepAccum = 0;

  constructor(scene: THREE.Scene) {
    this.group = new THREE.Group();
    const track = <T extends { dispose: () => void }>(res: T): T => {
      this.disposables.push(res);
      return res;
    };

    const skinMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x3d4348,
        emissive: 0x1f0b0b,
        emissiveIntensity: 0.4,
        roughness: 0.8,
        metalness: 0.15,
      }),
    );
    const boneMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x615d55,
        roughness: 0.7,
        metalness: 0.1,
      }),
    );
    const eyeMat = track(
      new THREE.MeshStandardMaterial({
        color: 0xff1111,
        emissive: 0xef2222,
        emissiveIntensity: 2.2,
        roughness: 0.2,
      }),
    );
    const shadowMat = track(
      new THREE.MeshBasicMaterial({
        color: 0x000000,
        transparent: true,
        opacity: 0.55,
        depthWrite: false,
      }),
    );

    // Grounded contact shadow disc
    const shadowDisc = new THREE.Mesh(track(new THREE.CircleGeometry(0.55, 14)), shadowMat);
    shadowDisc.rotation.x = -Math.PI / 2;
    shadowDisc.position.y = 0.02;
    this.group.add(shadowDisc);

    // Gaunt legs (bottom-center pivot at y=0)
    const legGeo = track(new THREE.BoxGeometry(0.16, 1.0, 0.16));
    this.leftLeg = new THREE.Mesh(legGeo, skinMat);
    this.leftLeg.position.set(-0.2, 0.5, 0);
    this.group.add(this.leftLeg);

    this.rightLeg = new THREE.Mesh(legGeo, skinMat);
    this.rightLeg.position.set(0.2, 0.5, 0);
    this.group.add(this.rightLeg);

    // Elongated hunched torso + jagged rib plates
    const torso = new THREE.Mesh(track(new THREE.BoxGeometry(0.54, 0.92, 0.34)), skinMat);
    torso.position.set(0, 1.4, 0.03);
    torso.rotation.x = 0.14;
    this.group.add(torso);

    const ribGeo = track(new THREE.BoxGeometry(0.58, 0.07, 0.37));
    for (let i = 0; i < 3; i++) {
      const rib = new THREE.Mesh(ribGeo, boneMat);
      rib.position.set(0, 1.2 + i * 0.2, 0.04);
      rib.rotation.x = 0.14;
      this.group.add(rib);
    }

    // Long asymmetrical arms with claw tips
    const armGeo = track(new THREE.BoxGeometry(0.13, 1.05, 0.13));
    const clawGeo = track(new THREE.ConeGeometry(0.055, 0.26, 4));

    this.leftArm = new THREE.Group();
    this.leftArm.position.set(-0.36, 1.78, 0.05);
    const lArmMesh = new THREE.Mesh(armGeo, skinMat);
    lArmMesh.position.y = -0.5;
    this.leftArm.add(lArmMesh);
    const lClaw = new THREE.Mesh(clawGeo, boneMat);
    lClaw.rotation.x = Math.PI;
    lClaw.position.y = -1.1;
    this.leftArm.add(lClaw);
    this.group.add(this.leftArm);

    this.rightArm = new THREE.Group();
    this.rightArm.position.set(0.36, 1.78, 0.05);
    const rArmMesh = new THREE.Mesh(armGeo, skinMat);
    rArmMesh.position.y = -0.5;
    this.rightArm.add(rArmMesh);
    const rClaw = new THREE.Mesh(clawGeo, boneMat);
    rClaw.rotation.x = Math.PI;
    rClaw.position.y = -1.1;
    this.rightArm.add(rClaw);
    this.group.add(this.rightArm);

    // Head with piercing glowing red eyes
    this.headGroup = new THREE.Group();
    this.headGroup.position.set(0, 1.95, 0.12);

    const skull = new THREE.Mesh(track(new THREE.BoxGeometry(0.38, 0.42, 0.42)), skinMat);
    this.headGroup.add(skull);

    const eyeGeo = track(new THREE.BoxGeometry(0.065, 0.045, 0.05));
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-0.11, 0.06, 0.21);
    this.headGroup.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(0.11, 0.06, 0.21);
    this.headGroup.add(rightEye);

    const jaw = new THREE.Mesh(track(new THREE.BoxGeometry(0.28, 0.14, 0.3)), boneMat);
    jaw.position.set(0, -0.22, 0.06);
    this.headGroup.add(jaw);

    this.group.add(this.headGroup);
    scene.add(this.group);

    this.reset();
  }

  reset(): void {
    this.x = MONSTER_SPAWN.x;
    this.z = MONSTER_SPAWN.z;
    this.yaw = Math.PI;
    this.state = 'patrol';
    this.targetWpIdx = 0;
    this.lastKnownPlayerX = MONSTER_SPAWN.x;
    this.lastKnownPlayerZ = MONSTER_SPAWN.z;
    this.searchTimer = 0;
    this.walkCycle = 0;
    this.stepAccum = 0;
    this.group.position.set(this.x, 0, this.z);
    this.group.rotation.y = this.yaw;
  }

  dispose(): void {
    this.disposables.forEach((d) => d.dispose());
  }

  update(
    dt: number,
    timeSec: number,
    playerX: number,
    playerZ: number,
    flashlightOn: boolean,
    playerSprinting: boolean,
    powerRestored: boolean,
    wallAABBs: readonly AABB[],
    onChaseStart: () => void,
    onStep: (proximity: number) => void,
    interactables?: readonly InteractableItem[],
    onDoorOpened?: (door: InteractableItem, isChase: boolean) => void,
  ): { caughtPlayer: boolean; dangerLevel: number } {
    // Door Opening: Mawrg automatically pushes or bashes open room doors within reach
    if (interactables) {
      for (let i = 0; i < interactables.length; i++) {
        const item = interactables[i];
        if (item.kind === 'door' && !item.isOpen) {
          const distToDoor = Math.hypot(this.x - item.x, this.z - item.z);
          if (distToDoor < 2.05) {
            item.isOpen = true;
            const isChase = this.state === 'chase';
            if (onDoorOpened) {
              onDoorOpened(item, isChase);
            }
          }
        }
      }
    }

    const detection = evaluateMonsterDetection({
      monsterX: this.x,
      monsterZ: this.z,
      monsterYaw: this.yaw,
      playerX,
      playerZ,
      flashlightOn,
      playerSprinting,
    });

    const prevState = this.state;

    if (detection.detected) {
      this.state = 'chase';
      this.lastKnownPlayerX = playerX;
      this.lastKnownPlayerZ = playerZ;
      this.searchTimer = 5.0;
      if (prevState !== 'chase') {
        onChaseStart();
      }
    } else if (this.state === 'chase') {
      this.state = 'search';
    }

    let goalX = this.x;
    let goalZ = this.z;
    let speed = powerRestored ? 2.45 : 2.1;

    const monsterGrid = worldToGrid(this.x, this.z);

    if (this.state === 'chase') {
      speed = powerRestored ? 4.45 : 4.15;
      const playerGrid = worldToGrid(playerX, playerZ);

      // Direct line of sight sprint ONLY if clear of furniture & closed doors
      if (isDirectSprintClear(this.x, this.z, playerX, playerZ, wallAABBs)) {
        goalX = playerX;
        goalZ = playerZ;
      } else {
        // Grid pathfinding directly around furniture and walls
        const path = findGridPath(monsterGrid.col, monsterGrid.row, playerGrid.col, playerGrid.row);
        if (path.length >= 2) {
          const nextTile = gridToWorld(path[1].col, path[1].row);
          if (path.length >= 3 && Math.hypot(this.x - nextTile.x, this.z - nextTile.z) < 0.6) {
            const nextNext = gridToWorld(path[2].col, path[2].row);
            goalX = nextNext.x;
            goalZ = nextNext.z;
          } else {
            goalX = nextTile.x;
            goalZ = nextTile.z;
          }
        } else {
          goalX = playerX;
          goalZ = playerZ;
        }
      }
    } else if (this.state === 'search') {
      speed = 2.9;
      this.searchTimer -= dt;
      const distLast = Math.hypot(this.lastKnownPlayerX - this.x, this.lastKnownPlayerZ - this.z);

      if (distLast > 0.8 && isDirectSprintClear(this.x, this.z, this.lastKnownPlayerX, this.lastKnownPlayerZ, wallAABBs)) {
        goalX = this.lastKnownPlayerX;
        goalZ = this.lastKnownPlayerZ;
      } else {
        const lastGrid = worldToGrid(this.lastKnownPlayerX, this.lastKnownPlayerZ);
        const path = findGridPath(monsterGrid.col, monsterGrid.row, lastGrid.col, lastGrid.row);
        if (path.length >= 2) {
          const nextTile = gridToWorld(path[1].col, path[1].row);
          goalX = nextTile.x;
          goalZ = nextTile.z;
        }
      }

      if (this.searchTimer <= 0 || distLast < 0.9) {
        this.state = 'patrol';
        this.targetWpIdx = Math.floor(Math.random() * PATROL_WAYPOINTS.length);
      }
    } else {
      // Patrol across office waypoints
      const targetWp = PATROL_WAYPOINTS[this.targetWpIdx];
      const distWp = Math.hypot(targetWp.x - this.x, targetWp.z - this.z);

      if (distWp < 1.0) {
        const neighbors = targetWp.neighbors;
        this.targetWpIdx = neighbors[Math.floor(Math.random() * neighbors.length)];
      }

      const nextWp = PATROL_WAYPOINTS[this.targetWpIdx];
      const targetGrid = worldToGrid(nextWp.x, nextWp.z);
      const path = findGridPath(monsterGrid.col, monsterGrid.row, targetGrid.col, targetGrid.row);

      if (path.length >= 2) {
        const nextTile = gridToWorld(path[1].col, path[1].row);
        if (path.length >= 3 && Math.hypot(this.x - nextTile.x, this.z - nextTile.z) < 0.6) {
          const nextNext = gridToWorld(path[2].col, path[2].row);
          goalX = nextNext.x;
          goalZ = nextNext.z;
        } else {
          goalX = nextTile.x;
          goalZ = nextTile.z;
        }
      } else {
        goalX = nextWp.x;
        goalZ = nextWp.z;
      }
    }

    // Directional movement & wall sliding
    const dx = goalX - this.x;
    const dz = goalZ - this.z;
    const dLen = Math.hypot(dx, dz);

    if (dLen > 0.04) {
      const targetYaw = Math.atan2(dx, dz);
      let diff = targetYaw - this.yaw;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      this.yaw += diff * (1 - Math.exp(-9 * dt));

      const stepDist = Math.min(dLen, speed * dt);
      const nx = this.x + (dx / dLen) * stepDist;
      const nz = this.z + (dz / dLen) * stepDist;

      // Safe collision resolution against walls
      const resolved = resolveCircleAABBs(nx, nz, MONSTER_RADIUS, wallAABBs);
      const moved = Math.hypot(resolved.x - this.x, resolved.z - this.z);

      if (moved < 0.15 * stepDist && dLen > 0.08) {
        // Direct step blocked by obstacle - apply tangential sliding
        const tangLeftX = -dz / dLen;
        const tangLeftZ = dx / dLen;
        const tangRightX = dz / dLen;
        const tangRightZ = -dx / dLen;

        const resLeft = resolveCircleAABBs(
          this.x + tangLeftX * stepDist,
          this.z + tangLeftZ * stepDist,
          MONSTER_RADIUS,
          wallAABBs,
        );
        const resRight = resolveCircleAABBs(
          this.x + tangRightX * stepDist,
          this.z + tangRightZ * stepDist,
          MONSTER_RADIUS,
          wallAABBs,
        );

        const movedLeft = Math.hypot(resLeft.x - this.x, resLeft.z - this.z);
        const movedRight = Math.hypot(resRight.x - this.x, resRight.z - this.z);

        const distLeftToGoal = Math.hypot(goalX - resLeft.x, goalZ - resLeft.z);
        const distRightToGoal = Math.hypot(goalX - resRight.x, goalZ - resRight.z);

        if (movedLeft > 0.08 * stepDist && (distLeftToGoal <= distRightToGoal || movedRight <= 0.08 * stepDist)) {
          this.x = resLeft.x;
          this.z = resLeft.z;
        } else if (movedRight > 0.08 * stepDist) {
          this.x = resRight.x;
          this.z = resRight.z;
        } else {
          // Axis-aligned slide fallback
          const resOnlyX = resolveCircleAABBs(this.x + Math.sign(dx) * stepDist, this.z, MONSTER_RADIUS, wallAABBs);
          const resOnlyZ = resolveCircleAABBs(this.x, this.z + Math.sign(dz) * stepDist, MONSTER_RADIUS, wallAABBs);
          const movedX = Math.hypot(resOnlyX.x - this.x, resOnlyX.z - this.z);
          const movedZ = Math.hypot(resOnlyZ.x - this.x, resOnlyZ.z - this.z);
          if (movedX > movedZ && movedX > 0.04 * stepDist) {
            this.x = resOnlyX.x;
            this.z = resOnlyX.z;
          } else if (movedZ > 0.04 * stepDist) {
            this.x = resOnlyZ.x;
            this.z = resOnlyZ.z;
          } else {
            this.x = resolved.x;
            this.z = resolved.z;
          }
        }
      } else {
        this.x = resolved.x;
        this.z = resolved.z;
      }

      this.walkCycle += moved * 2.4;
      this.stepAccum += moved;
      if (this.stepAccum >= 1.45) {
        this.stepAccum = 0;
        const prox = Math.max(0, 1 - detection.distance / 18);
        onStep(prox);
      }
    }

    // Animate monster mesh
    this.group.position.set(this.x, Math.abs(Math.sin(this.walkCycle)) * 0.06, this.z);
    this.group.rotation.y = this.yaw;

    const swing = Math.sin(this.walkCycle) * 0.55;
    this.leftLeg.rotation.x = swing;
    this.rightLeg.rotation.x = -swing;

    if (this.state === 'chase') {
      this.leftArm.rotation.x = -1.15 + Math.sin(this.walkCycle * 1.4) * 0.25;
      this.rightArm.rotation.x = -1.15 - Math.sin(this.walkCycle * 1.4) * 0.25;
      this.headGroup.rotation.z = Math.sin(timeSec * 14) * 0.14;
    } else {
      this.leftArm.rotation.x = -swing * 0.6;
      this.rightArm.rotation.x = swing * 0.6;
      this.headGroup.rotation.z = 0.22 + Math.sin(timeSec * 2.1) * 0.08;
    }

    const distToPlayer = Math.hypot(playerX - this.x, playerZ - this.z);
    const dangerLevel = Math.max(0, Math.min(1, 1 - (distToPlayer - 2) / 14));
    const caughtPlayer = distToPlayer < 1.1;

    return { caughtPlayer, dangerLevel };
  }
}
