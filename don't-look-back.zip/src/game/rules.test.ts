import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWallAABBs,
  createInitialInteractables,
  gridToWorld,
  isWallTile,
  MAP_COLS,
  MAP_ROWS,
  PATROL_WAYPOINTS,
  PLAYER_RADIUS,
  PLAYER_SPAWN,
  TILE_SIZE,
  worldToGrid,
} from './mapData';
import {
  advanceBattery,
  advanceNvgBattery,
  applyInteraction,
  computeObjectiveText,
  createInitialRunState,
  evaluateMonsterDetection,
  hasLineOfSight,
  resolveCircleAABBs,
} from './rules';

test('map connectivity: spawn reaches all fuses, batteries, generator, key cabinet, exit, and waypoints', () => {
  const start = worldToGrid(PLAYER_SPAWN.x, PLAYER_SPAWN.z);
  assert.equal(isWallTile(start.col, start.row), false, 'Player spawn must be walkable');

  const visited = new Set<string>();
  const queue: Array<{ col: number; row: number }> = [start];
  visited.add(`${start.col},${start.row}`);

  const dirs = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ];

  while (queue.length > 0) {
    const cur = queue.shift()!;
    for (const [dc, dr] of dirs) {
      const nc = cur.col + dc;
      const nr = cur.row + dr;
      const key = `${nc},${nr}`;
      if (nc >= 0 && nc < MAP_COLS && nr >= 0 && nr < MAP_ROWS && !isWallTile(nc, nr) && !visited.has(key)) {
        visited.add(key);
        queue.push({ col: nc, row: nr });
      }
    }
  }

  for (const item of createInitialInteractables()) {
    const cell = worldToGrid(item.x, item.z);
    assert.equal(
      visited.has(`${cell.col},${cell.row}`),
      true,
      `Interactable ${item.id} at (${cell.col},${cell.row}) must be reachable from spawn`,
    );
  }

  for (const wp of PATROL_WAYPOINTS) {
    const cell = worldToGrid(wp.x, wp.z);
    assert.equal(
      visited.has(`${cell.col},${cell.row}`),
      true,
      `Waypoint ${wp.id} must be reachable`,
    );
  }
});

test('player spawn starts facing down an open corridor with plenty of clearance', () => {
  for (let step = 1; step <= 4; step++) {
    const checkX = PLAYER_SPAWN.x + step * TILE_SIZE;
    const { col, row } = worldToGrid(checkX, PLAYER_SPAWN.z);
    assert.equal(isWallTile(col, row), false, `Tile ${step} ahead of spawn must be open`);
  }
});

test('circle-vs-AABB collision keeps player outside walls while allowing sliding', () => {
  const walls = buildWallAABBs();
  const wallCenter = gridToWorld(5, 4);
  const res = resolveCircleAABBs(wallCenter.x, wallCenter.z + TILE_SIZE * 0.5, PLAYER_RADIUS, walls);
  assert.ok(
    res.z >= 5 * TILE_SIZE + PLAYER_RADIUS - 1e-4,
    `Expected player pushed out, got ${res.z}`,
  );
});

test('line of sight is open along main corridor and blocked by walls between rooms', () => {
  const west = gridToWorld(2, 5.5);
  const east = gridToWorld(14, 5.5);
  assert.equal(hasLineOfSight(west.x, west.z, east.x, east.z), true);

  const storage = gridToWorld(2, 2);
  const security = gridToWorld(8, 2);
  assert.equal(hasLineOfSight(storage.x, storage.z, security.x, security.z), false);
});

test('monster detection accounts for FOV cone, flashlight range, and walls', () => {
  const basePos = gridToWorld(5, 5.5);
  const playerAhead = gridToWorld(9, 5.5);
  const yawEast = Math.PI / 2;

  const lit = evaluateMonsterDetection({
    monsterX: basePos.x,
    monsterZ: basePos.z,
    monsterYaw: yawEast,
    playerX: playerAhead.x,
    playerZ: playerAhead.z,
    flashlightOn: true,
    playerSprinting: false,
  });
  assert.equal(lit.canSee, true);

  const dark = evaluateMonsterDetection({
    monsterX: basePos.x,
    monsterZ: basePos.z,
    monsterYaw: yawEast,
    playerX: playerAhead.x,
    playerZ: playerAhead.z,
    flashlightOn: false,
    playerSprinting: false,
  });
  assert.equal(dark.canSee, false);
});

test('flashlight battery drains and triggers low-battery flicker below threshold', () => {
  const r1 = advanceBattery(100, true, 10);
  assert.ok(r1.battery < 100 && r1.battery > 50);
  assert.equal(r1.flashlightOn, true);
  assert.equal(r1.flickering, false);

  const r2 = advanceBattery(15, true, 1);
  assert.equal(r2.flickering, true);
});

test('full progression loop: fuses -> generator -> hammer -> cutters -> key -> exit door -> escape', () => {
  const state = createInitialRunState();
  const items = createInitialInteractables();
  const fuses = items.filter((i) => i.kind === 'fuse');
  const gen = items.find((i) => i.kind === 'generator')!;
  const hammer = items.find((i) => i.kind === 'hammer')!;
  const cutters = items.find((i) => i.kind === 'wire_cutters')!;
  const cabinet = items.find((i) => i.kind === 'key_cabinet')!;
  const exitDoor = items.find((i) => i.kind === 'exit_door')!;

  // Pick up 3 fuses & restore power
  for (const fuse of fuses) applyInteraction(state, fuse);
  applyInteraction(state, gen);
  assert.equal(state.powerRestored, true);

  // Pick up Hammer & remove planks
  applyInteraction(state, hammer);
  assert.equal(state.hasHammer, true);
  applyInteraction(state, exitDoor);
  assert.equal(state.planksRemoved, true);

  // Pick up Wire Cutters & disable alarm
  applyInteraction(state, cutters);
  assert.equal(state.hasWireCutters, true);
  applyInteraction(state, exitDoor);
  assert.equal(state.alarmDisabled, true);

  // Grab key from Security locker
  applyInteraction(state, cabinet);
  assert.equal(state.hasExitKey, true);

  // Final escape via exit door
  const exitRes = applyInteraction(state, exitDoor);
  assert.equal(exitRes.changed, true);
  assert.equal(state.escaped, true);
});

test('nightstand drawer opens and reveals contained items; closed nightstand keeps items hidden', () => {
  const state = createInitialRunState();
  const items = createInitialInteractables();
  const nsSec = items.find((i) => i.id === 'nightstand_sec')!;
  const nvg = items.find((i) => i.id === 'nvg_tool')!;

  assert.equal(nsSec.isOpen, false);
  assert.equal(nvg.insideNightstandId, 'nightstand_sec');

  // Open drawer
  const openRes = applyInteraction(state, nsSec, items);
  assert.equal(openRes.changed, true);
  assert.equal(nsSec.isOpen, true);
  assert.equal(nvg.insideNightstandId, undefined, 'Item inside nightstand must be revealed when opened');

  // Close drawer
  const closeRes = applyInteraction(state, nsSec, items);
  assert.equal(closeRes.changed, true);
  assert.equal(nsSec.isOpen, false);
  assert.equal(nvg.insideNightstandId, 'nightstand_sec', 'Item must be hidden when drawer is closed again');
});

test('3-slot inventory requires selecting active slot to perform specialized actions', () => {
  const state = createInitialRunState();
  const items = createInitialInteractables();
  const fuses = items.filter((i) => i.kind === 'fuse');
  const gen = items.find((i) => i.kind === 'generator')!;
  const hammer = items.find((i) => i.kind === 'hammer')!;
  const exitDoor = items.find((i) => i.kind === 'exit_door')!;

  for (const fuse of fuses) applyInteraction(state, fuse);
  applyInteraction(state, gen);
  assert.equal(state.powerRestored, true);

  // Pick up hammer (goes into slot 0, activeSlotIndex becomes 0)
  applyInteraction(state, hammer);
  assert.equal(state.hasHammer, true);
  assert.equal(state.inventory[0], 'hammer');

  // If user switches active slot to slot 1 (empty slot), attempting to break planks warns user
  state.activeSlotIndex = 1;
  const blockedRes = applyInteraction(state, exitDoor);
  assert.equal(blockedRes.changed, false);
  assert.equal(state.planksRemoved, false);
  assert.match(blockedRes.message, /Выберите Молоток в слоте/);

  // Switch back to slot 0 (hammer) and retry
  state.activeSlotIndex = 0;
  const breakRes = applyInteraction(state, exitDoor);
  assert.equal(breakRes.changed, true);
  assert.equal(state.planksRemoved, true);
});

test('night vision goggles (ПНВ) drain battery and auto-deactivate when exhausted', () => {
  const state = createInitialRunState();
  const items = createInitialInteractables();
  const nvg = items.find((i) => i.kind === 'nvg')!;

  applyInteraction(state, nvg);
  assert.equal(state.hasNvg, true);
  assert.ok(state.inventory.includes('nvg'));

  // NVG battery drain test
  const full = advanceNvgBattery(100, true, 5);
  assert.ok(full.nvgBattery < 100 && full.nvgBattery > 50);
  assert.equal(full.nvgOn, true);

  // Depleted battery auto-turns off
  const drained = advanceNvgBattery(1, true, 5);
  assert.equal(drained.nvgBattery, 0);
  assert.equal(drained.nvgOn, false);
});

