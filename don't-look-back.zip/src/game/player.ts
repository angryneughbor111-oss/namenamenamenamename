import * as THREE from 'three';
import { PLAYER_EYE_HEIGHT, PLAYER_RADIUS, PLAYER_SPAWN } from './mapData';
import { resolveCircleAABBs } from './rules';
import type { AABB, InteractableItem, InventoryItemType } from './types';

export interface PlayerInputState {
  keys: Set<string>;
  mouseDeltaX: number;
  mouseDeltaY: number;
}

const _fwd = new THREE.Vector3();
const _targetPos = new THREE.Vector3();

export class FirstPersonPlayer {
  readonly camera: THREE.PerspectiveCamera;
  readonly flashlight: THREE.SpotLight;
  readonly flashlightTarget: THREE.Object3D;
  readonly nvgLight: THREE.PointLight;

  // First-person held item viewmodel
  private heldItemGroup: THREE.Group;
  private heldHammer: THREE.Group;
  private heldCutters: THREE.Group;
  private heldKey: THREE.Group;
  private heldNvg: THREE.Group;

  x = PLAYER_SPAWN.x;
  z = PLAYER_SPAWN.z;
  yaw = PLAYER_SPAWN.yaw;
  pitch = 0;

  private bobDistance = 0;
  private stepAccum = 0;
  private bobOffsetY = 0;
  private flashlightSwayYaw = PLAYER_SPAWN.yaw;
  private flashlightSwayPitch = 0;

  isMoving = false;
  isSprinting = false;

  constructor(scene: THREE.Scene, aspect: number) {
    this.camera = new THREE.PerspectiveCamera(72, aspect, 0.05, 65);
    this.camera.rotation.order = 'YXZ';

    this.flashlight = new THREE.SpotLight(0xfff1d6, 26.0, 45, Math.PI / 3.5, 0.45, 1.2);
    this.flashlightTarget = new THREE.Object3D();
    scene.add(this.flashlight);
    scene.add(this.flashlightTarget);
    this.flashlight.target = this.flashlightTarget;

    // Green night vision phosphorescent emitter
    this.nvgLight = new THREE.PointLight(0x22c55e, 0, 18, 1.4);
    this.camera.add(this.nvgLight);
    scene.add(this.camera);

    // Build first-person held item viewmodel
    this.heldItemGroup = new THREE.Group();
    this.heldItemGroup.position.set(0.24, -0.22, -0.45);
    this.camera.add(this.heldItemGroup);

    // 1. Held Hammer
    this.heldHammer = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x6d4327, roughness: 0.8 });
    const ironMat = new THREE.MeshStandardMaterial({ color: 0x374151, roughness: 0.4, metalness: 0.8 });
    const hHandle = new THREE.Mesh(new THREE.CylinderGeometry(0.016, 0.018, 0.32, 8), woodMat);
    hHandle.rotation.z = Math.PI / 3.5;
    this.heldHammer.add(hHandle);
    const hHead = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.05, 0.06), ironMat);
    hHead.position.set(0.12, 0.11, 0);
    this.heldHammer.add(hHead);
    this.heldItemGroup.add(this.heldHammer);

    // 2. Held Wire Cutters
    this.heldCutters = new THREE.Group();
    const gripMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.4 });
    const cHandleL = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.015, 0.22, 6), gripMat);
    cHandleL.position.set(-0.03, -0.05, 0);
    this.heldCutters.add(cHandleL);
    const cHandleR = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.015, 0.22, 6), gripMat);
    cHandleR.position.set(0.03, -0.05, 0);
    this.heldCutters.add(cHandleR);
    const cJaw = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 0.03), ironMat);
    cJaw.position.set(0, 0.08, 0);
    this.heldCutters.add(cJaw);
    this.heldItemGroup.add(this.heldCutters);

    // 3. Held Exit Key
    this.heldKey = new THREE.Group();
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0x78350f,
      emissiveIntensity: 0.5,
      roughness: 0.2,
      metalness: 0.9,
    });
    const kRing = new THREE.Mesh(new THREE.TorusGeometry(0.035, 0.008, 6, 12), goldMat);
    kRing.position.y = 0.06;
    this.heldKey.add(kRing);
    const kShaft = new THREE.Mesh(new THREE.BoxGeometry(0.014, 0.12, 0.008), goldMat);
    kShaft.position.y = -0.02;
    this.heldKey.add(kShaft);
    const kTeeth = new THREE.Mesh(new THREE.BoxGeometry(0.028, 0.02, 0.008), goldMat);
    kTeeth.position.set(0.015, -0.06, 0);
    this.heldKey.add(kTeeth);
    this.heldItemGroup.add(this.heldKey);

    // 4. Held NVG Goggles
    this.heldNvg = new THREE.Group();
    const nvgBody = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.08, 0.1), ironMat);
    this.heldNvg.add(nvgBody);
    const lensMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      emissive: 0x059669,
      emissiveIntensity: 1.2,
      roughness: 0.1,
    });
    const lensL = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.04, 8), lensMat);
    lensL.rotation.x = Math.PI / 2;
    lensL.position.set(-0.04, 0, 0.06);
    this.heldNvg.add(lensL);
    const lensR = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.04, 8), lensMat);
    lensR.rotation.x = Math.PI / 2;
    lensR.position.set(0.04, 0, 0.06);
    this.heldNvg.add(lensR);
    this.heldItemGroup.add(this.heldNvg);

    this.setHeldItem(null);
    this.reset();
  }

  setHeldItem(item: InventoryItemType | null): void {
    this.heldHammer.visible = item === 'hammer';
    this.heldCutters.visible = item === 'wire_cutters';
    this.heldKey.visible = item === 'exit_key';
    this.heldNvg.visible = item === 'nvg';
    this.heldItemGroup.visible = item !== null;
  }

  reset(spawn?: { x: number; z: number; yaw: number }): void {
    const s = spawn ?? PLAYER_SPAWN;
    this.x = s.x;
    this.z = s.z;
    this.yaw = s.yaw;
    this.pitch = 0;
    this.bobDistance = 0;
    this.stepAccum = 0;
    this.bobOffsetY = 0;
    this.flashlightSwayYaw = this.yaw;
    this.flashlightSwayPitch = 0;
    this.setHeldItem(null);
    this.syncCameraAndLight(1, true, false, 0, false, false);
  }

  update(
    dt: number,
    input: PlayerInputState,
    wallAABBs: readonly AABB[],
    flashlightOn: boolean,
    flickering: boolean,
    nvgOn: boolean,
    timeSec: number,
    onFootstep: (sprint: boolean) => void,
  ): void {
    // Mouse look
    const mouseSens = 0.0022;
    this.yaw -= input.mouseDeltaX * mouseSens;
    this.pitch -= input.mouseDeltaY * mouseSens;
    input.mouseDeltaX = 0;
    input.mouseDeltaY = 0;

    // Optional arrow-key look fallback
    const keyTurnSpeed = 2.0;
    if (input.keys.has('ArrowLeft')) this.yaw += keyTurnSpeed * dt;
    if (input.keys.has('ArrowRight')) this.yaw -= keyTurnSpeed * dt;
    if (input.keys.has('ArrowUp')) this.pitch += 1.2 * dt;
    if (input.keys.has('ArrowDown')) this.pitch -= 1.2 * dt;

    this.pitch = THREE.MathUtils.clamp(this.pitch, -1.38, 1.38);

    // Movement
    let moveFwd = 0;
    let moveRight = 0;
    if (input.keys.has('KeyW')) moveFwd += 1;
    if (input.keys.has('KeyS')) moveFwd -= 1;
    if (input.keys.has('KeyD')) moveRight += 1;
    if (input.keys.has('KeyA')) moveRight -= 1;

    const len = Math.hypot(moveFwd, moveRight);
    this.isMoving = len > 0.01;
    const isCrouching =
      this.isMoving &&
      (input.keys.has('ControlLeft') || input.keys.has('ControlRight') || input.keys.has('KeyC'));
    this.isSprinting =
      this.isMoving && !isCrouching && (input.keys.has('ShiftLeft') || input.keys.has('ShiftRight'));

    if (this.isMoving) {
      moveFwd /= len;
      moveRight /= len;

      const fwdX = -Math.sin(this.yaw);
      const fwdZ = -Math.cos(this.yaw);
      const rightX = Math.cos(this.yaw);
      const rightZ = -Math.sin(this.yaw);

      const speed = this.isSprinting ? 6.5 : isCrouching ? 2.1 : 4.0;
      const vx = (fwdX * moveFwd + rightX * moveRight) * speed;
      const vz = (fwdZ * moveFwd + rightZ * moveRight) * speed;

      const nextX = this.x + vx * dt;
      const nextZ = this.z + vz * dt;
      const resolved = resolveCircleAABBs(nextX, nextZ, PLAYER_RADIUS, wallAABBs);

      const movedDist = Math.hypot(resolved.x - this.x, resolved.z - this.z);
      this.x = resolved.x;
      this.z = resolved.z;

      this.bobDistance += movedDist * (isCrouching ? 1.4 : 2.1);
      this.stepAccum += movedDist;
      const strideLen = this.isSprinting ? 1.85 : isCrouching ? 2.2 : 1.55;
      if (this.stepAccum >= strideLen) {
        this.stepAccum = 0;
        if (!isCrouching) {
          onFootstep(this.isSprinting);
        }
      }

      const bobAmp = this.isSprinting ? 0.042 : isCrouching ? 0.012 : 0.024;
      this.bobOffsetY = Math.sin(this.bobDistance * 2) * bobAmp;
    } else {
      const decay = Math.exp(-12 * dt);
      this.bobOffsetY *= decay;
    }

    // Viewmodel held item bobbing
    if (this.heldItemGroup.visible) {
      const swayX = Math.sin(this.bobDistance) * 0.015;
      const swayY = Math.abs(Math.sin(this.bobDistance * 2)) * 0.015;
      this.heldItemGroup.position.set(0.24 + swayX, -0.22 - swayY, -0.45);
    }

    this.syncCameraAndLight(dt, flashlightOn, flickering, timeSec, isCrouching, nvgOn);
  }

  private syncCameraAndLight(
    dt: number,
    flashlightOn: boolean,
    flickering: boolean,
    timeSec: number,
    isCrouching: boolean,
    nvgOn: boolean,
  ): void {
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);

    const targetEye = isCrouching ? PLAYER_EYE_HEIGHT - 0.5 : PLAYER_EYE_HEIGHT;
    const currentEyeY = this.camera.position.y - this.bobOffsetY;
    const lerpedEyeY = THREE.MathUtils.lerp(currentEyeY, targetEye, 1 - Math.exp(-14 * dt));

    this.camera.position.set(this.x, lerpedEyeY + this.bobOffsetY, this.z);
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;

    // Flashlight hand lag
    const dampAlpha = 1 - Math.exp(-16 * dt);
    this.flashlightSwayYaw += (this.yaw - this.flashlightSwayYaw) * dampAlpha;
    this.flashlightSwayPitch += (this.pitch - this.flashlightSwayPitch) * dampAlpha;

    this.flashlight.position.set(
      this.camera.position.x + rightX * 0.14,
      this.camera.position.y - 0.12,
      this.camera.position.z + rightZ * 0.14,
    );

    _fwd.set(
      -Math.sin(this.flashlightSwayYaw) * Math.cos(this.flashlightSwayPitch),
      Math.sin(this.flashlightSwayPitch),
      -Math.cos(this.flashlightSwayYaw) * Math.cos(this.flashlightSwayPitch),
    );
    _targetPos.copy(this.flashlight.position).addScaledVector(_fwd, 6);
    this.flashlightTarget.position.copy(_targetPos);

    if (!flashlightOn) {
      this.flashlight.intensity = 0;
    } else if (flickering) {
      const stutter =
        Math.sin(timeSec * 37) * Math.sin(timeSec * 19 + 1.2) > -0.25 ? 1 : 0.12;
      this.flashlight.intensity = 26.0 * stutter;
    } else {
      this.flashlight.intensity = 26.0;
    }

    // NVG Light
    this.nvgLight.intensity = nvgOn ? 4.8 : 0;
  }

  findBestInteractable(interactables: readonly InteractableItem[]): InteractableItem | null {
    const fwdX = -Math.sin(this.yaw) * Math.cos(this.pitch);
    const fwdY = Math.sin(this.pitch);
    const fwdZ = -Math.cos(this.yaw) * Math.cos(this.pitch);

    let best: InteractableItem | null = null;
    let bestScore = -1;

    for (let i = 0; i < interactables.length; i++) {
      const item = interactables[i];

      // Ignore collected items
      if (item.collected) continue;

      // Ignore items hidden inside a closed nightstand
      if (item.insideNightstandId) continue;

      const dx = item.x - this.x;
      const dy = item.y - PLAYER_EYE_HEIGHT;
      const dz = item.z - this.z;
      const dist = Math.hypot(dx, dy, dz);

      const maxRange =
        item.kind === 'exit_door' || item.kind === 'generator'
          ? 3.2
          : item.kind === 'nightstand' || item.kind === 'door'
            ? 2.85
            : 2.6;
      if (dist > maxRange || dist < 0.05) continue;

      const dot = (dx * fwdX + dy * fwdY + dz * fwdZ) / dist;
      const minDot =
        item.kind === 'exit_door' || item.kind === 'generator' || item.kind === 'door'
          ? 0.52
          : 0.65;
      if (dot < minDot) continue;

      const score = dot * 2 - dist * 0.25;
      if (score > bestScore) {
        bestScore = score;
        best = item;
      }
    }
    return best;
  }
}
