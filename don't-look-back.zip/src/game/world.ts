import * as THREE from 'three';
import {
  gridToWorld,
  MAP_COLS,
  MAP_LAYOUT,
  MAP_ROWS,
  TILE_SIZE,
  WALL_HEIGHT,
} from './mapData';
import type { InteractableItem } from './types';

export interface LampRig {
  light: THREE.PointLight | null;
  tubeMat: THREE.MeshStandardMaterial;
  baseIntensity: number;
  flickerPhase: number;
  alwaysOnWhenPowered: boolean;
  shortCircuited: boolean;
}

export interface WorldRefs {
  root: THREE.Group;
  lamps: LampRig[];
  itemMeshes: Map<string, THREE.Group>;
  generatorFuseLeds: THREE.MeshStandardMaterial[];
  generatorPowerLed: THREE.MeshStandardMaterial;
  cabinetLed: THREE.MeshStandardMaterial;
  cabinetDoor: THREE.Mesh;
  cabinetKeyMesh: THREE.Group;
  exitBeaconMat: THREE.MeshStandardMaterial;
  exitDoorLeaves: THREE.Mesh[];
  exitPlanksGroup: THREE.Group;
  exitAlarmLedMat: THREE.MeshStandardMaterial;
  turbineRotor: THREE.Group;
  dustPoints: THREE.Points;
  disposables: Array<{ dispose: () => void }>;
}

function makePixelTexture(
  width: number,
  height: number,
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void,
  maxAniso: number,
  repeatX = 1,
  repeatY = 1,
  isColor = true,
): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  draw(ctx, width, height);

  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeatX, repeatY);
  tex.magFilter = THREE.NearestFilter;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.anisotropy = maxAniso;
  if (isColor) {
    tex.colorSpace = THREE.SRGBColorSpace;
  }
  tex.needsUpdate = true;
  return tex;
}

export function buildComplexWorld(
  scene: THREE.Scene,
  interactables: InteractableItem[],
  maxAniso: number,
): WorldRefs {
  const root = new THREE.Group();
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(res: T): T => {
    disposables.push(res);
    return res;
  };

  // ==========================================
  // PROCEDURAL RETRO-CORPORATE TEXTURES
  // ==========================================

  // 1. Warm Oak / Walnut Parquet Floor
  const parquetTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#4a2f1b';
        ctx.fillRect(0, 0, w, h);
        const plankH = 16;
        for (let y = 0; y < h; y += plankH) {
          const rowOffset = (y / plankH) % 2 === 0 ? 0 : 16;
          for (let x = -rowOffset; x < w; x += 32) {
            const tone = Math.floor(Math.random() * 20);
            ctx.fillStyle = `rgb(${72 + tone}, ${45 + tone * 0.7}, ${24 + tone * 0.4})`;
            ctx.fillRect(Math.max(0, x + 1), y + 1, 30, plankH - 2);
            ctx.fillStyle = 'rgba(35, 18, 8, 0.35)';
            for (let g = 0; g < 3; g++) {
              ctx.fillRect(Math.max(0, x + 4 + g * 8), y + 2, 6, 1);
            }
          }
        }
        ctx.strokeStyle = '#221208';
        ctx.lineWidth = 1;
        for (let y = 0; y <= h; y += plankH) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(w, y);
          ctx.stroke();
        }
      },
      maxAniso,
      MAP_COLS * 2,
      MAP_ROWS * 2,
    ),
  );

  // 2. Executive Office Wall (Mahogany Wainscoting + Wallpaper)
  const officeWallTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#2f3133';
        ctx.fillRect(0, 0, w, h * 0.52);
        for (let y = 0; y < h * 0.52; y += 4) {
          for (let x = 0; x < w; x += 4) {
            const v = 44 + Math.floor(Math.random() * 12);
            ctx.fillStyle = `rgb(${v + 2}, ${v + 1}, ${v - 2})`;
            ctx.fillRect(x, y, 2, 2);
          }
        }
        // Brass chair rail moulding
        ctx.fillStyle = '#8a6e38';
        ctx.fillRect(0, h * 0.52 - 3, w, 2);
        ctx.fillStyle = '#bfa15a';
        ctx.fillRect(0, h * 0.52 - 1, w, 2);

        // Lower mahogany wainscoting
        ctx.fillStyle = '#3a1e12';
        ctx.fillRect(0, h * 0.52 + 1, w, h * 0.48);
        ctx.strokeStyle = '#231109';
        ctx.lineWidth = 2;
        ctx.strokeRect(4, h * 0.55, 24, h * 0.38);
        ctx.strokeRect(36, h * 0.55, 24, h * 0.38);
        ctx.fillStyle = '#4c2919';
        ctx.fillRect(6, h * 0.55 + 2, 20, h * 0.38 - 4);
        ctx.fillRect(38, h * 0.55 + 2, 20, h * 0.38 - 4);

        // Dark baseboard
        ctx.fillStyle = '#1c0c05';
        ctx.fillRect(0, h - 5, w, 5);
      },
      maxAniso,
      1,
      1,
    ),
  );

  // 3. Cafeteria Ceramic Tile
  const cafeteriaTileTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#181b1c';
        ctx.fillRect(0, 0, w, h);
        const tileSize = 32;
        for (let y = 0; y < h; y += tileSize) {
          for (let x = 0; x < w; x += tileSize) {
            const isIvory = (x / tileSize + y / tileSize) % 2 === 0;
            ctx.fillStyle = isIvory ? '#6d685e' : '#35433a';
            ctx.fillRect(x + 1, y + 1, tileSize - 2, tileSize - 2);
          }
        }
      },
      maxAniso,
      4,
      4,
    ),
  );

  // 4. Basement Concrete Wall & Tread Floor
  const basementWallTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#2b2f33';
        ctx.fillRect(0, 0, w, h);
        for (let y = 0; y < h; y += 2) {
          for (let x = 0; x < w; x += 2) {
            const v = 38 + Math.floor(Math.random() * 16);
            ctx.fillStyle = `rgb(${v}, ${v + 1}, ${v + 3})`;
            ctx.fillRect(x, y, 2, 2);
          }
        }
        ctx.fillStyle = 'rgba(12, 16, 20, 0.6)';
        ctx.fillRect(18, 0, 4, h);
      },
      maxAniso,
      1,
      1,
    ),
  );

  const basementFloorTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#1d2024';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#2c3138';
        for (let y = 4; y < h; y += 16) {
          for (let x = 4; x < w; x += 16) {
            ctx.fillRect(x, y, 4, 2);
            ctx.fillRect(x + 8, y + 8, 4, 2);
          }
        }
        ctx.strokeStyle = '#121417';
        ctx.lineWidth = 1;
        ctx.strokeRect(0, 0, w, h);
      },
      maxAniso,
      8,
      8,
    ),
  );

  // 5. Acoustic Office Grid Ceiling
  const officeCeilingTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#26292e';
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = '#16181b';
        ctx.lineWidth = 2;
        ctx.strokeRect(1, 1, w - 2, h - 2);
      },
      maxAniso,
      MAP_COLS,
      MAP_ROWS,
    ),
  );

  // 6. Hazard Yellow-Black Stripes
  const hazardTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#b8860b';
        ctx.fillRect(0, 0, w, h);
        ctx.fillStyle = '#151515';
        for (let i = -h; i < w + h; i += 16) {
          ctx.beginPath();
          ctx.moveTo(i, 0);
          ctx.lineTo(i + 8, 0);
          ctx.lineTo(i - h + 8, h);
          ctx.lineTo(i - h, h);
          ctx.closePath();
          ctx.fill();
        }
      },
      maxAniso,
      3,
      1,
    ),
  );

  // 7. Polished Furniture Wood
  const woodFurnitureTex = track(
    makePixelTexture(
      64,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#482a17';
        ctx.fillRect(0, 0, w, h);
        for (let y = 0; y < h; y += 4) {
          const v = Math.floor(Math.random() * 14);
          ctx.fillStyle = `rgb(${68 + v}, ${40 + v * 0.6}, ${22 + v * 0.3})`;
          ctx.fillRect(0, y, w, 3);
        }
        ctx.strokeStyle = '#271408';
        ctx.lineWidth = 1;
        ctx.strokeRect(1, 1, w - 2, h - 2);
      },
      maxAniso,
      1,
      1,
    ),
  );

  // ==========================================
  // SHARED MATERIALS
  // ==========================================
  const wallMat = track(
    new THREE.MeshStandardMaterial({
      map: officeWallTex,
      roughness: 0.85,
      metalness: 0.08,
    }),
  );
  const basementWallMat = track(
    new THREE.MeshStandardMaterial({
      map: basementWallTex,
      roughness: 0.92,
      metalness: 0.12,
    }),
  );
  const parquetFloorMat = track(
    new THREE.MeshStandardMaterial({
      map: parquetTex,
      roughness: 0.58,
      metalness: 0.14,
    }),
  );
  const cafeteriaFloorMat = track(
    new THREE.MeshStandardMaterial({
      map: cafeteriaTileTex,
      roughness: 0.45,
      metalness: 0.18,
    }),
  );
  const basementFloorMat = track(
    new THREE.MeshStandardMaterial({
      map: basementFloorTex,
      roughness: 0.72,
      metalness: 0.45,
    }),
  );
  const ceilingMat = track(
    new THREE.MeshStandardMaterial({
      map: officeCeilingTex,
      roughness: 0.95,
      metalness: 0.05,
    }),
  );
  const executiveWoodMat = track(
    new THREE.MeshStandardMaterial({
      map: woodFurnitureTex,
      roughness: 0.42,
      metalness: 0.15,
    }),
  );
  const darkLeatherMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x1f1d1b,
      roughness: 0.65,
      metalness: 0.1,
    }),
  );
  const brushedMetalMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x5a6066,
      roughness: 0.38,
      metalness: 0.82,
    }),
  );
  const darkIronMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x22262a,
      roughness: 0.6,
      metalness: 0.7,
    }),
  );
  const brassTrimMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xc89d44,
      roughness: 0.3,
      metalness: 0.85,
    }),
  );
  const hazardMat = track(
    new THREE.MeshStandardMaterial({
      map: hazardTex,
      roughness: 0.6,
      metalness: 0.15,
    }),
  );
  const contactShadowMat = track(
    new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.48,
      depthWrite: false,
    }),
  );

  // ==========================================
  // FLOORS & CEILINGS
  // ==========================================
  const totalW = MAP_COLS * TILE_SIZE;
  const totalD = MAP_ROWS * TILE_SIZE;

  // Main parquet floor
  const mainFloorGeo = track(new THREE.PlaneGeometry(totalW, totalD));
  const mainFloor = new THREE.Mesh(mainFloorGeo, parquetFloorMat);
  mainFloor.rotation.x = -Math.PI / 2;
  mainFloor.position.set(totalW / 2, 0, totalD / 2);
  root.add(mainFloor);

  // Cafeteria tiled floor
  const cafeGeo = track(new THREE.PlaneGeometry(3 * TILE_SIZE, 3 * TILE_SIZE));
  const cafeFloor = new THREE.Mesh(cafeGeo, cafeteriaFloorMat);
  cafeFloor.rotation.x = -Math.PI / 2;
  const cafePos = gridToWorld(2.0, 2.0);
  cafeFloor.position.set(cafePos.x, 0.005, cafePos.z);
  root.add(cafeFloor);

  // Basement Generator floor
  const baseGenGeo = track(new THREE.PlaneGeometry(5 * TILE_SIZE, 3 * TILE_SIZE));
  const baseGenFloor = new THREE.Mesh(baseGenGeo, basementFloorMat);
  baseGenFloor.rotation.x = -Math.PI / 2;
  const baseGenPos = gridToWorld(7.0, 9.0);
  baseGenFloor.position.set(baseGenPos.x, 0.005, baseGenPos.z);
  root.add(baseGenFloor);

  // Maintenance & Airlock basement floor
  const maintFloorGeo = track(new THREE.PlaneGeometry(19 * TILE_SIZE, 3 * TILE_SIZE));
  const maintFloor = new THREE.Mesh(maintFloorGeo, basementFloorMat);
  maintFloor.rotation.x = -Math.PI / 2;
  const maintPos = gridToWorld(10.0, 13.0);
  maintFloor.position.set(maintPos.x, 0.005, maintPos.z);
  root.add(maintFloor);

  // Office ceiling
  const ceiling = new THREE.Mesh(mainFloorGeo, ceilingMat);
  ceiling.rotation.x = Math.PI / 2;
  ceiling.position.set(totalW / 2, WALL_HEIGHT, totalD / 2);
  root.add(ceiling);

  // ==========================================
  // INSTANCED WALLS
  // ==========================================
  const wallGeo = track(new THREE.BoxGeometry(TILE_SIZE, WALL_HEIGHT, TILE_SIZE));
  let officeWallCount = 0;
  let basementWallCount = 0;

  for (let r = 0; r < MAP_ROWS; r++) {
    for (let c = 0; c < MAP_COLS; c++) {
      if (MAP_LAYOUT[r][c] === '#') {
        if (r >= 8 && r <= 15 && c >= 4 && c <= 10) {
          basementWallCount++;
        } else if (r >= 11) {
          basementWallCount++;
        } else {
          officeWallCount++;
        }
      }
    }
  }

  const officeWallInstanced = new THREE.InstancedMesh(wallGeo, wallMat, officeWallCount);
  const basementWallInstanced = new THREE.InstancedMesh(wallGeo, basementWallMat, basementWallCount);
  const dummy = new THREE.Object3D();
  let owi = 0;
  let bwi = 0;

  for (let r = 0; r < MAP_ROWS; r++) {
    for (let c = 0; c < MAP_COLS; c++) {
      if (MAP_LAYOUT[r][c] === '#') {
        const pos = gridToWorld(c, r);
        dummy.position.set(pos.x, WALL_HEIGHT / 2, pos.z);
        dummy.rotation.set(0, 0, 0);
        dummy.scale.set(1, 1, 1);
        dummy.updateMatrix();

        if (r >= 8 && r <= 15 && c >= 4 && c <= 10) {
          basementWallInstanced.setMatrixAt(bwi++, dummy.matrix);
        } else if (r >= 11) {
          basementWallInstanced.setMatrixAt(bwi++, dummy.matrix);
        } else {
          officeWallInstanced.setMatrixAt(owi++, dummy.matrix);
        }
      }
    }
  }
  officeWallInstanced.instanceMatrix.needsUpdate = true;
  officeWallInstanced.computeBoundingSphere();
  root.add(officeWallInstanced);

  if (basementWallCount > 0) {
    basementWallInstanced.instanceMatrix.needsUpdate = true;
    basementWallInstanced.computeBoundingSphere();
    root.add(basementWallInstanced);
  }

  // ==========================================
  // LIGHTING RIG
  // ==========================================
  const lamps: LampRig[] = [];
  const fixtureGeo = track(new THREE.BoxGeometry(1.2, 0.08, 0.5));
  const diffuserGeo = track(new THREE.BoxGeometry(1.0, 0.02, 0.35));

  const lampSpecs: Array<{
    col: number;
    row: number;
    hasPointLight: boolean;
    color: number;
    intensity: number;
  }> = [
    { col: 2.0, row: 5.5, hasPointLight: true, color: 0xffeedd, intensity: 2.2 },  // Lobby West
    { col: 7.0, row: 5.5, hasPointLight: true, color: 0xffeedd, intensity: 2.0 },  // Lobby Center
    { col: 13.0, row: 5.5, hasPointLight: true, color: 0xffeedd, intensity: 2.0 }, // Lobby East
    { col: 2.0, row: 2.0, hasPointLight: true, color: 0xf5f3ea, intensity: 2.1 },  // Cafeteria
    { col: 7.0, row: 2.0, hasPointLight: true, color: 0x98d4c8, intensity: 2.2 },  // Security Command
    { col: 13.0, row: 2.0, hasPointLight: true, color: 0xffdfb8, intensity: 2.4 }, // Mawrg's Office
    { col: 2.0, row: 9.0, hasPointLight: true, color: 0xe8eef2, intensity: 2.0 },  // Conference Boardroom
    { col: 7.0, row: 9.0, hasPointLight: true, color: 0xf59e0b, intensity: 2.4 },  // Basement Generator
    { col: 13.0, row: 9.0, hasPointLight: true, color: 0xffeedd, intensity: 2.1 }, // Open Office
    { col: 4.0, row: 13.5, hasPointLight: true, color: 0xd98c4a, intensity: 2.0 }, // Maintenance Workshop
    { col: 15.0, row: 13.5, hasPointLight: true, color: 0xef4444, intensity: 2.4 },// Exit Airlock
  ];

  lampSpecs.forEach((spec, idx) => {
    const pos = gridToWorld(spec.col, spec.row);
    const fixture = new THREE.Group();
    fixture.position.set(pos.x, WALL_HEIGHT - 0.04, pos.z);

    const frame = new THREE.Mesh(fixtureGeo, darkIronMat);
    fixture.add(frame);

    const tubeMat = track(
      new THREE.MeshStandardMaterial({
        color: spec.color,
        emissive: spec.color,
        emissiveIntensity: 1.15,
        roughness: 0.25,
      }),
    );
    const diffuser = new THREE.Mesh(diffuserGeo, tubeMat);
    diffuser.position.y = -0.04;
    fixture.add(diffuser);

    let light: THREE.PointLight | null = null;
    if (spec.hasPointLight) {
      light = new THREE.PointLight(spec.color, spec.intensity, 12.0, 1.8);
      light.position.set(0, -0.3, 0);
      fixture.add(light);
    }

    root.add(fixture);
    lamps.push({
      light,
      tubeMat,
      baseIntensity: spec.intensity,
      flickerPhase: idx * 1.5,
      alwaysOnWhenPowered: true,
      shortCircuited: false,
    });
  });

  // ==========================================
  // DOORWAY LINTELS & DIRECTIONAL WALL ARROWS
  // ==========================================
  const lintelGeo = track(new THREE.BoxGeometry(TILE_SIZE, 0.55, 0.42));
  const doorwayPositions = [
    { col: 2.0, row: 4.0 },
    { col: 7.0, row: 4.0 },
    { col: 13.0, row: 4.0 },
    { col: 18.0, row: 4.0 },
    { col: 2.0, row: 7.0 },
    { col: 7.0, row: 7.0 },
    { col: 13.0, row: 7.0 },
    { col: 18.0, row: 7.0 },
    { col: 4.0, row: 11.0 },
    { col: 13.0, row: 11.0 },
  ];
  for (const dp of doorwayPositions) {
    const lp = gridToWorld(dp.col, dp.row);
    const lintel = new THREE.Mesh(lintelGeo, wallMat);
    lintel.position.set(lp.x, WALL_HEIGHT - 0.28, lp.z);
    root.add(lintel);
  }

  // Hallway Directional Signs: Green emergency arrows pointing to exit
  const makeArrowSign = (col: number, row: number, rotY: number, zOff: number) => {
    const tex = track(
      makePixelTexture(
        128,
        32,
        (ctx, w, h) => {
          ctx.fillStyle = '#064e3b';
          ctx.fillRect(0, 0, w, h);
          ctx.strokeStyle = '#10b981';
          ctx.lineWidth = 2;
          ctx.strokeRect(2, 2, w - 4, h - 4);
          ctx.fillStyle = '#f4f4f5';
          ctx.font = 'bold 12px monospace';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('--> ВЫХОД / EXIT -->', w / 2, h / 2);
        },
        maxAniso,
      ),
    );
    const sign = new THREE.Mesh(
      track(new THREE.PlaneGeometry(1.4, 0.35)),
      track(new THREE.MeshStandardMaterial({ map: tex, emissive: 0x064e3b, emissiveIntensity: 0.6 })),
    );
    const p = gridToWorld(col, row);
    sign.position.set(p.x, 2.2, p.z + zOff);
    sign.rotation.y = rotY;
    root.add(sign);
  };
  makeArrowSign(8.0, 5.0, 0, 1.21);
  makeArrowSign(14.0, 5.0, 0, 1.21);
  makeArrowSign(12.0, 6.0, Math.PI, -1.21);

  // ==========================================
  // PROP 1: MAWRG'S EXECUTIVE SUITE
  // ==========================================
  const execSuitePos = gridToWorld(13.0, 2.0);
  const execGroup = new THREE.Group();
  execGroup.position.set(execSuitePos.x, 0, execSuitePos.z);

  const execDeskTop = new THREE.Mesh(track(new THREE.BoxGeometry(2.5, 0.12, 1.2)), executiveWoodMat);
  execDeskTop.position.y = 0.76;
  execGroup.add(execDeskTop);

  const blotter = new THREE.Mesh(track(new THREE.BoxGeometry(1.2, 0.02, 0.7)), darkLeatherMat);
  blotter.position.set(0, 0.83, 0);
  execGroup.add(blotter);

  for (const px of [-0.85, 0.85]) {
    const ped = new THREE.Mesh(track(new THREE.BoxGeometry(0.65, 0.7, 1.05)), executiveWoodMat);
    ped.position.set(px, 0.35, 0);
    execGroup.add(ped);
  }

  // Banker's Lamp
  const lampBase = new THREE.Mesh(track(new THREE.CylinderGeometry(0.09, 0.1, 0.04, 8)), brassTrimMat);
  lampBase.position.set(-0.85, 0.84, 0.25);
  execGroup.add(lampBase);
  const emeraldMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x0f5132,
      emissive: 0x198754,
      emissiveIntensity: 0.65,
    }),
  );
  const lampShade = new THREE.Mesh(track(new THREE.CylinderGeometry(0.08, 0.08, 0.22, 8)), emeraldMat);
  lampShade.rotation.z = Math.PI / 2;
  lampShade.position.set(-0.85, 1.05, 0.25);
  execGroup.add(lampShade);

  // Bookshelf
  const shelfGroup = new THREE.Group();
  shelfGroup.position.set(2.4, 0, -1.1);
  const shelfFrame = new THREE.Mesh(track(new THREE.BoxGeometry(1.6, 2.5, 0.45)), executiveWoodMat);
  shelfFrame.position.y = 1.25;
  shelfGroup.add(shelfFrame);
  execGroup.add(shelfGroup);

  root.add(execGroup);

  // ==========================================
  // PROP 2: CORPORATE CAFETERIA
  // ==========================================
  const cafeCenter = gridToWorld(2.0, 2.0);
  const cafeGroup = new THREE.Group();
  cafeGroup.position.set(cafeCenter.x, 0, cafeCenter.z);

  const counterBody = new THREE.Mesh(track(new THREE.BoxGeometry(0.75, 0.9, 2.2)), brushedMetalMat);
  counterBody.position.set(1.1, 0.45, 0.2);
  cafeGroup.add(counterBody);
  const counterTop = new THREE.Mesh(track(new THREE.BoxGeometry(0.85, 0.08, 2.3)), executiveWoodMat);
  counterTop.position.set(1.1, 0.94, 0.2);
  cafeGroup.add(counterTop);

  const tableTop = new THREE.Mesh(track(new THREE.CylinderGeometry(0.65, 0.65, 0.06, 12)), executiveWoodMat);
  tableTop.position.set(-0.8, 0.74, 0);
  cafeGroup.add(tableTop);
  const tableLeg = new THREE.Mesh(track(new THREE.CylinderGeometry(0.05, 0.05, 0.72, 8)), brushedMetalMat);
  tableLeg.position.set(-0.8, 0.36, 0);
  cafeGroup.add(tableLeg);

  root.add(cafeGroup);

  // ==========================================
  // PROP 3: SECURITY COMMAND & KEY LOCKER
  // ==========================================
  const secCenter = gridToWorld(7.0, 2.2);
  const secGroup = new THREE.Group();
  secGroup.position.set(secCenter.x, 0, secCenter.z);

  const secDesk = new THREE.Mesh(track(new THREE.BoxGeometry(2.4, 0.1, 0.9)), darkIronMat);
  secDesk.position.y = 0.75;
  secGroup.add(secDesk);

  const crtMat = track(new THREE.MeshStandardMaterial({ color: 0x27272a, roughness: 0.6 }));
  const cctvScreenMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x064e3b,
      emissive: 0x059669,
      emissiveIntensity: 0.85,
    }),
  );
  for (let m = 0; m < 3; m++) {
    const mon = new THREE.Mesh(track(new THREE.BoxGeometry(0.55, 0.42, 0.38)), crtMat);
    mon.position.set(-0.6 + m * 0.6, 1.05, -0.1);
    secGroup.add(mon);
    const scr = new THREE.Mesh(track(new THREE.PlaneGeometry(0.44, 0.32)), cctvScreenMat);
    scr.position.set(-0.6 + m * 0.6, 1.06, 0.1);
    secGroup.add(scr);
  }
  root.add(secGroup);

  // Security Key Locker
  const cabPos = gridToWorld(7.0, 1.05);
  const cabGroup = new THREE.Group();
  cabGroup.position.set(cabPos.x, 1.45, cabPos.z - 0.55);

  const cabBack = new THREE.Mesh(track(new THREE.BoxGeometry(0.7, 0.85, 0.25)), darkIronMat);
  cabGroup.add(cabBack);

  const cabinetDoor = new THREE.Mesh(
    track(new THREE.BoxGeometry(0.62, 0.76, 0.05)),
    track(new THREE.MeshStandardMaterial({ color: 0x3b444b, roughness: 0.4, metalness: 0.7 })),
  );
  cabinetDoor.position.set(0, 0, 0.14);
  cabGroup.add(cabinetDoor);

  const cabinetLed = track(
    new THREE.MeshStandardMaterial({
      color: 0xaa2222,
      emissive: 0xcc2222,
      emissiveIntensity: 1.4,
    }),
  );
  const cabLedMesh = new THREE.Mesh(track(new THREE.BoxGeometry(0.08, 0.08, 0.04)), cabinetLed);
  cabLedMesh.position.set(0.22, 0.32, 0.15);
  cabGroup.add(cabLedMesh);

  // Master Exit Key inside locker
  const cabinetKeyMesh = new THREE.Group();
  const keyMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xf4c44e,
      emissive: 0x553d08,
      roughness: 0.25,
      metalness: 0.9,
    }),
  );
  const keyRing = new THREE.Mesh(track(new THREE.TorusGeometry(0.08, 0.022, 6, 10)), keyMat);
  keyRing.position.y = 0.08;
  cabinetKeyMesh.add(keyRing);
  const keyShaft = new THREE.Mesh(track(new THREE.BoxGeometry(0.035, 0.2, 0.02)), keyMat);
  keyShaft.position.y = -0.08;
  cabinetKeyMesh.add(keyShaft);
  const keyTooth = new THREE.Mesh(track(new THREE.BoxGeometry(0.07, 0.04, 0.02)), keyMat);
  keyTooth.position.set(0.03, -0.14, 0);
  cabinetKeyMesh.add(keyTooth);
  cabinetKeyMesh.position.set(0, -0.02, 0.08);
  cabGroup.add(cabinetKeyMesh);
  root.add(cabGroup);

  // ==========================================
  // PROP 4: CONFERENCE BOARDROOM
  // ==========================================
  const confCenter = gridToWorld(2.0, 9.0);
  const confGroup = new THREE.Group();
  confGroup.position.set(confCenter.x, 0, confCenter.z);

  const confTable = new THREE.Mesh(track(new THREE.BoxGeometry(1.2, 0.08, 2.4)), executiveWoodMat);
  confTable.position.y = 0.74;
  confGroup.add(confTable);

  const wbTex = track(
    makePixelTexture(
      128,
      64,
      (ctx, w, h) => {
        ctx.fillStyle = '#f4f4f5';
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = '#3f3f46';
        ctx.lineWidth = 3;
        ctx.strokeRect(2, 2, w - 4, h - 4);
        ctx.strokeStyle = '#dc2626';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(15, 45);
        ctx.lineTo(40, 30);
        ctx.lineTo(70, 50);
        ctx.lineTo(105, 15);
        ctx.stroke();
      },
      maxAniso,
    ),
  );
  const whiteboard = new THREE.Mesh(
    track(new THREE.PlaneGeometry(1.8, 1.1)),
    track(new THREE.MeshStandardMaterial({ map: wbTex, roughness: 0.3 })),
  );
  whiteboard.position.set(-1.18, 1.6, 0);
  whiteboard.rotation.y = Math.PI / 2;
  confGroup.add(whiteboard);
  root.add(confGroup);

  // ==========================================
  // PROP 5: BASEMENT GENERATOR VAULT
  // ==========================================
  const genGroup = new THREE.Group();
  const genCenter = gridToWorld(8.5, 9.2);
  genGroup.position.set(genCenter.x, 0, genCenter.z);

  const genPlinth = new THREE.Mesh(track(new THREE.BoxGeometry(2.3, 0.22, 3.2)), darkIronMat);
  genPlinth.position.y = 0.11;
  genGroup.add(genPlinth);

  const genHazard = new THREE.Mesh(track(new THREE.BoxGeometry(2.36, 0.08, 3.26)), hazardMat);
  genHazard.position.y = 0.04;
  genGroup.add(genHazard);

  const genBody = new THREE.Mesh(track(new THREE.BoxGeometry(1.8, 1.5, 2.5)), darkIronMat);
  genBody.position.y = 0.98;
  genGroup.add(genBody);

  const turbineRotor = new THREE.Group();
  turbineRotor.position.set(0, 1.15, 0);
  const drum = new THREE.Mesh(track(new THREE.CylinderGeometry(0.65, 0.65, 1.6, 12)), brushedMetalMat);
  drum.rotation.x = Math.PI / 2;
  turbineRotor.add(drum);
  for (let fin = 0; fin < 4; fin++) {
    const finMesh = new THREE.Mesh(track(new THREE.BoxGeometry(1.36, 0.08, 1.4)), darkIronMat);
    finMesh.rotation.z = (fin * Math.PI) / 4;
    turbineRotor.add(finMesh);
  }
  genGroup.add(turbineRotor);

  const breakerBox = new THREE.Mesh(track(new THREE.BoxGeometry(0.35, 1.2, 1.1)), darkIronMat);
  breakerBox.position.set(-1.05, 1.25, 0);
  genGroup.add(breakerBox);

  const generatorFuseLeds: THREE.MeshStandardMaterial[] = [];
  const ledGeo = track(new THREE.BoxGeometry(0.06, 0.1, 0.1));
  for (let i = 0; i < 3; i++) {
    const ledMat = track(
      new THREE.MeshStandardMaterial({
        color: 0x331111,
        emissive: 0xaa2222,
        emissiveIntensity: 1.0,
      }),
    );
    generatorFuseLeds.push(ledMat);
    const led = new THREE.Mesh(ledGeo, ledMat);
    led.position.set(-1.22, 1.45, -0.28 + i * 0.28);
    genGroup.add(led);
  }

  const generatorPowerLed = track(
    new THREE.MeshStandardMaterial({
      color: 0xaa2222,
      emissive: 0xaa2222,
      emissiveIntensity: 1.4,
    }),
  );
  const mainLed = new THREE.Mesh(track(new THREE.BoxGeometry(0.08, 0.14, 0.45)), generatorPowerLed);
  mainLed.position.set(-1.22, 1.7, 0);
  genGroup.add(mainLed);

  root.add(genGroup);

  // ==========================================
  // PROP 6: PROMINENT MAIN EXIT AIRLOCK (South Wall)
  // ==========================================
  const exitPos = gridToWorld(15.0, 14.4);
  const exitGroup = new THREE.Group();
  exitGroup.position.set(exitPos.x, 0, exitPos.z);

  // Massive Outer Steel Archway Frame
  const frameSideGeo = track(new THREE.BoxGeometry(0.42, 3.4, 0.48));
  for (const fx of [-1.65, 1.65]) {
    const jamb = new THREE.Mesh(frameSideGeo, darkIronMat);
    jamb.position.set(fx, 1.7, 0);
    exitGroup.add(jamb);
  }
  const frameHeader = new THREE.Mesh(track(new THREE.BoxGeometry(3.7, 0.55, 0.52)), hazardMat);
  frameHeader.position.set(0, 3.12, 0);
  exitGroup.add(frameHeader);

  // Giant Illuminated Green "ВЫХОД / EXIT" Signboard
  const exitSignTex = track(
    makePixelTexture(
      128,
      48,
      (ctx, w, h) => {
        ctx.fillStyle = '#064e3b';
        ctx.fillRect(0, 0, w, h);
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 3;
        ctx.strokeRect(3, 3, w - 6, h - 6);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 18px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('ВЫХОД / EXIT', w / 2, h / 2);
      },
      maxAniso,
    ),
  );
  const exitSignMat = track(
    new THREE.MeshStandardMaterial({
      map: exitSignTex,
      emissive: 0x10b981,
      emissiveIntensity: 1.25,
      roughness: 0.2,
    }),
  );
  const exitSignMesh = new THREE.Mesh(track(new THREE.BoxGeometry(2.4, 0.55, 0.12)), exitSignMat);
  exitSignMesh.position.set(0, 3.5, 0.22);
  exitGroup.add(exitSignMesh);

  // 2 Heavy Blast Door Leaves
  const doorLeafGeo = track(new THREE.BoxGeometry(1.45, 2.85, 0.2));
  const leftLeaf = new THREE.Mesh(doorLeafGeo, darkIronMat);
  leftLeaf.position.set(-0.73, 1.425, 0);
  exitGroup.add(leftLeaf);

  const rightLeaf = new THREE.Mesh(doorLeafGeo, darkIronMat);
  rightLeaf.position.set(0.73, 1.425, 0);
  exitGroup.add(rightLeaf);

  // Barricading Wooden Planks (Hammer mechanic)
  const exitPlanksGroup = new THREE.Group();
  const plankMat = track(new THREE.MeshStandardMaterial({ map: woodFurnitureTex, roughness: 0.9 }));
  const plankGeo = track(new THREE.BoxGeometry(3.3, 0.24, 0.09));
  for (let p = 0; p < 3; p++) {
    const plank = new THREE.Mesh(plankGeo, plankMat);
    plank.position.set(0, 0.95 + p * 0.55, 0.18);
    plank.rotation.z = p % 2 === 0 ? 0.05 : -0.05;
    exitPlanksGroup.add(plank);
  }
  exitGroup.add(exitPlanksGroup);

  // Alarm Junction Box & Status LED (Wire cutters mechanic)
  const alarmBox = new THREE.Mesh(track(new THREE.BoxGeometry(0.38, 0.48, 0.2)), darkIronMat);
  alarmBox.position.set(1.5, 1.6, 0.28);
  exitGroup.add(alarmBox);

  const exitAlarmLedMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xef4444,
      emissive: 0xef4444,
      emissiveIntensity: 1.5,
    }),
  );
  const alarmLed = new THREE.Mesh(track(new THREE.SphereGeometry(0.065, 8, 8)), exitAlarmLedMat);
  alarmLed.position.set(1.5, 1.72, 0.4);
  exitGroup.add(alarmLed);

  // Overhead Rotating Red/Green Beacon
  const exitBeaconMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xcc2222,
      emissive: 0xcc2222,
      emissiveIntensity: 1.6,
      roughness: 0.2,
    }),
  );
  const beacon = new THREE.Mesh(track(new THREE.CylinderGeometry(0.14, 0.14, 0.22, 8)), exitBeaconMat);
  beacon.position.set(0, 3.82, 0);
  exitGroup.add(beacon);

  root.add(exitGroup);

  // ==========================================
  // INTERACTABLE ITEMS (Fuses, Batteries, Tools, Nightstands, Doors)
  // ==========================================
  const itemMeshes = new Map<string, THREE.Group>();
  const shadowCircleGeo = track(new THREE.CircleGeometry(0.28, 12));

  const fuseBodyMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xd97706,
      emissive: 0x7c2d12,
      emissiveIntensity: 0.85,
      roughness: 0.35,
      metalness: 0.3,
    }),
  );
  const brassCapMat = track(
    new THREE.MeshStandardMaterial({
      color: 0xeab308,
      roughness: 0.25,
      metalness: 0.9,
    }),
  );
  const batteryBodyMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x1e293b,
      roughness: 0.45,
      metalness: 0.6,
    }),
  );
  const batteryBandMat = track(
    new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x0284c7,
      emissiveIntensity: 0.95,
      roughness: 0.25,
    }),
  );

  // Highlight Halo Material for Tools
  const amberGlowMat = track(
    new THREE.MeshBasicMaterial({
      color: 0xf59e0b,
      wireframe: true,
      transparent: true,
      opacity: 0.65,
    }),
  );
  const redGlowMat = track(
    new THREE.MeshBasicMaterial({
      color: 0xef4444,
      wireframe: true,
      transparent: true,
      opacity: 0.65,
    }),
  );
  const greenGlowMat = track(
    new THREE.MeshBasicMaterial({
      color: 0x10b981,
      wireframe: true,
      transparent: true,
      opacity: 0.65,
    }),
  );

  for (const item of interactables) {
    if (
      item.kind !== 'fuse' &&
      item.kind !== 'battery' &&
      item.kind !== 'door' &&
      item.kind !== 'hammer' &&
      item.kind !== 'wire_cutters' &&
      item.kind !== 'nvg' &&
      item.kind !== 'nightstand'
    )
      continue;

    const grp = new THREE.Group();
    grp.position.set(item.x, item.y, item.z);

    if (item.kind === 'nightstand') {
      // 3-Part Nightstand / Cabinet with Sliding Drawer
      const carcass = new THREE.Mesh(track(new THREE.BoxGeometry(0.72, 0.72, 0.6)), executiveWoodMat);
      carcass.position.y = 0;
      grp.add(carcass);

      const drawer = new THREE.Group();
      drawer.name = 'drawerMesh';
      const drawerBox = new THREE.Mesh(track(new THREE.BoxGeometry(0.64, 0.3, 0.52)), executiveWoodMat);
      drawer.add(drawerBox);

      // Brass Handle
      const dHandle = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.03, 0.04)), brassTrimMat);
      dHandle.position.set(0, 0, 0.28);
      drawer.add(dHandle);

      drawer.position.set(0, 0.12, 0.02);
      grp.add(drawer);
    } else if (item.kind === 'nvg') {
      // High-Visibility Tactical NVG Monocular/Goggles
      const nvgMesh = new THREE.Group();
      const body = new THREE.Mesh(track(new THREE.BoxGeometry(0.24, 0.12, 0.16)), darkIronMat);
      nvgMesh.add(body);

      const lensMat = track(
        new THREE.MeshStandardMaterial({
          color: 0x10b981,
          emissive: 0x059669,
          emissiveIntensity: 1.5,
          roughness: 0.2,
        }),
      );
      for (const lx of [-0.06, 0.06]) {
        const lens = new THREE.Mesh(track(new THREE.CylinderGeometry(0.04, 0.04, 0.08, 8)), lensMat);
        lens.rotation.x = Math.PI / 2;
        lens.position.set(lx, 0, 0.1);
        nvgMesh.add(lens);
      }
      const halo = new THREE.Mesh(track(new THREE.SphereGeometry(0.25, 8, 8)), greenGlowMat);
      nvgMesh.add(halo);
      grp.add(nvgMesh);
    } else if (item.kind === 'hammer') {
      // High-Visibility Heavy Hammer with Amber Glow Ring
      const hGroup = new THREE.Group();
      const handle = new THREE.Mesh(track(new THREE.CylinderGeometry(0.032, 0.035, 0.48, 8)), executiveWoodMat);
      handle.rotation.z = Math.PI / 2;
      hGroup.add(handle);

      const head = new THREE.Mesh(track(new THREE.BoxGeometry(0.22, 0.09, 0.12)), darkIronMat);
      head.position.set(0.2, 0, 0);
      hGroup.add(head);

      const halo = new THREE.Mesh(track(new THREE.SphereGeometry(0.3, 8, 8)), amberGlowMat);
      hGroup.add(halo);
      grp.add(hGroup);
    } else if (item.kind === 'wire_cutters') {
      // High-Visibility Wire Cutters with Red Handles and Crimson Glow Ring
      const cGroup = new THREE.Group();
      const body = new THREE.Mesh(track(new THREE.BoxGeometry(0.26, 0.06, 0.14)), darkIronMat);
      cGroup.add(body);

      const redGripMat = track(
        new THREE.MeshStandardMaterial({ color: 0xdc2626, emissive: 0x7f1d1d, emissiveIntensity: 0.5 }),
      );
      for (const gz of [-0.06, 0.06]) {
        const handle = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.045, 0.045)), redGripMat);
        handle.position.set(-0.16, 0, gz);
        cGroup.add(handle);
      }

      const halo = new THREE.Mesh(track(new THREE.SphereGeometry(0.28, 8, 8)), redGlowMat);
      cGroup.add(halo);
      grp.add(cGroup);
    } else if (item.kind === 'fuse') {
      const core = new THREE.Mesh(track(new THREE.CylinderGeometry(0.085, 0.085, 0.32, 8)), fuseBodyMat);
      core.rotation.z = Math.PI / 2;
      grp.add(core);

      const capGeo = track(new THREE.CylinderGeometry(0.098, 0.098, 0.08, 8));
      for (const cx of [-0.15, 0.15]) {
        const cap = new THREE.Mesh(capGeo, brassCapMat);
        cap.rotation.z = Math.PI / 2;
        cap.position.x = cx;
        grp.add(cap);
      }
    } else if (item.kind === 'battery') {
      const cell = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.26, 0.12)), batteryBodyMat);
      grp.add(cell);

      const band = new THREE.Mesh(track(new THREE.BoxGeometry(0.19, 0.07, 0.13)), batteryBandMat);
      band.position.y = 0.03;
      grp.add(band);

      const terminal = new THREE.Mesh(track(new THREE.CylinderGeometry(0.025, 0.025, 0.05, 6)), brassCapMat);
      terminal.position.set(-0.04, 0.15, 0);
      grp.add(terminal);
    } else if (item.kind === 'door') {
      // 1-Tile Door: Flush with wall opening (width 2.4m, leaf 2.1m)
      const frameL = new THREE.Mesh(track(new THREE.BoxGeometry(0.15, 2.9, 0.35)), darkIronMat);
      frameL.position.set(-1.1, 1.45, 0);
      grp.add(frameL);

      const frameR = new THREE.Mesh(track(new THREE.BoxGeometry(0.15, 2.9, 0.35)), darkIronMat);
      frameR.position.set(1.1, 1.45, 0);
      grp.add(frameR);

      const doorLeaf = new THREE.Mesh(track(new THREE.BoxGeometry(2.1, 2.75, 0.12)), executiveWoodMat);
      doorLeaf.position.set(0, 1.375, 0);
      doorLeaf.name = 'doorLeaf';
      grp.add(doorLeaf);

      const handle = new THREE.Mesh(track(new THREE.BoxGeometry(0.18, 0.04, 0.08)), brassTrimMat);
      handle.position.set(0.75, 1.25, 0.08);
      doorLeaf.add(handle);
    }

    if (item.kind !== 'door') {
      const cShadow = new THREE.Mesh(shadowCircleGeo, contactShadowMat);
      cShadow.rotation.x = -Math.PI / 2;
      cShadow.position.y = -0.22;
      grp.add(cShadow);
    }

    root.add(grp);
    itemMeshes.set(item.id, grp);
  }

  // Floating Dust Motes
  const dustCount = 160;
  const dustPos = new Float32Array(dustCount * 3);
  for (let i = 0; i < dustCount; i++) {
    dustPos[i * 3] = Math.random() * totalW;
    dustPos[i * 3 + 1] = 0.3 + Math.random() * (WALL_HEIGHT - 0.6);
    dustPos[i * 3 + 2] = Math.random() * totalD;
  }
  const dustGeo = track(new THREE.BufferGeometry());
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
  const dustMat = track(
    new THREE.PointsMaterial({
      color: 0x9aa5b1,
      size: 0.045,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
    }),
  );
  const dustPoints = new THREE.Points(dustGeo, dustMat);
  root.add(dustPoints);

  scene.add(root);

  return {
    root,
    lamps,
    itemMeshes,
    generatorFuseLeds,
    generatorPowerLed,
    cabinetLed,
    cabinetDoor,
    cabinetKeyMesh,
    exitBeaconMat,
    exitDoorLeaves: [leftLeaf, rightLeaf],
    exitPlanksGroup,
    exitAlarmLedMat,
    turbineRotor,
    dustPoints,
    disposables,
  };
}
