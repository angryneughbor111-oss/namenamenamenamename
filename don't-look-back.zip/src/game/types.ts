export type GamePhase = 'title' | 'playing' | 'paused' | 'victory' | 'defeat';

export type MonsterState = 'patrol' | 'chase' | 'search';

export type InventoryItemType = 'hammer' | 'wire_cutters' | 'exit_key' | 'nvg';

export type InteractableKind =
  | 'fuse'
  | 'battery'
  | 'generator'
  | 'key_cabinet'
  | 'exit_key'
  | 'exit_door'
  | 'door'
  | 'hammer'
  | 'wire_cutters'
  | 'nvg'
  | 'nightstand';

export interface AABB {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export interface Point2D {
  x: number;
  z: number;
}

export interface InteractableItem {
  id: string;
  kind: InteractableKind;
  label: string;
  x: number;
  y: number;
  z: number;
  collected: boolean;
  isOpen?: boolean;
  containsItemId?: string;
  insideNightstandId?: string;
}

export interface RunState {
  fusesCarried: number;
  fusesInstalled: number;
  totalFuses: number;
  powerRestored: boolean;
  keyCabinetUnlocked: boolean;
  hasExitKey: boolean;
  hasHammer: boolean;
  hasWireCutters: boolean;
  hasNvg: boolean;
  nvgOn: boolean;
  nvgBattery: number; // 0..100
  inventory: [InventoryItemType | null, InventoryItemType | null, InventoryItemType | null];
  activeSlotIndex: number; // 0..2
  planksRemoved: boolean;
  alarmDisabled: boolean;
  battery: number; // 0..100
  flashlightOn: boolean;
  elapsedSeconds: number;
  batteriesCollected: number;
  escaped: boolean;
  caught: boolean;
}

export interface HudSnapshot {
  phase: GamePhase;
  fusesCarried: number;
  fusesInstalled: number;
  totalFuses: number;
  powerRestored: boolean;
  hasExitKey: boolean;
  hasHammer: boolean;
  hasWireCutters: boolean;
  hasNvg: boolean;
  nvgOn: boolean;
  nvgBattery: number;
  inventory: [InventoryItemType | null, InventoryItemType | null, InventoryItemType | null];
  activeSlotIndex: number;
  planksRemoved: boolean;
  alarmDisabled: boolean;
  battery: number;
  flashlightOn: boolean;
  flashlightFlickering: boolean;
  objective: string;
  promptText: string | null;
  promptSubtext: string | null;
  roomName: string;
  statusBanner: string | null;
  dangerLevel: number; // 0..1 proximity / chase intensity
  elapsedSeconds: number;
  pointerLocked: boolean;
  muted: boolean;
}
