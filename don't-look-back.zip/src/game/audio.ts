export class HorrorAudio {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private droneGain: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private muted = false;
  private paused = false;
  private unlocked = false;
  private lastHeartbeat = 0;

  unlock(): void {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : 0.75;
      this.masterGain.connect(this.ctx.destination);
      this.noiseBuffer = this.createNoiseBuffer(this.ctx);
      this.startAmbientDrone();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    this.unlocked = true;
  }

  setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.75, this.ctx.currentTime, 0.04);
    }
  }

  isMuted(): boolean {
    return this.muted;
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
    if (this.droneGain && this.ctx) {
      this.droneGain.gain.setTargetAtTime(paused ? 0 : 0.14, this.ctx.currentTime, 0.08);
    }
  }

  dispose(): void {
    if (this.ctx) {
      void this.ctx.close();
      this.ctx = null;
      this.masterGain = null;
      this.droneGain = null;
    }
  }

  private createNoiseBuffer(ctx: AudioContext): AudioBuffer {
    const length = ctx.sampleRate * 2;
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < length; i++) {
      const white = Math.random() * 2 - 1;
      // Brownish noise for deep industrial rumble
      lastOut = (lastOut + 0.04 * white) / 1.04;
      data[i] = lastOut * 3.2;
    }
    return buffer;
  }

  private startAmbientDrone(): void {
    if (!this.ctx || !this.masterGain || !this.noiseBuffer) return;

    this.droneGain = this.ctx.createGain();
    this.droneGain.gain.value = this.paused ? 0 : 0.14;
    this.droneGain.connect(this.masterGain);

    // Ventilation rumble
    const noise = this.ctx.createBufferSource();
    noise.buffer = this.noiseBuffer;
    noise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 165;

    noise.connect(filter);
    filter.connect(this.droneGain);
    noise.start();

    // 55Hz electrical hum
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.value = 55;
    const oscFilter = this.ctx.createBiquadFilter();
    oscFilter.type = 'lowpass';
    oscFilter.frequency.value = 110;
    const oscGain = this.ctx.createGain();
    oscGain.gain.value = 0.07;

    osc.connect(oscFilter);
    oscFilter.connect(oscGain);
    oscGain.connect(this.droneGain);
    osc.start();
  }

  playFootstep(sprint: boolean): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer || this.paused) return;
    const now = this.ctx.currentTime;

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.playbackRate.value = 0.92 + Math.random() * 0.16;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = sprint ? 520 : 380;
    filter.Q.value = 1.4;

    const gain = this.ctx.createGain();
    const vol = sprint ? 0.24 : 0.14;
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    src.start(now, Math.random() * 0.8, 0.1);
  }

  playMonsterStep(proximity: number): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || this.paused) return;
    if (proximity <= 0.02) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(88 + Math.random() * 14, now);
    osc.frequency.exponentialRampToValueAtTime(34, now + 0.18);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.32 * proximity, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.22);
  }

  updateHeartbeat(timeSeconds: number, dangerLevel: number): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || this.paused) return;
    if (dangerLevel < 0.2) return;

    const interval = 0.95 - dangerLevel * 0.52; // 0.95s down to 0.43s
    if (timeSeconds - this.lastHeartbeat < interval) return;
    this.lastHeartbeat = timeSeconds;

    const now = this.ctx.currentTime;
    const beat = (offset: number, amp: number) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(62, now + offset);
      osc.frequency.exponentialRampToValueAtTime(32, now + offset + 0.12);

      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.28 * dangerLevel * amp, now + offset);
      g.gain.exponentialRampToValueAtTime(0.001, now + offset + 0.14);

      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + offset);
      osc.stop(now + offset + 0.15);
    };

    beat(0, 1.0);
    beat(0.14, 0.65);
  }

  playFlashlightClick(on: boolean): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(on ? 1450 : 980, now);
    osc.frequency.exponentialRampToValueAtTime(320, now + 0.03);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.035);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.04);
  }

  playPickup(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    const freqs = [440, 660];
    freqs.forEach((f, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, now + idx * 0.055);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.16, now + idx * 0.055);
      g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.055 + 0.16);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + idx * 0.055);
      osc.stop(now + idx * 0.055 + 0.18);
    });
  }

  playFuseInsert(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(190, now);
    osc.frequency.exponentialRampToValueAtTime(95, now + 0.12);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.22, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.15);
  }

  playPowerRestore(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(65, now);
    osc.frequency.exponentialRampToValueAtTime(220, now + 0.9);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(240, now);
    filter.frequency.exponentialRampToValueAtTime(1200, now + 0.9);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.25, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 1.2);

    osc.connect(filter);
    filter.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 1.25);
  }

  playLocked(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'square';
    osc.frequency.setValueAtTime(130, now);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.1, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  playCreakOrBang(kind: 'creak' | 'bang' | 'spark'): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer || this.paused) return;
    const now = this.ctx.currentTime;

    if (kind === 'bang') {
      const osc = this.ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(110, now);
      osc.frequency.exponentialRampToValueAtTime(28, now + 0.45);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.24, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.52);
    } else if (kind === 'spark') {
      const src = this.ctx.createBufferSource();
      src.buffer = this.noiseBuffer;
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.value = 1800;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.22, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      src.connect(filter);
      filter.connect(g);
      g.connect(this.masterGain);
      src.start(now, 0, 0.26);
    } else {
      // Metallic creak
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(240 + Math.random() * 80, now);
      osc.frequency.linearRampToValueAtTime(195, now + 0.55);
      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 600;
      filter.Q.value = 8;
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime(0.11, now + 0.15);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.65);
      osc.connect(filter);
      filter.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.7);
    }
  }

  playAmbientSting(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || this.paused) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    osc.type = 'sine';
    const baseFreq = 55 + Math.random() * 30;
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.linearRampToValueAtTime(baseFreq * 1.5, now + 1.2);

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(120, now);
    filter.frequency.linearRampToValueAtTime(320, now + 0.8);

    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.09, now + 0.4);
    g.gain.exponentialRampToValueAtTime(0.001, now + 1.8);

    osc.connect(filter);
    filter.connect(g);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 1.85);
  }

  playChaseSting(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    [220, 233.08].forEach((freq) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);
      osc.frequency.linearRampToValueAtTime(freq * 1.4, now + 0.38);

      const filter = this.ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 780;

      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.18, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.55);

      osc.connect(filter);
      filter.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.58);
    });
  }

  playCaughtSting(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = this.ctx.currentTime;

    // Heavy Sub-Bass Jumpscare Rumble
    const subOsc = this.ctx.createOscillator();
    subOsc.type = 'sawtooth';
    subOsc.frequency.setValueAtTime(42, now);
    subOsc.frequency.exponentialRampToValueAtTime(20, now + 0.95);
    const subFilter = this.ctx.createBiquadFilter();
    subFilter.type = 'lowpass';
    subFilter.frequency.value = 85;
    const subGain = this.ctx.createGain();
    subGain.gain.setValueAtTime(0.75, now);
    subGain.gain.exponentialRampToValueAtTime(0.001, now + 1.0);

    subOsc.connect(subFilter);
    subFilter.connect(subGain);
    subGain.connect(this.masterGain);
    subOsc.start(now);
    subOsc.stop(now + 1.05);

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const gNoise = this.ctx.createGain();
    gNoise.gain.setValueAtTime(0.48, now);
    gNoise.gain.exponentialRampToValueAtTime(0.001, now + 0.85);
    src.connect(gNoise);
    gNoise.connect(this.masterGain);
    src.start(now, 0, 0.9);

    [110, 116.5, 311, 622].forEach((freq) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, now);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.24, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.8);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.85);
    });
  }

  playNvgToggle(on: boolean): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    // Relay click
    const clickOsc = this.ctx.createOscillator();
    clickOsc.type = 'square';
    clickOsc.frequency.setValueAtTime(800, now);
    clickOsc.frequency.exponentialRampToValueAtTime(120, now + 0.04);
    const clickGain = this.ctx.createGain();
    clickGain.gain.setValueAtTime(0.2, now);
    clickGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
    clickOsc.connect(clickGain);
    clickGain.connect(this.masterGain);
    clickOsc.start(now);
    clickOsc.stop(now + 0.05);

    // High-pitched capacitor charge whine
    if (on) {
      const whineOsc = this.ctx.createOscillator();
      whineOsc.type = 'sine';
      whineOsc.frequency.setValueAtTime(2200, now + 0.02);
      whineOsc.frequency.exponentialRampToValueAtTime(5800, now + 0.18);
      const whineGain = this.ctx.createGain();
      whineGain.gain.setValueAtTime(0.12, now + 0.02);
      whineGain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
      whineOsc.connect(whineGain);
      whineGain.connect(this.masterGain);
      whineOsc.start(now + 0.02);
      whineOsc.stop(now + 0.3);
    }
  }

  playDrawer(open: boolean): void {
    if (!this.unlocked || !this.ctx || !this.masterGain || !this.noiseBuffer) return;
    const now = this.ctx.currentTime;

    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(open ? 350 : 280, now);
    filter.frequency.exponentialRampToValueAtTime(open ? 220 : 380, now + 0.22);
    filter.Q.value = 2.0;

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    src.start(now, Math.random() * 0.5, 0.25);
  }

  playVictoryChord(): void {
    if (!this.unlocked || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    [220, 277.18, 329.63, 440].forEach((freq, i) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.07);
      const g = this.ctx.createGain();
      g.gain.setValueAtTime(0.14, now + i * 0.07);
      g.gain.exponentialRampToValueAtTime(0.001, now + 1.4);
      osc.connect(g);
      g.connect(this.masterGain);
      osc.start(now + i * 0.07);
      osc.stop(now + 1.45);
    });
  }
}
