import {
  isWallTile,
  MAP_COLS,
  MAP_ROWS,
  TILE_SIZE,
  worldToGrid,
} from './mapData';
import type {
  AABB,
  InteractableItem,
  InventoryItemType,
  RunState,
} from './types';

export const BATTERY_DRAIN_PER_SEC = 1.35;
export const NVG_DRAIN_PER_SEC = 2.85;
export const BATTERY_RECHARGE_AMOUNT = 45;
export const LOW_BATTERY_THRESHOLD = 20;

export function createInitialRunState(): RunState {
  return {
    fusesCarried: 0,
    fusesInstalled: 0,
    totalFuses: 3,
    powerRestored: false,
    keyCabinetUnlocked: false,
    hasExitKey: false,
    hasHammer: false,
    hasWireCutters: false,
    hasNvg: false,
    nvgOn: false,
    nvgBattery: 100,
    inventory: [null, null, null],
    activeSlotIndex: 0,
    planksRemoved: false,
    alarmDisabled: false,
    battery: 100,
    flashlightOn: true,
    elapsedSeconds: 0,
    batteriesCollected: 0,
    escaped: false,
    caught: false,
  };
}

export function putInInventory(
  state: RunState,
  itemType: InventoryItemType,
): number {
  // Check if item is already in a slot
  const existingIdx = state.inventory.indexOf(itemType);
  if (existingIdx !== -1) {
    state.activeSlotIndex = existingIdx;
    return existingIdx;
  }

  // If current active slot is empty, put it there
  if (state.inventory[state.activeSlotIndex] === null) {
    state.inventory[state.activeSlotIndex] = itemType;
    return state.activeSlotIndex;
  }

  // Otherwise find first empty slot
  const emptyIdx = state.inventory.indexOf(null);
  if (emptyIdx !== -1) {
    state.inventory[emptyIdx] = itemType;
    state.activeSlotIndex = emptyIdx;
    return emptyIdx;
  }

  // All 3 slots full: overwrite active slot
  state.inventory[state.activeSlotIndex] = itemType;
  return state.activeSlotIndex;
}

export function resolveCircleAABBs(
  x: number,
  z: number,
  radius: number,
  aabbs: readonly AABB[],
): { x: number; z: number } {
  let curX = x;
  let curZ = z;

  for (let iter = 0; iter < 3; iter++) {
    for (let i = 0; i < aabbs.length; i++) {
      const box = aabbs[i];
      const clampedX = Math.max(box.minX, Math.min(curX, box.maxX));
      const clampedZ = Math.max(box.minZ, Math.min(curZ, box.maxZ));

      const dx = curX - clampedX;
      const dz = curZ - clampedZ;
      const distSq = dx * dx + dz * dz;

      if (distSq < radius * radius) {
        const dist = Math.sqrt(distSq);
        if (dist > 1e-5) {
          const overlap = radius - dist;
          curX += (dx / dist) * overlap;
          curZ += (dz / dist) * overlap;
        } else {
          // Centered inside box: push out along nearest axis
          const left = Math.abs(curX - box.minX);
          const right = Math.abs(curX - box.maxX);
          const top = Math.abs(curZ - box.minZ);
          const bottom = Math.abs(curZ - box.maxZ);
          const minD = Math.min(left, right, top, bottom);

          if (minD === left) curX = box.minX - radius;
          else if (minD === right) curX = box.maxX + radius;
          else if (minD === top) curZ = box.minZ - radius;
          else curZ = box.maxZ + radius;
        }
      }
    }
  }

  return { x: curX, z: curZ };
}

export function hasLineOfSight(
  x1: number,
  z1: number,
  x2: number,
  z2: number,
): boolean {
  const dx = x2 - x1;
  const dz = z2 - z1;
  const dist = Math.hypot(dx, dz);
  if (dist < 0.05) return true;

  const stepSize = TILE_SIZE * 0.2;
  const steps = Math.ceil(dist / stepSize);
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    const sx = x1 + dx * t;
    const sz = z1 + dz * t;
    const { col, row } = worldToGrid(sx, sz);
    if (isWallTile(col, row)) {
      return false;
    }
  }
  return true;
}

export interface DetectionInput {
  monsterX: number;
  monsterZ: number;
  monsterYaw: number;
  playerX: number;
  playerZ: number;
  flashlightOn: boolean;
  playerSprinting: boolean;
}

export interface DetectionResult {
  canSee: boolean;
  canHear: boolean;
  distance: number;
  detected: boolean;
}

export function evaluateMonsterDetection(input: DetectionInput): DetectionResult {
  const dx = input.playerX - input.monsterX;
  const dz = input.playerZ - input.monsterZ;
  const distance = Math.hypot(dx, dz);

  const sightRange = input.flashlightOn ? 16.5 : 8.5;
  const closeSenseRange = 2.8;
  const hearingRange = input.playerSprinting ? 12.0 : 0;

  const los = distance <= Math.max(sightRange, hearingRange) &&
    hasLineOfSight(input.monsterX, input.monsterZ, input.playerX, input.playerZ);

  let inFov = false;
  if (distance > 0.001) {
    const dirX = dx / distance;
    const dirZ = dz / distance;
    const fwdX = Math.sin(input.monsterYaw);
    const fwdZ = Math.cos(input.monsterYaw);
    const dot = dirX * fwdX + dirZ * fwdZ;
    inFov = dot >= 0.4;
  }

  const canSee = los && ((distance <= sightRange && inFov) || distance <= closeSenseRange);
  const canHear = input.playerSprinting && distance <= hearingRange && los;

  return {
    canSee,
    canHear,
    distance,
    detected: canSee || canHear,
  };
}

export function advanceBattery(
  currentBattery: number,
  flashlightOn: boolean,
  dt: number,
): { battery: number; flashlightOn: boolean; flickering: boolean } {
  if (!flashlightOn || currentBattery <= 0) {
    return {
      battery: Math.max(0, currentBattery),
      flashlightOn: false,
      flickering: false,
    };
  }
  const next = Math.max(0, currentBattery - BATTERY_DRAIN_PER_SEC * dt);
  return {
    battery: next,
    flashlightOn: next > 0,
    flickering: next > 0 && next <= LOW_BATTERY_THRESHOLD,
  };
}

export function advanceNvgBattery(
  currentBattery: number,
  nvgOn: boolean,
  dt: number,
): { nvgBattery: number; nvgOn: boolean } {
  if (!nvgOn || currentBattery <= 0) {
    return {
      nvgBattery: Math.max(0, currentBattery),
      nvgOn: false,
    };
  }
  const next = Math.max(0, currentBattery - NVG_DRAIN_PER_SEC * dt);
  return {
    nvgBattery: next,
    nvgOn: next > 0,
  };
}

export interface InteractionOutcome {
  changed: boolean;
  message: string;
  sound: 'pickup' | 'fuse_insert' | 'power_on' | 'key_pickup' | 'unlock_exit' | 'locked';
}

export function applyInteraction(
  state: RunState,
  item: InteractableItem,
  allItems?: InteractableItem[],
): InteractionOutcome {
  if (
    item.collected &&
    (item.kind === 'fuse' ||
      item.kind === 'battery' ||
      item.kind === 'key_cabinet' ||
      item.kind === 'hammer' ||
      item.kind === 'wire_cutters' ||
      item.kind === 'nvg')
  ) {
    return { changed: false, message: '', sound: 'locked' };
  }

  switch (item.kind) {
    case 'nightstand': {
      item.isOpen = !item.isOpen;

      // Reveal or hide contained item
      if (allItems && item.containsItemId) {
        const insideItem = allItems.find((i) => i.id === item.containsItemId);
        if (insideItem && !insideItem.collected) {
          insideItem.insideNightstandId = item.isOpen ? undefined : item.id;
        }
      }

      return {
        changed: true,
        message: item.isOpen ? `${item.label} открыта.` : `${item.label} закрыта.`,
        sound: 'pickup',
      };
    }

    case 'nvg': {
      item.collected = true;
      state.hasNvg = true;
      const slot = putInInventory(state, 'nvg');
      return {
        changed: true,
        message: `Подобран ПНВ (Слот [${slot + 1}]). Нажмите [N] для включения.`,
        sound: 'pickup',
      };
    }

    case 'hammer': {
      item.collected = true;
      state.hasHammer = true;
      const slot = putInInventory(state, 'hammer');
      return {
        changed: true,
        message: `Подобран Тяжелый молоток (Слот [${slot + 1}]). Разбейте доски на выходе.`,
        sound: 'pickup',
      };
    }

    case 'wire_cutters': {
      item.collected = true;
      state.hasWireCutters = true;
      const slot = putInInventory(state, 'wire_cutters');
      return {
        changed: true,
        message: `Подобраны Кусачки (Слот [${slot + 1}]). Отключите сигнализацию шлюза.`,
        sound: 'pickup',
      };
    }

    case 'fuse': {
      item.collected = true;
      state.fusesCarried += 1;
      const totalFound = state.fusesCarried + state.fusesInstalled;
      return {
        changed: true,
        message: `Подобран предохранитель (${totalFound}/${state.totalFuses})`,
        sound: 'pickup',
      };
    }

    case 'battery': {
      item.collected = true;
      state.batteriesCollected += 1;
      state.battery = Math.min(100, state.battery + BATTERY_RECHARGE_AMOUNT);
      state.nvgBattery = Math.min(100, state.nvgBattery + BATTERY_RECHARGE_AMOUNT);
      return {
        changed: true,
        message: `Батареи перезаряжены (+${BATTERY_RECHARGE_AMOUNT}%)`,
        sound: 'pickup',
      };
    }

    case 'generator': {
      if (state.powerRestored) {
        return {
          changed: false,
          message: 'Дизель-генератор работает в штатном режиме.',
          sound: 'locked',
        };
      }
      if (state.fusesCarried <= 0) {
        return {
          changed: false,
          message: `Требуются предохранители (${state.fusesInstalled}/${state.totalFuses} установлено).`,
          sound: 'locked',
        };
      }
      const inserted = state.fusesCarried;
      state.fusesInstalled += inserted;
      state.fusesCarried = 0;

      if (state.fusesInstalled >= state.totalFuses) {
        state.powerRestored = true;
        state.keyCabinetUnlocked = true;
        return {
          changed: true,
          message: 'Питание восстановлено! Оружейный шкафчик охраны разблокирован.',
          sound: 'power_on',
        };
      }
      return {
        changed: true,
        message: `Установлено предохранителей: ${inserted} (${state.fusesInstalled}/${state.totalFuses})`,
        sound: 'fuse_insert',
      };
    }

    case 'key_cabinet': {
      if (state.hasExitKey) {
        return {
          changed: false,
          message: 'Шкафчик пуст.',
          sound: 'locked',
        };
      }
      if (!state.powerRestored) {
        return {
          changed: false,
          message: 'Магнитный замок заблокирован. Восстановите питание генератора.',
          sound: 'locked',
        };
      }
      item.collected = true;
      state.hasExitKey = true;
      const slot = putInInventory(state, 'exit_key');
      return {
        changed: true,
        message: `Получен Ключ выхода (Слот [${slot + 1}])!`,
        sound: 'key_pickup',
      };
    }

    case 'exit_door': {
      if (!state.powerRestored) {
        return {
          changed: false,
          message: 'Шлюз обесточен. Включите дизель-генератор в подвале.',
          sound: 'locked',
        };
      }

      const activeItem = state.inventory[state.activeSlotIndex];

      // 1. Check wooden planks
      if (!state.planksRemoved) {
        if (activeItem === 'hammer') {
          state.planksRemoved = true;
          return {
            changed: true,
            message: 'Доски разбиты тяжелым молотком!',
            sound: 'fuse_insert',
          };
        }
        if (state.hasHammer) {
          return {
            changed: false,
            message: 'Заколочено досками! Выберите Молоток в слоте [1-3].',
            sound: 'locked',
          };
        }
        return {
          changed: false,
          message: 'Выход заколочен досками. Найдите молоток в мастерской.',
          sound: 'locked',
        };
      }

      // 2. Check alarm wires
      if (!state.alarmDisabled) {
        if (activeItem === 'wire_cutters') {
          state.alarmDisabled = true;
          return {
            changed: true,
            message: 'Провода сигнализации перекушены кусачками!',
            sound: 'power_on',
          };
        }
        if (state.hasWireCutters) {
          return {
            changed: false,
            message: 'Сигнализация включена! Выберите Кусачки в слоте [1-3].',
            sound: 'locked',
          };
        }
        return {
          changed: false,
          message: 'Сигнализация заблокирует выход! Найдите кусачки.',
          sound: 'locked',
        };
      }

      // 3. Check exit key
      if (!state.hasExitKey) {
        return {
          changed: false,
          message: 'Шлюз заперт на ключ! Заберите ключ из поста охраны.',
          sound: 'locked',
        };
      }

      if (activeItem !== 'exit_key') {
        return {
          changed: false,
          message: 'Замок шлюза закрыт. Выберите Ключ выхода в слоте [1-3].',
          sound: 'locked',
        };
      }

      state.escaped = true;
      return {
        changed: true,
        message: 'Аварийный гермошлюз открыт! Побег на поверхность... THE END!',
        sound: 'unlock_exit',
      };
    }

    case 'door': {
      item.isOpen = !item.isOpen;
      return {
        changed: true,
        message: item.isOpen ? 'Дверь открыта.' : 'Дверь закрыта.',
        sound: item.isOpen ? 'pickup' : 'locked',
      };
    }

    default:
      return { changed: false, message: '', sound: 'locked' };
  }
}

export function getInteractionPrompt(
  state: RunState,
  item: InteractableItem,
): { title: string; detail: string } {
  const activeItem = state.inventory[state.activeSlotIndex];

  switch (item.kind) {
    case 'nightstand':
      return {
        title: item.isOpen ? '[E] Закрыть тумбочку' : '[E] Открыть тумбочку',
        detail: item.label,
      };

    case 'nvg':
      return { title: '[E] Взять ПНВ', detail: 'Прибор ночного видения' };

    case 'hammer':
      return { title: '[E] Взять Молоток', detail: 'Разбить доски на выходе' };

    case 'wire_cutters':
      return { title: '[E] Взять Кусачки', detail: 'Отключить сигнализацию' };

    case 'fuse':
      return { title: '[E] Взять Предохранитель', detail: 'Для генератора' };

    case 'battery':
      return { title: '[E] Взять Батарею', detail: `+${BATTERY_RECHARGE_AMOUNT}% Заряд` };

    case 'generator':
      if (state.powerRestored) {
        return { title: 'Дизель-генератор', detail: 'Питание в норме' };
      }
      if (state.fusesCarried > 0) {
        return {
          title: `[E] Вставить предохранители (${state.fusesInstalled}/${state.totalFuses})`,
          detail: `В наличии: ${state.fusesCarried}`,
        };
      }
      return {
        title: `Щит генератора (${state.fusesInstalled}/${state.totalFuses})`,
        detail: 'Найдите 3 предохранителя',
      };

    case 'key_cabinet':
      if (!state.powerRestored) {
        return { title: 'Оружейный шкафчик', detail: 'Обесточен — включите генератор' };
      }
      if (!state.hasExitKey) {
        return { title: '[E] Забрать Ключ выхода', detail: 'Магнитный замок открыт' };
      }
      return { title: 'Оружейный шкафчик', detail: 'Пусто' };

    case 'exit_door':
      if (!state.powerRestored) {
        return { title: 'Аварийный гермошлюз', detail: 'Обесточен — нужен генератор' };
      }
      if (!state.planksRemoved) {
        return {
          title: activeItem === 'hammer' ? '[E] Разбить доски молотком' : 'Заколочено досками',
          detail:
            activeItem === 'hammer'
              ? 'Молоток активен'
              : state.hasHammer
                ? 'Выберите молоток в слоте [1-3]'
                : 'Найдите молоток в мастерской',
        };
      }
      if (!state.alarmDisabled) {
        return {
          title: activeItem === 'wire_cutters' ? '[E] Перекусить провода' : 'Сигнализация включена',
          detail:
            activeItem === 'wire_cutters'
              ? 'Кусачки активны'
              : state.hasWireCutters
                ? 'Выберите кусачки в слоте [1-3]'
                : 'Найдите кусачки',
        };
      }
      if (!state.hasExitKey) {
        return { title: 'Аварийный гермошлюз', detail: 'Нужен ключ из поста охраны' };
      }
      return {
        title: activeItem === 'exit_key' ? '[E] Открыть шлюз и сбежать' : 'Замок шлюза',
        detail: activeItem === 'exit_key' ? 'Ключ выхода активен' : 'Выберите ключ в слоте [1-3]',
      };

    case 'door':
      return {
        title: item.isOpen ? '[E] Закрыть дверь' : '[E] Открыть дверь',
        detail: item.label,
      };

    default:
      return { title: item.label, detail: '' };
  }
}

export function computeObjectiveText(state: RunState): string {
  if (state.escaped) return 'Побег удался — THE END!';
  if (!state.powerRestored) {
    const totalFound = state.fusesCarried + state.fusesInstalled;
    if (totalFound < state.totalFuses) {
      return `Найдите 3 предохранителя (${totalFound}/${state.totalFuses})`;
    }
    return 'Запустите генератор в подвале';
  }
  if (!state.planksRemoved) {
    return state.hasHammer
      ? 'Разбейте доски на выходе (выберите молоток)'
      : 'Найдите молоток для досок';
  }
  if (!state.alarmDisabled) {
    return state.hasWireCutters
      ? 'Обесточьте сигнализацию (выберите кусачки)'
      : 'Найдите кусачки для сигнализации';
  }
  if (!state.hasExitKey) return 'Заберите ключ выхода из поста охраны';
  return 'Откройте шлюз ключом и сбегите!';
}
