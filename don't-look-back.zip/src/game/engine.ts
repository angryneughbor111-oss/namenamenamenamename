import * as THREE from 'three';
import { HorrorAudio } from './audio';
import {
  buildWallAABBs,
  createEventZones,
  createInitialInteractables,
  getRoomNameAt,
  gridToWorld,
  PLAYER_SPAWN,
  POSSIBLE_PLAYER_SPAWNS,
  type AtmosphericEventZone,
} from './mapData';
import { StalkerMonster } from './monster';
import { FirstPersonPlayer, type PlayerInputState } from './player';
import {
  advanceBattery,
  advanceNvgBattery,
  applyInteraction,
  computeObjectiveText,
  createInitialRunState,
  getInteractionPrompt,
} from './rules';
import type { AABB, GamePhase, HudSnapshot, InteractableItem, RunState } from './types';
import { buildComplexWorld, type WorldRefs } from './world';

export class HorrorGameEngine {
  private container: HTMLElement;
  private onHudUpdate: (snapshot: HudSnapshot) => void;
  private onContextLostChange: (lost: boolean) => void;

  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private audio = new HorrorAudio();

  private wallAABBs: AABB[];
  private interactables: InteractableItem[];
  private eventZones: AtmosphericEventZone[];
  private triggeredEvents = new Set<string>();
  private world: WorldRefs;
  private player: FirstPersonPlayer;
  private monster: StalkerMonster;

  private phase: GamePhase = 'title';
  private runState: RunState = createInitialRunState();
  private input: PlayerInputState = {
    keys: new Set<string>(),
    mouseDeltaX: 0,
    mouseDeltaY: 0,
  };

  private lastFrameTimeMs = performance.now();
  private elapsedTotal = 0;
  private frameId = 0;
  private disposed = false;

  private bannerText: string | null = null;
  private bannerTimer = 0;
  private redSurgeTimer = 0;
  private nextAmbientSfxTime = 9;
  private defeatTrauma = 0;
  private victoryDoorOpen = 0;
  private cabinetDoorOpen = 0;

  private pointerLocked = false;
  private wasPointerLocked = false;
  private lastHudPush = 0;

  private hemiLight!: THREE.HemisphereLight;
  private dirLight!: THREE.DirectionalLight;
  private fogRef!: THREE.FogExp2;

  setBrightness(val: number): void {
    if (this.hemiLight) this.hemiLight.intensity = 0.85 * val;
    if (this.dirLight) this.dirLight.intensity = 0.45 * val;
  }

  setFogDensity(density: number): void {
    if (this.fogRef) this.fogRef.density = density;
  }

  constructor(
    container: HTMLElement,
    onHudUpdate: (snapshot: HudSnapshot) => void,
    onContextLostChange: (lost: boolean) => void,
  ) {
    this.container = container;
    this.onHudUpdate = onHudUpdate;
    this.onContextLostChange = onContextLostChange;
    this.renderer = new THREE.WebGLRenderer({
      antialias: false,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;
    this.renderer.setPixelRatio(1);
    this.renderer.shadowMap.enabled = false;
    this.renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    container.appendChild(this.renderer.domElement);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x07090f);
    const fog = new THREE.FogExp2(0x07090f, 0.01);
    this.scene.fog = fog;
    this.fogRef = fog;

    const hemi = new THREE.HemisphereLight(0x56718a, 0x241d18, 0.85 * 5.25);
    this.scene.add(hemi);
    this.hemiLight = hemi;

    const rimDir = new THREE.DirectionalLight(0xffecd0, 0.45 * 5.25);
    rimDir.position.set(12, 16, -8);
    this.scene.add(rimDir);
    this.dirLight = rimDir;

    this.interactables = createInitialInteractables();
    this.wallAABBs = buildWallAABBs(this.interactables);
    this.eventZones = createEventZones();

    const maxAniso = Math.min(4, this.renderer.capabilities.getMaxAnisotropy());
    this.world = buildComplexWorld(this.scene, this.interactables, maxAniso);

    const aspect = (container.clientWidth || window.innerWidth) / Math.max(1, container.clientHeight || window.innerHeight);
    this.player = new FirstPersonPlayer(this.scene, aspect);
    this.monster = new StalkerMonster(this.scene);

    this.bindEvents();

    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      this.startNewGame(false, false);
    } else {
      this.syncBodyDataset();
      this.pushHud(true);
    }

    this.lastFrameTimeMs = performance.now();
    this.scheduleNextTick();
  }

  private bindEvents(): void {
    window.addEventListener('resize', this.handleResize);
    window.addEventListener('keydown', this.handleKeyDown);
    window.addEventListener('keyup', this.handleKeyUp);
    window.addEventListener('mousemove', this.handleMouseMove);
    window.addEventListener('wheel', this.handleWheel, { passive: false });
    window.addEventListener('blur', this.handleWindowBlur);
    document.addEventListener('visibilitychange', this.handleVisibilityChange);
    document.addEventListener('pointerlockchange', this.handlePointerLockChange);
    this.renderer.domElement.addEventListener('click', this.handleCanvasClick);
    this.renderer.domElement.addEventListener('mousedown', this.handleMouseDown);
    this.renderer.domElement.addEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.addEventListener('webglcontextrestored', this.handleContextRestored);
  }

  dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    window.removeEventListener('resize', this.handleResize);
    window.removeEventListener('keydown', this.handleKeyDown);
    window.removeEventListener('keyup', this.handleKeyUp);
    window.removeEventListener('mousemove', this.handleMouseMove);
    window.removeEventListener('wheel', this.handleWheel);
    window.removeEventListener('blur', this.handleWindowBlur);
    document.removeEventListener('visibilitychange', this.handleVisibilityChange);
    document.removeEventListener('pointerlockchange', this.handlePointerLockChange);
    this.renderer.domElement.removeEventListener('click', this.handleCanvasClick);
    this.renderer.domElement.removeEventListener('mousedown', this.handleMouseDown);
    this.renderer.domElement.removeEventListener('webglcontextlost', this.handleContextLost);
    this.renderer.domElement.removeEventListener('webglcontextrestored', this.handleContextRestored);

    this.exitPointerLock();
    this.audio.dispose();
    this.monster.dispose();
    this.world.disposables.forEach((d) => d.dispose());
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
  }

  private handleContextLost = (e: Event): void => {
    e.preventDefault();
    this.onContextLostChange(true);
  };

  private handleContextRestored = (): void => {
    this.onContextLostChange(false);
  };

  private handleResize = (): void => {
    if (this.disposed) return;
    const w = this.container.clientWidth || window.innerWidth;
    const h = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.player.camera.aspect = w / h;
    this.player.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
  };

  private handleWindowBlur = (): void => {
    this.input.keys.clear();
    this.input.mouseDeltaX = 0;
    this.input.mouseDeltaY = 0;
  };

  private handleVisibilityChange = (): void => {
    if (document.hidden) {
      this.input.keys.clear();
    }
  };

  private handlePointerLockChange = (): void => {
    const locked = document.pointerLockElement === this.renderer.domElement;
    this.pointerLocked = locked;
    if (this.wasPointerLocked && !locked && this.phase === 'playing') {
      this.pauseGame();
    }
    this.wasPointerLocked = locked;
    this.pushHud(true);
  };

  private handleCanvasClick = (): void => {
    if (this.phase === 'playing') {
      this.audio.unlock();
      this.requestPointerLock();
    }
  };

  private handleMouseDown = (e: MouseEvent): void => {
    if (this.phase !== 'playing') return;
    // Middle click (СКМ) cycles active inventory slot
    if (e.button === 1) {
      e.preventDefault();
      this.selectInventorySlot((this.runState.activeSlotIndex + 1) % 3);
    }
  };

  private handleWheel = (e: WheelEvent): void => {
    if (this.phase !== 'playing') return;
    e.preventDefault();
    if (e.deltaY > 0) {
      this.selectInventorySlot((this.runState.activeSlotIndex + 1) % 3);
    } else if (e.deltaY < 0) {
      this.selectInventorySlot((this.runState.activeSlotIndex + 2) % 3);
    }
  };

  private handleMouseMove = (e: MouseEvent): void => {
    if (this.phase !== 'playing') return;
    if (document.pointerLockElement === this.renderer.domElement) {
      this.input.mouseDeltaX += e.movementX;
      this.input.mouseDeltaY += e.movementY;
    }
  };

  private handleKeyDown = (e: KeyboardEvent): void => {
    this.audio.unlock();

    if (this.phase === 'title') {
      if (e.code === 'Enter' || e.code === 'Space') {
        e.preventDefault();
        this.startNewGame(true);
      }
      return;
    }

    if (e.code === 'KeyM' && !e.repeat) {
      this.toggleMute();
      return;
    }

    if ((e.code === 'Escape' || e.code === 'KeyP') && !e.repeat) {
      if (this.phase === 'playing') {
        this.pauseGame();
        return;
      }
      if (this.phase === 'paused') {
        this.resumeGame();
        return;
      }
    }

    if (this.phase !== 'playing') return;

    this.input.keys.add(e.code);

    if (e.code === 'Digit1') {
      this.selectInventorySlot(0);
    } else if (e.code === 'Digit2') {
      this.selectInventorySlot(1);
    } else if (e.code === 'Digit3') {
      this.selectInventorySlot(2);
    } else if (e.code === 'KeyN' && !e.repeat) {
      this.toggleNvg();
    } else if (e.code === 'KeyF' && !e.repeat) {
      this.toggleFlashlight();
    } else if (e.code === 'KeyE' && !e.repeat) {
      this.tryInteract();
    }
  };

  private handleKeyUp = (e: KeyboardEvent): void => {
    this.input.keys.delete(e.code);
  };

  selectInventorySlot(index: number): void {
    if (index < 0 || index > 2) return;
    this.runState.activeSlotIndex = index;
    const item = this.runState.inventory[index];
    this.player.setHeldItem(item);
    this.pushHud(true);
  }

  toggleNvg(): void {
    if (!this.runState.hasNvg) {
      this.showBanner('ПНВ не найден! Обыщите пост охраны.', 2.5);
      this.pushHud(true);
      return;
    }
    if (this.runState.nvgBattery <= 0) {
      this.showBanner('Батарея ПНВ разряжена! Найдите батареи.', 2.5);
      this.pushHud(true);
      return;
    }
    this.runState.nvgOn = !this.runState.nvgOn;
    this.audio.playNvgToggle(this.runState.nvgOn);
    this.showBanner(this.runState.nvgOn ? 'ПНВ: ВКЛЮЧЕН' : 'ПНВ: ВЫКЛЮЧЕН', 2.0);
    this.pushHud(true);
  }

  requestPointerLock(): void {
    try {
      const promise = this.renderer.domElement.requestPointerLock?.() as unknown as Promise<void> | undefined;
      if (promise && typeof promise.catch === 'function') {
        promise.catch(() => {});
      }
    } catch {}
  }

  private exitPointerLock(): void {
    try {
      if (document.pointerLockElement) {
        document.exitPointerLock?.();
      }
    } catch {}
  }

  startNewGame(lockPointer = true, fromUserGesture = true, randomized = true): void {
    if (fromUserGesture) {
      this.audio.unlock();
      this.audio.setPaused(false);
    }

    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }

    this.runState = createInitialRunState();
    this.interactables = createInitialInteractables(randomized);
    this.wallAABBs = buildWallAABBs(this.interactables);
    this.triggeredEvents.clear();
    this.input.keys.clear();
    this.input.mouseDeltaX = 0;
    this.input.mouseDeltaY = 0;

    const spawnIndex = randomized
      ? Math.floor(Math.random() * POSSIBLE_PLAYER_SPAWNS.length)
      : 0;
    const spawn = POSSIBLE_PLAYER_SPAWNS[spawnIndex];
    this.bannerText = `ЛОКАЦИЯ: ${spawn.locationName.toUpperCase()}`;
    this.bannerTimer = 4.5;
    this.redSurgeTimer = 0;
    this.defeatTrauma = 0;
    this.victoryDoorOpen = 0;
    this.cabinetDoorOpen = 0;
    this.nextAmbientSfxTime = this.elapsedTotal + 10;

    // Reposition interactable meshes in case items were randomized
    for (const item of this.interactables) {
      const mesh = this.world.itemMeshes.get(item.id);
      if (mesh) {
        mesh.position.set(item.x, item.y, item.z);
        mesh.visible = !item.collected;
      }
    }

    this.player.reset(spawn);
    this.monster.reset();
    this.syncWorldVisuals(0);

    this.phase = 'playing';
    this.syncBodyDataset();
    if (lockPointer) {
      this.requestPointerLock();
    }
    this.pushHud(true);
  }

  pauseGame(): void {
    if (this.phase !== 'playing') return;
    this.phase = 'paused';
    this.input.keys.clear();
    this.audio.setPaused(true);
    this.wasPointerLocked = false;
    this.exitPointerLock();
    this.syncBodyDataset();
    this.pushHud(true);
  }

  resumeGame(): void {
    if (this.phase !== 'paused') return;
    this.phase = 'playing';
    this.audio.setPaused(false);
    this.requestPointerLock();
    this.syncBodyDataset();
    this.pushHud(true);
  }

  toggleMute(): void {
    const next = !this.audio.isMuted();
    this.audio.setMuted(next);
    this.pushHud(true);
  }

  returnToTitle(): void {
    this.phase = 'title';
    this.input.keys.clear();
    this.wasPointerLocked = false;
    this.exitPointerLock();
    this.syncBodyDataset();
    this.pushHud(true);
  }

  private toggleFlashlight(): void {
    if (this.runState.battery <= 0) {
      this.runState.flashlightOn = false;
      this.audio.playFlashlightClick(false);
      this.showBanner('Батарея фонарика разряжена! Найдите батарею.');
      this.pushHud(true);
      return;
    }
    this.runState.flashlightOn = !this.runState.flashlightOn;
    this.audio.playFlashlightClick(this.runState.flashlightOn);
    this.pushHud(true);
  }

  private tryInteract(): void {
    const target = this.player.findBestInteractable(this.interactables);
    if (!target) return;

    const outcome = applyInteraction(this.runState, target, this.interactables);
    if (outcome.message) {
      this.showBanner(outcome.message);
    }

    switch (outcome.sound) {
      case 'pickup':
      case 'key_pickup':
        this.audio.playPickup();
        break;
      case 'fuse_insert':
        this.audio.playFuseInsert();
        break;
      case 'power_on':
        this.audio.playPowerRestore();
        break;
      case 'unlock_exit':
        this.audio.playVictoryChord();
        break;
      case 'locked':
        this.audio.playLocked();
        break;
    }

    if (target.kind === 'nightstand') {
      this.audio.playDrawer(target.isOpen ?? true);
    }

    if (target.kind === 'door') {
      this.wallAABBs = buildWallAABBs(this.interactables);
    }

    // Re-sync held item viewmodel on player camera
    this.player.setHeldItem(this.runState.inventory[this.runState.activeSlotIndex]);

    if (this.runState.escaped) {
      this.phase = 'victory';
      this.wasPointerLocked = false;
      this.exitPointerLock();
      this.syncBodyDataset();
    }

    this.pushHud(true);
  }

  private showBanner(msg: string, duration = 3.2): void {
    this.bannerText = msg;
    this.bannerTimer = duration;
  }

  private syncBodyDataset(): void {
    const bodyState =
      this.phase === 'victory' || this.phase === 'defeat' ? 'gameover' : this.phase;
    document.body.dataset.state = bodyState;
  }

  private scheduleNextTick(): void {
    if (this.disposed) return;
    this.frameId = requestAnimationFrame(this.tick);
  }

  private tick = (): void => {
    if (this.disposed) return;

    const nowMs = performance.now();
    const rawDt = Math.max(0, (nowMs - this.lastFrameTimeMs) / 1000);
    this.lastFrameTimeMs = nowMs;
    const dt = Math.min(rawDt, 0.05);
    this.elapsedTotal += dt;

    if (this.phase === 'title') {
      this.updateTitleTour();
      this.updateLampsAndWorld(dt);
    } else if (this.phase === 'playing') {
      this.updatePlaying(dt);
      this.updateLampsAndWorld(dt);
    } else if (this.phase === 'defeat') {
      this.updateDefeatBeat(dt);
      this.updateLampsAndWorld(dt);
    } else if (this.phase === 'victory') {
      this.victoryDoorOpen = Math.min(1, this.victoryDoorOpen + dt * 1.4);
      this.updateLampsAndWorld(dt);
    }

    if (this.bannerTimer > 0) {
      this.bannerTimer -= dt;
      if (this.bannerTimer <= 0) {
        this.bannerText = null;
        this.pushHud(true);
      }
    }

    if (this.redSurgeTimer > 0) {
      this.redSurgeTimer -= dt;
    }

    this.renderer.render(this.scene, this.player.camera);
    this.scheduleNextTick();
  };

  private updateTitleTour(): void {
    const t = this.elapsedTotal * 0.22;
    const base = gridToWorld(7.0, 5.5);
    this.player.camera.position.set(
      base.x + Math.sin(t * 0.25) * 1.1,
      1.62 + Math.sin(t * 0.7) * 0.04,
      base.z + Math.cos(t * 0.35) * 0.35,
    );
    this.player.camera.rotation.order = 'YXZ';
    this.player.camera.rotation.y = -Math.PI / 2 + Math.sin(t * 0.22) * 0.08;
    this.player.camera.rotation.x = Math.sin(t * 0.4) * 0.03;

    this.player.flashlight.position.copy(this.player.camera.position);
    this.player.flashlightTarget.position.set(
      this.player.camera.position.x + 6,
      1.45,
      this.player.camera.position.z + Math.sin(t * 0.5) * 0.6,
    );
    this.player.flashlight.intensity = 7.5;
  }

  private updatePlaying(dt: number): void {
    this.runState.elapsedSeconds += dt;

    // Flashlight battery
    const batRes = advanceBattery(this.runState.battery, this.runState.flashlightOn, dt);
    this.runState.battery = batRes.battery;
    this.runState.flashlightOn = batRes.flashlightOn;

    // NVG battery
    const nvgRes = advanceNvgBattery(this.runState.nvgBattery, this.runState.nvgOn, dt);
    this.runState.nvgBattery = nvgRes.nvgBattery;
    this.runState.nvgOn = nvgRes.nvgOn;

    this.player.update(
      dt,
      this.input,
      this.wallAABBs,
      this.runState.flashlightOn,
      batRes.flickering,
      this.runState.nvgOn,
      this.elapsedTotal,
      (sprint) => this.audio.playFootstep(sprint),
    );

    const monsterRes = this.monster.update(
      dt,
      this.elapsedTotal,
      this.player.x,
      this.player.z,
      this.runState.flashlightOn,
      this.player.isSprinting,
      this.runState.powerRestored,
      this.wallAABBs,
      () => {
        this.audio.playChaseSting();
        this.showBanner('MAWRG ЗАМЕТИЛ ВАС — БЕГИТЕ!', 2.2);
      },
      (prox) => this.audio.playMonsterStep(prox),
      this.interactables,
      (door, isChase) => {
        this.wallAABBs = buildWallAABBs(this.interactables);
        if (isChase) {
          this.audio.playCreakOrBang('bang');
          this.redSurgeTimer = 1.2;
          this.showBanner('MAWRG ВЫБИВАЕТ ДВЕРЬ!', 2.2);
          const distToPlayer = Math.hypot(this.player.x - door.x, this.player.z - door.z);
          if (distToPlayer < 14) {
            this.audio.playChaseSting();
          }
        } else {
          this.audio.playCreakOrBang('creak');
          this.showBanner('Слышен скрип открываемой двери...', 2.0);
        }
      },
    );

    this.audio.updateHeartbeat(this.elapsedTotal, monsterRes.dangerLevel);

    // Event zones
    for (let i = 0; i < this.eventZones.length; i++) {
      const z = this.eventZones[i];
      if (this.triggeredEvents.has(z.id)) continue;
      if (Math.hypot(this.player.x - z.x, this.player.z - z.z) <= z.radius) {
        this.triggeredEvents.add(z.id);
        this.showBanner(z.message, 3.0);
        if (z.kind === 'lamp_spark') {
          this.world.lamps[1].shortCircuited = true;
          this.audio.playCreakOrBang('spark');
        } else if (z.kind === 'red_surge') {
          this.redSurgeTimer = 2.6;
          this.audio.playCreakOrBang('bang');
        } else {
          this.audio.playCreakOrBang('creak');
        }
      }
    }

    // Proximity ambient stings
    if (this.elapsedTotal > this.nextAmbientSfxTime) {
      this.audio.playAmbientSting();
      this.nextAmbientSfxTime = this.elapsedTotal + 14 + Math.random() * 12;
    }

    if (monsterRes.caughtPlayer && !this.runState.escaped) {
      this.triggerDefeat();
      return;
    }

    this.pushHud(false, monsterRes.dangerLevel);
  }

  private triggerDefeat(): void {
    this.phase = 'defeat';
    this.runState.caught = true;
    this.defeatTrauma = 1.0;
    this.input.keys.clear();
    this.audio.playCaughtSting();
    this.wasPointerLocked = false;
    this.exitPointerLock();
    this.syncBodyDataset();
    this.pushHud(true, 1.0);
  }

  private updateDefeatBeat(dt: number): void {
    this.defeatTrauma = Math.max(0, this.defeatTrauma - dt * 0.4);
    const shake = this.defeatTrauma;
    const dx = this.monster.x - this.player.x;
    const dz = this.monster.z - this.player.z;
    const targetYaw = Math.atan2(-dx, -dz);
    this.player.camera.rotation.y =
      targetYaw + Math.sin(this.elapsedTotal * 48) * 0.08 * shake;
    this.player.camera.rotation.x = 0.08 + Math.cos(this.elapsedTotal * 42) * 0.06 * shake;
  }

  private updateLampsAndWorld(dt: number): void {
    this.syncWorldVisuals(dt);

    const powered = this.runState.powerRestored;
    const surgeRed = this.redSurgeTimer > 0;

    for (let i = 0; i < this.world.lamps.length; i++) {
      const lamp = this.world.lamps[i];
      let factor = powered ? 1.15 : 0.72;

      if (lamp.shortCircuited && !powered) {
        factor = Math.sin(this.elapsedTotal * 29) > 0.78 ? 0.6 : 0.04;
      } else {
        const noise =
          Math.sin(this.elapsedTotal * 7.5 + lamp.flickerPhase) *
          Math.sin(this.elapsedTotal * 19.3 + lamp.flickerPhase * 2);
        if (noise > 0.86) {
          factor *= 0.28;
        }
      }

      if (lamp.light) {
        lamp.light.intensity = lamp.baseIntensity * factor;
        if (surgeRed) {
          lamp.light.color.setHex(0xdc2626);
        } else if (powered) {
          lamp.light.color.setHex(i === 7 ? 0xf59e0b : 0xdbeafe);
        }
      }

      lamp.tubeMat.emissiveIntensity = (lamp.light ? 1.3 : 0.75) * factor;
      if (surgeRed) {
        lamp.tubeMat.emissive.setHex(0xdc2626);
      } else if (powered) {
        lamp.tubeMat.emissive.setHex(i === 7 ? 0xf59e0b : 0xdbeafe);
      }
    }
  }

  private syncWorldVisuals(dt: number): void {
    // Item visibility, nightstand drawer slide & hover bob
    for (let i = 0; i < this.interactables.length; i++) {
      const item = this.interactables[i];
      const mesh = this.world.itemMeshes.get(item.id);
      if (mesh) {
        if (item.kind === 'door') {
          mesh.visible = true;
          const leaf = mesh.getObjectByName('doorLeaf');
          if (leaf) {
            const targetX = item.isOpen ? 1.4 : 0;
            leaf.position.x += (targetX - leaf.position.x) * dt * 8;
          }
        } else if (item.kind === 'nightstand') {
          mesh.visible = true;
          const drawer = mesh.getObjectByName('drawerMesh');
          if (drawer) {
            const targetZ = item.isOpen ? 0.38 : 0.02;
            drawer.position.z += (targetZ - drawer.position.z) * dt * 7;
          }
        } else {
          // If item is inside a closed nightstand, hide it
          if (item.insideNightstandId) {
            const ns = this.interactables.find((it) => it.id === item.insideNightstandId);
            mesh.visible = ns ? Boolean(ns.isOpen) && !item.collected : !item.collected;
          } else {
            mesh.visible = !item.collected;
          }

          if (!item.collected && mesh.visible) {
            mesh.rotation.y += dt * 1.1;
            mesh.position.y = item.y + Math.sin(this.elapsedTotal * 2.4 + i) * 0.035;
          }
        }
      }
    }

    // Generator fuse LEDs & turbine spin
    for (let i = 0; i < 3; i++) {
      const lit = i < this.runState.fusesInstalled;
      this.world.generatorFuseLeds[i].color.setHex(lit ? 0x10b981 : 0x7f1d1d);
      this.world.generatorFuseLeds[i].emissive.setHex(lit ? 0x10b981 : 0x991b1b);
    }
    this.world.generatorPowerLed.color.setHex(this.runState.powerRestored ? 0x10b981 : 0x991b1b);
    this.world.generatorPowerLed.emissive.setHex(this.runState.powerRestored ? 0x10b981 : 0xcc2222);

    if (this.runState.powerRestored) {
      this.world.turbineRotor.rotation.z += dt * 5.2;
      this.cabinetDoorOpen = Math.min(1, this.cabinetDoorOpen + dt * 2.5);
    } else {
      this.cabinetDoorOpen = Math.max(0, this.cabinetDoorOpen - dt * 4);
    }

    this.world.cabinetLed.color.setHex(this.runState.powerRestored ? 0x10b981 : 0xcc2222);
    this.world.cabinetLed.emissive.setHex(this.runState.powerRestored ? 0x10b981 : 0xcc2222);
    this.world.cabinetDoor.position.x = -this.cabinetDoorOpen * 0.55;
    this.world.cabinetKeyMesh.visible = !this.runState.hasExitKey;

    const exitReady = this.runState.powerRestored && this.runState.hasExitKey;
    this.world.exitBeaconMat.color.setHex(exitReady ? 0x10b981 : 0xcc2222);
    this.world.exitBeaconMat.emissive.setHex(exitReady ? 0x10b981 : 0xcc2222);

    if (this.world.exitPlanksGroup) {
      this.world.exitPlanksGroup.visible = !this.runState.planksRemoved;
    }
    if (this.world.exitAlarmLedMat) {
      this.world.exitAlarmLedMat.color.setHex(this.runState.alarmDisabled ? 0x10b981 : 0xef4444);
      this.world.exitAlarmLedMat.emissive.setHex(this.runState.alarmDisabled ? 0x10b981 : 0xef4444);
    }

    this.world.exitDoorLeaves[0].position.x = -0.73 - this.victoryDoorOpen * 1.1;
    this.world.exitDoorLeaves[1].position.x = 0.73 + this.victoryDoorOpen * 1.1;
  }

  private pushHud(
    force: boolean,
    dangerLevel = 0,
    targetOverride?: InteractableItem | null,
  ): void {
    if (!force && this.elapsedTotal - this.lastHudPush < 0.08) return;
    this.lastHudPush = this.elapsedTotal;

    const target =
      targetOverride !== undefined
        ? targetOverride
        : this.phase === 'playing'
          ? this.player.findBestInteractable(this.interactables)
          : null;

    const prompt = target ? getInteractionPrompt(this.runState, target) : null;
    const flickering =
      this.runState.flashlightOn &&
      this.runState.battery > 0 &&
      this.runState.battery <= 20;

    this.onHudUpdate({
      phase: this.phase,
      fusesCarried: this.runState.fusesCarried,
      fusesInstalled: this.runState.fusesInstalled,
      totalFuses: this.runState.totalFuses,
      powerRestored: this.runState.powerRestored,
      hasExitKey: this.runState.hasExitKey,
      hasHammer: this.runState.hasHammer,
      hasWireCutters: this.runState.hasWireCutters,
      hasNvg: this.runState.hasNvg,
      nvgOn: this.runState.nvgOn,
      nvgBattery: Math.round(this.runState.nvgBattery),
      inventory: this.runState.inventory,
      activeSlotIndex: this.runState.activeSlotIndex,
      planksRemoved: this.runState.planksRemoved,
      alarmDisabled: this.runState.alarmDisabled,
      battery: Math.round(this.runState.battery),
      flashlightOn: this.runState.flashlightOn,
      flashlightFlickering: flickering,
      objective: computeObjectiveText(this.runState),
      promptText: prompt ? prompt.title : null,
      promptSubtext: prompt ? prompt.detail : null,
      roomName: getRoomNameAt(this.player.x, this.player.z),
      statusBanner: this.bannerText,
      dangerLevel,
      elapsedSeconds: Math.floor(this.runState.elapsedSeconds),
      pointerLocked: this.pointerLocked,
      muted: this.audio.isMuted(),
    });
  }
}
